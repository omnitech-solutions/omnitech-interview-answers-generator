import { FieldLayoutProps } from '../Input/Input.variants';
import { RootProps } from '../lib';
import * as React from 'react';
export interface DateTimePickerProps extends RootProps, FieldLayoutProps {
    id?: string;
    name?: string;
    /** ISO 8601 datetime string (`YYYY-MM-DDTHH:MM`). */
    value?: string;
    onChange?: (next: string) => void;
    min?: Date;
    max?: Date;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    wrapperClassName?: string;
    labelClassName?: string;
    className?: string;
    'data-testid'?: string;
}
/** Chrome-wrapped Omni DateTimePicker. */
export declare const DateTimePicker: React.NamedExoticComponent<DateTimePickerProps>;
