import { InputSize, InputVariant } from '../Input/Input.variants';
import * as React from 'react';
export interface DateTimePickerPrimitiveProps {
    id?: string;
    name?: string;
    value?: string;
    onChange?: (next: string) => void;
    min?: Date;
    max?: Date;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    /** The look of the field box. Default `bordered`. */
    variant?: InputVariant;
    /** The height of the field box. Default `default`. */
    inputSize?: InputSize;
    readOnly?: boolean;
    /** Id of the element that names the pair: the date button is named by it and its own date, the time field by it. */
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    /** Name of the time field when nothing labels the pair. */
    timeLabel?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw date + time pair (no chrome). */
export declare const DateTimePickerPrimitive: React.ForwardRefExoticComponent<DateTimePickerPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
