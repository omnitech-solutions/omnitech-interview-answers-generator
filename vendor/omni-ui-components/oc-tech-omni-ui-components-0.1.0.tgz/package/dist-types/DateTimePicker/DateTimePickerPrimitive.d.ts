import * as React from 'react';
export interface DateTimePickerPrimitiveProps {
    id?: string;
    name?: string;
    value?: string;
    onChange?: (next: string) => void;
    min?: Date;
    max?: Date;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw date + time pair (no chrome). */
export declare const DateTimePickerPrimitive: React.ForwardRefExoticComponent<DateTimePickerPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
