import type * as React from 'react';
export interface DescriptionItem {
    key?: React.Key;
    label: React.ReactNode;
    children: React.ReactNode;
}
export interface DescriptionsProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
    title?: React.ReactNode;
    items: DescriptionItem[];
    columns?: number;
    /** `false` draws the rows only, with no box of its own: for use inside a `Card`, a `Collapse` or a `Panel`. Default `true`. */
    bordered?: boolean;
    /** `small` tightens the padding and the gaps for a narrow column. Default `default`. */
    size?: 'default' | 'small';
}
/**
 * Omni Descriptions: labelled values. Each item is a small upper-case `label` over its `children` (text, a
 * `Tag`, a list of lines, a field).
 *
 * Slots: `data-slot="descriptions" | "descriptions-title" | "descriptions-item" | "descriptions-label" |
 * "descriptions-value"`. The root carries `data-size` and `data-bordered`.
 *
 * @example
 * <Descriptions columns={1} size="small" bordered={false} items={[{ label: 'Owner', children: 'Alex Morgan' }]} />
 */
export declare const Descriptions: ({ title, items, columns, bordered, size, className, ...props }: DescriptionsProps) => React.JSX.Element;
