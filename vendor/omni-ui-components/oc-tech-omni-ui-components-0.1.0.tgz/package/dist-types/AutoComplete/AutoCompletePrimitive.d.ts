import { AutoCompleteOption, AutoCompletePrimitiveProps } from './AutoComplete.types';
import * as React from 'react';
/**
 * Raw Omni AutoComplete primitive: a free-text input (`role="combobox"`) with a suggestion listbox under it.
 * No label, no description, no error row: pair with {@link AutoComplete} when field chrome is needed.
 * The ref and `id` are the input's.
 *
 * @example
 * <AutoCompletePrimitive aria-label="Assignee" value={name} onChange={setName} onSelect={assign} options={people} />
 */
export declare const AutoCompletePrimitive: (<T extends AutoCompleteOption = AutoCompleteOption>(props: AutoCompletePrimitiveProps<T> & {
    ref?: React.Ref<HTMLInputElement>;
}) => React.ReactElement) & {
    displayName?: string;
};
