import { InputProps } from '../Input';
import * as React from 'react';
export interface AutoCompleteOption {
    value: string;
    label?: React.ReactNode;
}
export interface AutoCompleteProps extends Omit<InputProps, 'onChange' | 'value'> {
    value?: string;
    onChange?: (next: string) => void;
    options?: AutoCompleteOption[];
}
export declare function AutoComplete({ id: idProp, value, onChange, options, className, label, description, error, required, invalid, layout, wrapperClassName, labelClassName, placeholder, disabled, onBlur, onFocus, ...props }: AutoCompleteProps): React.JSX.Element;
