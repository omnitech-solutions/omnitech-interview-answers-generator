import { AutoCompleteOption, AutoCompleteProps } from './AutoComplete.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni AutoComplete: {@link AutoCompletePrimitive} inside {@link FieldShell}.
 * Free text with suggestions: the value is the typed string.
 *
 * @example
 * <AutoComplete label="Assignee" value={name} onChange={setName} options={people} />
 */
export declare const AutoComplete: (<T extends AutoCompleteOption = AutoCompleteOption>(props: AutoCompleteProps<T> & {
    ref?: React.Ref<HTMLInputElement>;
}) => React.ReactElement) & {
    displayName?: string;
};
