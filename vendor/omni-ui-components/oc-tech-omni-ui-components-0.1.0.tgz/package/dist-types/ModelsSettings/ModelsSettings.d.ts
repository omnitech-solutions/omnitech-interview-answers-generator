import { ModelInfo } from '../ModelPicker/ModelPicker.types';
import { ModelsSettingsLabels, ModelsSettingsProps } from './ModelsSettings.types';
import * as React from 'react';
export declare const DEFAULT_MODELS_SETTINGS_LABELS: ModelsSettingsLabels;
/**
 * The Models tab of the settings dialog: the read-only endpoint, a "Connected · N models" status, the available
 * models and a cloud-providers row. Generic over `ModelInfo`: extend it and `renderModelMeta` receives your type.
 * `onAddProvider()` adds the Add provider button; without it the whole row is not rendered.
 *
 * Slots: `data-slot="models-settings" | "models-status" | "models-list" | "model-row" | "models-providers"`.
 *
 * @example
 * <ModelsSettings endpoint="http://localhost:1234/v1" models={models} onAddProvider={openProviders} />
 */
export declare const ModelsSettings: <M extends ModelInfo = ModelInfo>({ endpoint, status, models, onAddProvider, addProviderIcon, modelIcon, renderModelMeta, labels: labelOverrides, className, }: ModelsSettingsProps<M>) => React.JSX.Element;
