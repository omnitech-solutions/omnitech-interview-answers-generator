/** The status dot beside the connection line, on the tone scale. */
export declare const modelsStatusVariants: (props?: ({
    status?: "connected" | "checking" | "disconnected" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
