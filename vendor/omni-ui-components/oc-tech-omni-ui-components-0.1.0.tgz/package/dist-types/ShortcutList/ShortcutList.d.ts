import { ShortcutItem, ShortcutListLabels, ShortcutListProps } from './ShortcutList.types';
import * as React from 'react';
export declare const DEFAULT_SHORTCUT_LIST_LABELS: ShortcutListLabels;
/**
 * Omni ShortcutList: a read-only reference of actions and their keys. `keys` is a shortcut string (`mod+k`), turned
 * into glyphs by `describe` (default: ⌘ ⇧ ⌥ on a Mac, Ctrl Shift Alt elsewhere), or the glyphs themselves.
 *
 * Slots: `data-slot="shortcut-list" | "shortcut-label" | "shortcut-keys"`.
 *
 * @example
 * <ShortcutList items={[{ label: 'Search conversations', keys: 'mod+k' }, { label: 'Stop reply', keys: ['Esc'] }]} />
 */
export declare const ShortcutList: <S extends ShortcutItem = ShortcutItem>({ items, describe, title, labels: labelOverrides, className, }: ShortcutListProps<S>) => React.JSX.Element;
