import { DrawerCloseProps, DrawerContentProps, DrawerFooterProps, DrawerHeaderProps, DrawerPortalProps, DrawerProps, DrawerTriggerProps } from './Drawer.types';
import * as React from 'react';
export declare const Drawer: React.FC<DrawerProps>;
export declare const DrawerTrigger: React.FC<DrawerTriggerProps>;
export declare const DrawerPortal: React.FC<DrawerPortalProps>;
export declare const DrawerClose: React.FC<DrawerCloseProps>;
declare const DrawerOverlayInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-dialog').DialogOverlayProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
declare const DrawerContentInner: React.ForwardRefExoticComponent<DrawerContentProps & React.RefAttributes<HTMLDivElement>>;
declare const DrawerTitleInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-dialog').DialogTitleProps & React.RefAttributes<HTMLHeadingElement>, "ref"> & React.RefAttributes<HTMLHeadingElement>>;
declare const DrawerDescriptionInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-dialog').DialogDescriptionProps & React.RefAttributes<HTMLParagraphElement>, "ref"> & React.RefAttributes<HTMLParagraphElement>>;
export declare const DrawerOverlay: typeof DrawerOverlayInner;
export declare const DrawerContent: typeof DrawerContentInner;
export declare const DrawerHeader: React.MemoExoticComponent<{
    (props: DrawerHeaderProps): React.JSX.Element;
    displayName: string;
}>;
export declare const DrawerFooter: React.MemoExoticComponent<{
    (props: DrawerFooterProps): React.JSX.Element;
    displayName: string;
}>;
export declare const DrawerTitle: typeof DrawerTitleInner;
export declare const DrawerDescription: typeof DrawerDescriptionInner;
export {};
