import { InputPrimitiveProps } from './Input.types';
import * as React from 'react';
/**
 * The multiline mode of {@link InputPrimitive}: an auto-growing `<textarea>` that follows the same variants as the
 * single-line field (so `variant="panel"` is the see-through dock look).
 *
 * Keys: with `sendOnEnter`, Enter calls `onSubmit(value)` (blank too: the host guards); Shift+Enter is a newline and an IME
 * composition is never interrupted. `commitOnEnter` has no meaning here and is ignored.
 */
export declare const MultilineField: React.ForwardRefExoticComponent<Omit<InputPrimitiveProps, "ref"> & React.RefAttributes<HTMLTextAreaElement>>;
