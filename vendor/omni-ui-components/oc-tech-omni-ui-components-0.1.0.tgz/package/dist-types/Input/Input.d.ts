import { InputProps } from './Input.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Input. Composes {@link InputPrimitive} with a
 * label / description / error stack via {@link FieldShell}.
 *
 * `actions` adds a trailing slot (a composer's mic and send); `variant="panel"` is the see-through dock field.
 *
 * @example
 * <Input label="Project Title" value={title} onChange={setTitle} required />
 * <Input variant="panel" aria-label="Message" value={text} onChange={setText} actions={<IconButton label="Send" icon={<ArrowUp />} />} />
 */
declare const InputInner: React.ForwardRefExoticComponent<Omit<InputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const Input: typeof InputInner;
export {};
