import { InputPrimitiveProps } from './Input.types';
import * as React from 'react';
/**
 * Raw Omni input primitive. Renders a styled `<input>` and nothing else.
 * No label, no description, no error row — pair with {@link Input} when
 * field chrome is needed.
 *
 * Wrapped in `React.memo` so RJSF parent re-renders only touch fields whose
 * props actually changed; unchanged sibling fields skip the work entirely.
 *
 * @example
 * <InputPrimitive variant="ghost" value={value} onChange={setValue} />
 *
 * @example
 * <InputPrimitive
 *   variant="bordered"
 *   inputSize="default"
 *   invalid={Boolean(errors.subject)}
 *   commitOnEnter
 *   onBlur={save}
 *   value={subject}
 *   onChange={setSubject}
 * />
 */
declare const InputPrimitiveInner: React.ForwardRefExoticComponent<Omit<InputPrimitiveProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const InputPrimitive: typeof InputPrimitiveInner;
export {};
