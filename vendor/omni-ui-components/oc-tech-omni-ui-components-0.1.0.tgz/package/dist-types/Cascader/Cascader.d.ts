import { CascaderOption, CascaderProps } from './Cascader.types';
import * as React from 'react';
/**
 * Chooses a path through a tree of options, one column per level. Composes
 * {@link CascaderPrimitive} with the label, description and error rows.
 *
 * @example
 * <Cascader label="Stack" options={stack} value={path} onChange={(next) => setPath(next)} />
 */
export declare const Cascader: (<T extends CascaderOption = CascaderOption>(props: CascaderProps<T> & React.RefAttributes<HTMLButtonElement>) => React.ReactElement | null) & {
    displayName?: string;
};
