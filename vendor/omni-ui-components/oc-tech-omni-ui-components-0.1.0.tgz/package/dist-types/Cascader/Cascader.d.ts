import * as React from 'react';
export type CascaderOption = {
    value: string;
    label: React.ReactNode;
    children?: CascaderOption[];
    disabled?: boolean;
};
export interface CascaderProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'value' | 'defaultValue' | 'onChange'> {
    options: CascaderOption[];
    value?: string[];
    defaultValue?: string[];
    onChange?: (value: string[], selectedOptions: CascaderOption[]) => void;
}
export declare const Cascader: React.ForwardRefExoticComponent<CascaderProps & React.RefAttributes<HTMLSelectElement>>;
