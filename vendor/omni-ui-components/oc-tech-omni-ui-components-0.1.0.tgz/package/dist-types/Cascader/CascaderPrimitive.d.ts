import { CascaderOption, CascaderPrimitiveProps } from './Cascader.types';
import * as React from 'react';
/**
 * The bare cascading picker: a field-like combobox trigger and a popup with one column per open level.
 * The value is the path of option values; chosen options reach `onChange` by reference.
 *
 * @example
 * <CascaderPrimitive aria-label="Stack" options={stack} value={path} onChange={(next) => setPath(next)} />
 */
export declare const CascaderPrimitive: (<T extends CascaderOption = CascaderOption>(props: CascaderPrimitiveProps<T> & React.RefAttributes<HTMLButtonElement>) => React.ReactElement | null) & {
    displayName?: string;
};
