/** The summary button: a quiet outlined pill row. */
export declare const stepSummaryButtonClasses: string;
export declare const stepListClasses = "flex flex-col rounded-[10px] border border-solid border-[color:var(--oui-panel-divider)] p-1 bg-[color:color-mix(in_srgb,var(--oui-panel-bg)_calc(var(--oui-panel-see-through,1)_*_100%),transparent)]";
export declare const stepRowClasses = "flex items-center gap-2.5 px-2 py-1.5 text-[13px]";
/** The quiet `parallel` tag. */
export declare const stepParallelClasses = "flex-none rounded-[5px] border border-solid border-[color:var(--oui-panel-divider)] px-1.5 text-[11px] leading-4 font-normal text-[color:var(--oui-panel-meta-fg)]";
/** The default spinner ring. */
export declare const stepSpinnerClasses = "inline-block size-3.5 flex-none animate-spin rounded-full border-2 border-solid border-current border-t-transparent motion-reduce:animate-none";
/** Rail dot: empty circle, accent ring while running, success tint when done, danger tint when failed. */
export declare const railDotVariants: (props?: ({
    state?: "running" | "done" | "pending" | "failed" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
/** The dotted connector between two rail dots. */
export declare const railLineClasses = "my-0.5 min-h-3 w-0 flex-1 border-s-[1.5px] border-dotted border-[color:var(--oui-panel-divider)]";
