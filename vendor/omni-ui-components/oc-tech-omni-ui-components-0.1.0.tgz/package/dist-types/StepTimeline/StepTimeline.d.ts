import { StepTimelineLabels, StepTimelineProps, StepTimelineStep } from './StepTimeline.types';
import * as React from 'react';
/** English strings of {@link StepTimeline}. */
export declare const DEFAULT_STEP_TIMELINE_LABELS: StepTimelineLabels;
/** Generic over the step item type, so an extended step keeps its fields in props and slots. */
export declare const StepTimeline: <T extends StepTimelineStep = StepTimelineStep>(props: StepTimelineProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
