import { FieldLayoutProps } from '../Input/Input.variants';
import { RootProps } from '../lib';
import * as React from 'react';
export interface InputOTPProps extends RootProps, FieldLayoutProps {
    id?: string;
    name?: string;
    value?: string;
    defaultValue?: string;
    onChange?: (next: string) => void;
    /** Number of slots. Default 6. */
    length?: number;
    /** Insert a separator dot after this slot index (0-based). */
    separatorIndex?: number;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    wrapperClassName?: string;
    labelClassName?: string;
    className?: string;
    'data-testid'?: string;
}
/**
 * Omni InputOTP — chrome-wrapped {@link InputOTPPrimitive}.
 */
export declare const InputOTP: React.NamedExoticComponent<InputOTPProps>;
