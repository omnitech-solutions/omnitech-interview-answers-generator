import * as React from 'react';
export interface InputOTPPrimitiveProps {
    id?: string;
    name?: string;
    value?: string;
    defaultValue?: string;
    onChange?: (next: string) => void;
    length?: number;
    separatorIndex?: number;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    /** Read-only: stays focusable and readable, is announced as read-only, and cannot be changed. `disabled` wins. */
    readOnly?: boolean;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw OTP grid with no chrome (no label/description/error). */
export declare const InputOTPPrimitive: React.ForwardRefExoticComponent<InputOTPPrimitiveProps & React.RefAttributes<HTMLInputElement>>;
