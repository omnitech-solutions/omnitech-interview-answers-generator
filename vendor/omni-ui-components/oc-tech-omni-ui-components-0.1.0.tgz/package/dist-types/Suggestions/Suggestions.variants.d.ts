/** A follow-up chip: quiet outline, accent tint on hover, left-aligned wrapping text. */
export declare const suggestionChipVariants: (props?: import('class-variance-authority/types').ClassProp | undefined) => string;
