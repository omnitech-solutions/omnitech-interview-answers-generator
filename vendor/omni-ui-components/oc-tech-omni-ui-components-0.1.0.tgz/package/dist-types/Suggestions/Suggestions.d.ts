import { SuggestionItem, SuggestionsProps } from './Suggestions.types';
import * as React from 'react';
/** Generic over the item type: an extended item flows to every callback and slot, by reference. */
export declare const Suggestions: <T extends SuggestionItem = SuggestionItem>(props: SuggestionsProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
