import { ModalCloseProps, ModalFooterProps, ModalHeaderProps, ModalPortalProps, ModalProps, ModalTriggerProps } from './Modal.types';
import * as React from 'react';
export declare const Modal: React.FC<ModalProps>;
export declare const ModalTrigger: React.FC<ModalTriggerProps>;
export declare const ModalPortal: React.FC<ModalPortalProps>;
export declare const ModalClose: React.FC<ModalCloseProps>;
declare const ModalOverlayInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-dialog').DialogOverlayProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
declare const ModalContentInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-dialog').DialogContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
declare const ModalTitleInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-dialog').DialogTitleProps & React.RefAttributes<HTMLHeadingElement>, "ref"> & React.RefAttributes<HTMLHeadingElement>>;
declare const ModalDescriptionInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-dialog').DialogDescriptionProps & React.RefAttributes<HTMLParagraphElement>, "ref"> & React.RefAttributes<HTMLParagraphElement>>;
export declare const ModalOverlay: typeof ModalOverlayInner;
export declare const ModalContent: typeof ModalContentInner;
export declare const ModalHeader: React.MemoExoticComponent<{
    (props: ModalHeaderProps): React.JSX.Element;
    displayName: string;
}>;
export declare const ModalFooter: React.MemoExoticComponent<{
    (props: ModalFooterProps): React.JSX.Element;
    displayName: string;
}>;
export declare const ModalTitle: typeof ModalTitleInner;
export declare const ModalDescription: typeof ModalDescriptionInner;
export {};
