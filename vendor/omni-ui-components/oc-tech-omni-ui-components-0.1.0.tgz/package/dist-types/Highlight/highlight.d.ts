import { CodeToken, HighlightFn, HighlightOptions } from './Highlight.types';
/** Built-in aliases for the names people put after a code fence. */
export declare const DEFAULT_LANGUAGE_ALIASES: Readonly<Record<string, string>>;
/** One plain, unstyled token per line: what unknown languages and failures fall back to. */
export declare const plainLines: (code: string) => CodeToken[][];
/**
 * Highlights `code` with highlight.js grammars (via lowlight, the `common` set) and returns one token list per
 * line, so code can be rendered line by line (line numbers, per-line marks, diffs). Colours are not decided here:
 * tokens carry `hljs-*` classes and the stylesheet (`--oui-code-*` tokens) paints them, so light and dark follow
 * the theme. Never throws: any failure returns plain lines.
 *
 * @example
 * highlightLines('const a = 1;', 'ts')[0]; // [{ text: 'const', className: 'hljs-keyword' }, { text: ' a = ' }, ...]
 */
export declare function highlightLines(code: string, language?: string, options?: HighlightOptions): CodeToken[][];
/** A {@link HighlightFn} with options fixed, e.g. `createHighlighter({ auto: true })`. */
export declare const createHighlighter: (options?: HighlightOptions) => HighlightFn;
