import { Textarea } from '../Textarea';
import type * as React from 'react';
export interface MentionsOption {
    value: string;
    label?: React.ReactNode;
}
export interface MentionsProps extends Omit<React.ComponentProps<typeof Textarea>, 'onChange' | 'value'> {
    value?: string;
    onChange?: (next: string) => void;
    options?: MentionsOption[];
}
export declare const Mentions: ({ value, onChange, ...props }: MentionsProps) => React.JSX.Element;
