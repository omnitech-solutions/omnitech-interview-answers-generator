import { MentionsOption, MentionsProps } from './Mentions.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Mentions: {@link MentionsPrimitive} inside {@link FieldShell}. The value is plain text.
 *
 * @example
 * <Mentions label="Comment" value={text} onChange={setText} options={people} />
 */
export declare const Mentions: (<T extends MentionsOption = MentionsOption>(props: MentionsProps<T> & {
    ref?: React.Ref<HTMLTextAreaElement>;
}) => React.ReactElement) & {
    displayName?: string;
};
