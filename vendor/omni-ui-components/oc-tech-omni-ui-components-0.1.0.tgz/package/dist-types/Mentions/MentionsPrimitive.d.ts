import { MentionsOption, MentionsPrimitiveProps } from './Mentions.types';
import * as React from 'react';
/**
 * Raw Omni Mentions primitive: a textarea that opens a suggestion listbox under it while a mention is being typed
 * (a trigger at the start of the text or after whitespace, then the query). Picking writes
 * `trigger + option.value + ' '` over the trigger and query. The list is closed when nothing matches.
 * No label, no description, no error row: pair with {@link Mentions}. The ref and `id` are the textarea's.
 *
 * @example
 * <MentionsPrimitive aria-label="Comment" value={text} onChange={setText} onMention={notify} options={people} />
 */
export declare const MentionsPrimitive: (<T extends MentionsOption = MentionsOption>(props: MentionsPrimitiveProps<T> & {
    ref?: React.Ref<HTMLTextAreaElement>;
}) => React.ReactElement) & {
    displayName?: string;
};
