import { Button } from '../Button';
import * as React from 'react';
export interface FloatButtonProps extends React.ComponentProps<typeof Button> {
    bottom?: number;
    right?: number;
}
export declare const FloatButton: React.ForwardRefExoticComponent<Omit<FloatButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
