import { ControlTone } from '../internal/support/controlTone';
import type * as React from 'react';
export interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
    /** `line` (default): the linear bar. `ring`: a circular indicator that fits a control's icon slot. */
    shape?: 'line' | 'ring';
    /** Line shape: completion, 0-100. */
    percent?: number;
    showInfo?: boolean;
    status?: 'normal' | 'success' | 'exception' | 'active';
    /**
     * Ring shape: completion, 0-100 (determinate). Leave unset for an indeterminate,
     * spinning ring (`aria-busy`, no `aria-valuenow`).
     */
    value?: number;
    /** Ring shape: colour from the shared `ControlTone` scale (default `accent`). */
    tone?: ControlTone;
    /** Ring shape: outer diameter in px (default 20, the control icon size). */
    size?: number;
}
/**
 * Omni Progress. The default `line` shape is a linear bar; `shape="ring"` is a
 * circular indicator: determinate with `value`, otherwise an indeterminate
 * spinning ring (swap it for an icon while work is running).
 *
 * @example
 * <Progress percent={64} />
 * <Progress shape="ring" tone="accent" />            // spinning, aria-busy
 * <Progress shape="ring" value={40} size={36} />     // determinate, aria-valuenow=40
 */
export declare const Progress: ({ shape, percent, showInfo, status, value, tone, size, className, ...props }: ProgressProps) => React.JSX.Element;
