import { ControlTone } from '../internal/support/controlTone';
import type * as React from 'react';
/** The optional call to action under an Empty `tile`, rendered with the library Button. */
export interface EmptyAction {
    label: React.ReactNode;
    onClick: () => void;
    /** Button tone from the shared scale. Default `accent`. */
    tone?: ControlTone;
    /** Optional leading icon node. */
    icon?: React.ReactNode;
    /** Optional shortcut text after the label, one entry per key: `['⌘', '⇧', 'S']`. */
    shortcut?: string[];
}
export interface EmptyProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
    /** `dashed` (default): the bordered blank-state box. `tile`: panel empty state with a 40px icon tile. */
    variant?: 'dashed' | 'tile';
    image?: React.ReactNode;
    /** `tile`: the icon node shown inside the 40px tile (falls back to `image`). */
    icon?: React.ReactNode;
    /** `tile`: optional bold title above the description. */
    title?: React.ReactNode;
    description?: React.ReactNode;
    /** `tile`: optional action button under the description. */
    action?: EmptyAction;
}
export declare const Empty: ({ variant, image, icon, title, description, action, className, children, ...props }: EmptyProps) => React.JSX.Element;
