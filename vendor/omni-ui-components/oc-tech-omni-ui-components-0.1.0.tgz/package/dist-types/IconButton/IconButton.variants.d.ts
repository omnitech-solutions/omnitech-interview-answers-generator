import { VariantProps } from 'class-variance-authority';
/**
 * Tailwind class config for IconButton. Sizes track the Omni field
 * height scale (`--oui-field-height-*`) so IconButtons sit cleanly next
 * to Input / Select / Textarea rows.
 */
export declare const iconButtonVariants: (props?: ({
    variant?: "default" | "link" | "ghost" | "destructive" | "outline" | "secondary" | null | undefined;
    iconSize?: "default" | "sm" | "md" | "lg" | "control" | "control-labelled" | null | undefined;
    tone?: "neutral" | "accent" | "success" | "warning" | "danger" | "dim" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type IconButtonVariantProps = VariantProps<typeof iconButtonVariants>;
