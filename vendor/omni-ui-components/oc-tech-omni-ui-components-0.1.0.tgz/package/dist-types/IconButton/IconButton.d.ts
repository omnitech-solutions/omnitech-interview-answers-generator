import { IconButtonProps } from './IconButton.types';
import * as React from 'react';
/**
 * Omni IconButton — square, icon-only button used by RJSF array
 * toolbars (copy / move / remove) and other compact affordances. Sizes
 * track the Omni field-height scale so the button sits cleanly next to
 * Input / Select / Textarea rows.
 *
 * Mirrors `@rjsf/shadcn`'s IconButton API (`icon`, `variant`, size). One
 * of `label` / `aria-label` / `title` is required for a11y; the wrapper
 * does not enforce this at the type level so the props stay structurally
 * compatible with RJSF's `IconButtonProps`.
 *
 * Configuration-driven variations: `tone`, `pressed`, `badge`, `tooltip`,
 * `disabledReason` and the `control` / `control-labelled` sizes. Callbacks
 * are ordinary props (`onClick`).
 *
 * @example
 * <IconButton aria-label="Remove" icon={<Trash2 />} variant="destructive" onClick={…} />
 * <IconButton label="Microphone" icon={<Mic />} iconSize="control" tone="warning"
 *   badge={{ tone: 'warning', label: '!', description: 'Microphone lost' }} tooltip="Microphone lost. Trying again." />
 * <IconButton label="Capture" icon={<Camera />} disabledReason="Resume to capture" />
 */
declare const IconButtonInner: React.ForwardRefExoticComponent<IconButtonProps & React.RefAttributes<HTMLButtonElement>>;
export declare const IconButton: typeof IconButtonInner;
export {};
