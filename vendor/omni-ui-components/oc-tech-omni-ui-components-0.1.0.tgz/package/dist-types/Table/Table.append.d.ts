import { TableColumn, TableDataRow, TableExtendableConfig, TableExtendableSide } from './Table.types';
/**
 * Row / column extension controls.
 *
 * Owns the small "+" affordances (bottom-center for adding a row, right-edge
 * for adding a column) and the default row/column factories used when the
 * consumer doesn't wire their own `onAppend`.
 */
import type * as React from 'react';
export interface ResolvedExtendable<TRecord, TRowData> {
    rows: TableExtendableSide<TRecord, TRowData, TableDataRow<TRecord, TRowData>> | null;
    columns: TableExtendableSide<TRecord, TRowData, TableColumn<TRecord, TRowData>> | null;
    controls: boolean;
}
export declare function resolveExtendable<TRecord, TRowData>(extendable: boolean | TableExtendableConfig<TRecord, TRowData> | undefined): ResolvedExtendable<TRecord, TRowData>;
/** Build an empty appended row using the current column set. */
export declare function makeEmptyRow<TRecord, TRowData>(columns: TableColumn<TRecord, TRowData>[], nextKey: string): TableDataRow<TRecord, TRowData>;
/** Build an empty appended column with an auto-generated key/title. */
export declare function makeEmptyColumn<TRecord, TRowData>(existing: TableColumn<TRecord, TRowData>[]): TableColumn<TRecord, TRowData>;
interface ControlProps {
    label: string;
    onClick: () => void;
    testId?: string;
    className?: string;
}
export declare const AppendControlButton: React.FC<ControlProps>;
export {};
