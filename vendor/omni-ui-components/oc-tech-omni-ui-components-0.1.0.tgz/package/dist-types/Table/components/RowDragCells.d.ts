import type * as React from 'react';
export interface RowDragHeaderProps {
    className?: string;
    style?: React.CSSProperties;
}
export declare const RowDragHeader: React.FC<RowDragHeaderProps>;
export interface RowDragCellProps {
    rowKey: string;
    draggable: boolean;
    className?: string;
    style?: React.CSSProperties;
}
export declare const RowDragCell: React.FC<RowDragCellProps>;
