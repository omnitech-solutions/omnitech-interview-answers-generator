import { ResolvedCellEditable } from '../internal';
import { TableCellOverride, TableCellRenderContext, TableColumn, TableDataRow, TableEditableRowConfig, TableProps, TableResolvedRow } from '../Table.types';
import * as React from 'react';
export interface BodyCellProps<TRecord, TRowData> {
    resolved: TableResolvedRow<TRecord, TRowData>;
    col: TableColumn<TRecord, TRowData>;
    rowIndex: number;
    columnIndex: number;
    indent?: number;
    appearance: NonNullable<TableProps<TRecord, TRowData>['appearance']>;
    treeMode: boolean;
    expandable: TableProps<TRecord, TRowData>['expandable'];
    expanded: import('@tanstack/react-table').ExpandedState;
    toggleExpanded: (resolved: TableResolvedRow<TRecord, TRowData>) => void;
    currentRows: TableDataRow<TRecord, TRowData>[];
    resolvedExtendable: {
        rows?: unknown;
    };
    handleAppendRow: () => Promise<TableDataRow<TRecord, TRowData>>;
    bodyCellEditableConfig: (override: TableCellOverride<TRecord, TRowData> | undefined, col: TableColumn<TRecord, TRowData>) => ResolvedCellEditable<TRecord, TRowData> | null;
    editableCellTarget: (rowKey: string, columnKey: string, direction: -1 | 1) => {
        resolved: TableResolvedRow<TRecord, TRowData>;
        column: TableColumn<TRecord, TRowData>;
        rowConfig: TableEditableRowConfig<TRecord, TRowData> | null;
        editableConfig: ResolvedCellEditable<TRecord, TRowData>;
        value: unknown;
    } | null;
    firstEditableCellTarget: (resolved: TableResolvedRow<TRecord, TRowData>) => {
        resolved: TableResolvedRow<TRecord, TRowData>;
        column: TableColumn<TRecord, TRowData>;
        rowConfig: TableEditableRowConfig<TRecord, TRowData> | null;
        editableConfig: ResolvedCellEditable<TRecord, TRowData>;
        value: unknown;
    } | null;
    beginCellEdit: (resolved: TableResolvedRow<TRecord, TRowData>, col: TableColumn<TRecord, TRowData>, value: unknown, rowConfig: TableEditableRowConfig<TRecord, TRowData> | null, editableConfig: ResolvedCellEditable<TRecord, TRowData> | null) => void;
    saveCellEdit: (rowKey: string, col: TableColumn<TRecord, TRowData>, editableConfig: ResolvedCellEditable<TRecord, TRowData>, ctx: TableCellRenderContext<TRecord, TRowData>, nextValue?: unknown) => Promise<boolean>;
    saveRowEdit: (resolved: TableResolvedRow<TRecord, TRowData>, rowConfig: TableEditableRowConfig<TRecord, TRowData>, pending?: Record<string, unknown>) => Promise<void>;
    cancelCellEdit: (rowKey: string, columnKey: string) => void;
    cancelRowEdit: (resolved: TableResolvedRow<TRecord, TRowData>, rowConfig: TableEditableRowConfig<TRecord, TRowData>) => void;
    setEditableValue: (rowKey: string, columnKey: string, value: unknown) => void;
    rowInitialEditableValues: (resolved: TableResolvedRow<TRecord, TRowData>, rowConfig: TableEditableRowConfig<TRecord, TRowData> | null) => Record<string, unknown>;
    editableErrorKey: (rowKey: string, columnKey: string) => string;
}
export declare function BodyCell<TRecord, TRowData>({ resolved, col, rowIndex, columnIndex, indent, appearance, treeMode, expandable, expanded, toggleExpanded, currentRows, resolvedExtendable, handleAppendRow, bodyCellEditableConfig, editableCellTarget, firstEditableCellTarget, beginCellEdit, saveCellEdit, saveRowEdit, cancelCellEdit, cancelRowEdit, setEditableValue, rowInitialEditableValues, editableErrorKey, }: BodyCellProps<TRecord, TRowData>): React.JSX.Element | null;
