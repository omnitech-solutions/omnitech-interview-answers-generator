import { TableProps, TableSelectionAction } from '../Table.types';
import * as React from 'react';
export interface SelectionHeaderProps<TRecord, TRowData> {
    rowSelection: NonNullable<TableProps<TRecord, TRowData>['rowSelection']>;
    actions: TableSelectionAction[];
    allChangeableSelected: boolean;
    someChangeableSelected: boolean;
    hasChangeableKeys: boolean;
    titleCheckboxProps: React.InputHTMLAttributes<HTMLInputElement>;
    onSelectAll: (nextChecked: boolean, event: React.ChangeEvent<HTMLInputElement>) => void;
    onRunAction: (action: TableSelectionAction) => void;
    fixedSide: 'left' | 'right' | undefined;
    alignStyle: React.CSSProperties;
    className?: string;
}
export declare function SelectionHeader<TRecord, TRowData>({ rowSelection, actions, allChangeableSelected, someChangeableSelected, hasChangeableKeys, titleCheckboxProps, onSelectAll, onRunAction, fixedSide, alignStyle, className, }: SelectionHeaderProps<TRecord, TRowData>): React.JSX.Element;
