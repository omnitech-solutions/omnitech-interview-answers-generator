import { TableColumn, TableProps, TableResolvedRow } from '../Table.types';
import * as React from 'react';
export interface BodyRowProps<TRecord, TRowData> {
    resolved: TableResolvedRow<TRecord, TRowData>;
    rowIndex: number;
    indent: number;
    selected: boolean;
    disabled: boolean;
    canClickExpand: boolean;
    rowClass: string | undefined;
    expandedRowClass: string | undefined;
    rowProps: React.HTMLAttributes<HTMLTableRowElement> & {
        className?: string;
    };
    hasDraggableRows: boolean;
    treeMode: boolean;
    expandable: TableProps<TRecord, TRowData>['expandable'];
    rowSelection: TableProps<TRecord, TRowData>['rowSelection'];
    toggleExpanded: (resolved: TableResolvedRow<TRecord, TRowData>) => void;
    renderRowDragCell: (resolved: TableResolvedRow<TRecord, TRowData>) => React.ReactNode;
    renderSelectionCell: (resolved: TableResolvedRow<TRecord, TRowData>, rowIndex: number) => React.ReactNode;
    renderExpandCell: (resolved: TableResolvedRow<TRecord, TRowData>, rowIndex: number, indent: number) => React.ReactNode;
    renderBodyCell: (resolved: TableResolvedRow<TRecord, TRowData>, col: TableColumn<TRecord, TRowData>, rowIndex: number, columnIndex: number, indent: number) => React.ReactNode;
}
export declare function BodyRow<TRecord, TRowData>({ resolved, rowIndex, indent, selected, disabled, canClickExpand, rowClass, expandedRowClass, rowProps, hasDraggableRows, treeMode, expandable, rowSelection, toggleExpanded, renderRowDragCell, renderSelectionCell, renderExpandCell, renderBodyCell, }: BodyRowProps<TRecord, TRowData>): React.JSX.Element;
