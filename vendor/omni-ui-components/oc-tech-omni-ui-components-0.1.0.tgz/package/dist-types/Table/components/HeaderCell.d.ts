import { TableColumn, TableKey } from '../Table.types';
import type * as React from 'react';
export interface HeaderCellProps<TRecord, TRowData> {
    col: TableColumn<TRecord, TRowData>;
    columnIndex: number;
    extraProps?: React.ThHTMLAttributes<HTMLTableCellElement>;
    committedFilterKeys: (col: TableColumn<TRecord, TRowData>) => TableKey[];
    initialFilterItemsMap: Record<string, import('../Table.types').TableFilterItem[]>;
    onCommitFilter: (col: TableColumn<TRecord, TRowData>, values: TableKey[]) => void;
}
export declare function HeaderCell<TRecord, TRowData>({ col, columnIndex, extraProps, committedFilterKeys, initialFilterItemsMap, onCommitFilter, }: HeaderCellProps<TRecord, TRowData>): React.JSX.Element | null;
