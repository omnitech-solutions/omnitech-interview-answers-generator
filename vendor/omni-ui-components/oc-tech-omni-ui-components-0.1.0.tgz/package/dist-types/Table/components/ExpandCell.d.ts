import { TableColumn, TableProps, TableResolvedRow } from '../Table.types';
import type * as React from 'react';
export interface ExpandCellProps<TRecord, TRowData> {
    resolved: TableResolvedRow<TRecord, TRowData>;
    rowIndex: number;
    indent: number;
    column: TableColumn<TRecord, TRowData> | undefined;
    expandable: NonNullable<TableProps<TRecord, TRowData>['expandable']>;
    isExpanded: boolean;
    canExpand: boolean;
    fixedSide: 'left' | 'right' | undefined;
    indentSize: number;
    onToggle: (resolved: TableResolvedRow<TRecord, TRowData>) => void;
    className?: string;
}
export declare function ExpandCell<TRecord, TRowData>({ resolved, rowIndex, indent, column, expandable, isExpanded, canExpand, fixedSide, indentSize, onToggle, className, }: ExpandCellProps<TRecord, TRowData>): React.JSX.Element;
