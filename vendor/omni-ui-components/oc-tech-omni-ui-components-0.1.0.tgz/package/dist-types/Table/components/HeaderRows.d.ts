import { TableColumn, TableProps } from '../Table.types';
import type * as React from 'react';
export interface HeaderRowsProps<TRecord, TRowData> {
    hasDraggableRows: boolean;
    onHeaderRow: TableProps<TRecord, TRowData>['onHeaderRow'];
    renderRowDragHeader: () => React.ReactNode;
    renderSelectionHeader: () => React.ReactNode;
    renderExpandHeader: () => React.ReactNode;
    renderHeaderCell: (col: TableColumn<TRecord, TRowData>, columnIndex: number, extraProps?: React.ThHTMLAttributes<HTMLTableCellElement>) => React.ReactNode;
    leafCount: (col: TableColumn<TRecord, TRowData>) => number;
    treeMode?: boolean;
}
export declare function HeaderRows<TRecord, TRowData>({ hasDraggableRows, onHeaderRow, renderRowDragHeader, renderSelectionHeader, renderExpandHeader, renderHeaderCell, leafCount, treeMode, }: HeaderRowsProps<TRecord, TRowData>): React.JSX.Element;
