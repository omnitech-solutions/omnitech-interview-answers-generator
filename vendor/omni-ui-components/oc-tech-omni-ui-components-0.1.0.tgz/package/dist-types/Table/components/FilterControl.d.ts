import { TableColumn, TableFilterItem, TableKey } from '../Table.types';
import * as React from 'react';
export interface FilterControlProps<TRecord, TRowData> {
    column: TableColumn<TRecord, TRowData>;
    committedKeys: TableKey[];
    filtered: boolean;
    initialFilterItems: TableFilterItem[];
    onCommit: (column: TableColumn<TRecord, TRowData>, values: TableKey[]) => void;
}
export declare function FilterControl<TRecord, TRowData>({ column: col, committedKeys, filtered, initialFilterItems, onCommit, }: FilterControlProps<TRecord, TRowData>): React.JSX.Element;
