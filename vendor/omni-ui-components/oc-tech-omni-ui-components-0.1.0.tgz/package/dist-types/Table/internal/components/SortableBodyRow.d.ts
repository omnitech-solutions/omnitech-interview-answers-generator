import * as React from 'react';
export interface SortableBodyRowProps extends React.HTMLAttributes<HTMLTableRowElement> {
    rowKey: string;
    onKeyboardMove: (rowKey: string, direction: -1 | 1) => void;
    children?: React.ReactNode;
}
export declare const SortableBodyRow: React.FC<SortableBodyRowProps>;
