import { TableBulkActionsButtonProps } from '../../Table.types';
import type * as React from 'react';
export declare const BulkActionsButton: React.FC<TableBulkActionsButtonProps>;
