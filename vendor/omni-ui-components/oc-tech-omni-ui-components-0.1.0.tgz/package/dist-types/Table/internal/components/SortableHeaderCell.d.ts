import type * as React from 'react';
export interface SortableHeaderCellProps extends React.ThHTMLAttributes<HTMLTableCellElement> {
    columnKey: string;
    testIdPrefix: string;
    onKeyboardMove: (columnKey: string, direction: -1 | 1) => void;
    children?: React.ReactNode;
}
export declare const SortableHeaderCell: React.FC<SortableHeaderCellProps>;
