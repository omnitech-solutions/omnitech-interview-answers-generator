import { TableColumn } from '../Table.types';
export declare const TABLE_BREAKPOINT_QUERIES: Record<string, string>;
export declare const allResponsiveScreens: () => Record<string, boolean>;
export declare const currentResponsiveScreens: () => Record<string, boolean>;
export declare const useResponsiveScreens: () => Record<string, boolean>;
export declare const isResponsiveColumnVisible: <TRecord, TRowData>(column: TableColumn<TRecord, TRowData>, screens: Record<string, boolean>) => boolean;
