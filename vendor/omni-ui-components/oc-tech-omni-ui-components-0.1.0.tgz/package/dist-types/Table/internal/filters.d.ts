import { ColumnFiltersState } from '@tanstack/react-table';
import { TableColumn, TableFilterItem, TableKey, TableResolvedRow } from '../Table.types';
export type TableFilterSearch = boolean | ((input: string, record: TableFilterItem) => boolean);
export declare const initialColumnFilters: <TRecord, TRowData>(columns: TableColumn<TRecord, TRowData>[], filters?: ColumnFiltersState) => ColumnFiltersState;
export declare const filtersRecord: (filters: ColumnFiltersState) => Record<string, TableKey[] | null>;
export declare const filtersRecordForColumn: <TRecord, TRowData>(filters: ColumnFiltersState, col: TableColumn<TRecord, TRowData>) => Record<string, TableKey[] | null>;
export declare const rowsForFilters: <TRecord, TRowData>(rows: TableResolvedRow<TRecord, TRowData>[], columns: TableColumn<TRecord, TRowData>[], filters: ColumnFiltersState) => TableResolvedRow<TRecord, TRowData>[];
export declare const filterItemMatchesSearch: (filter: TableFilterItem, search: string, filterSearch: TableFilterSearch | undefined) => boolean;
