import { TableAppearance, TableProps, TableSemanticDOM, TableSorterResult } from '../Table.types';
import type * as React from 'react';
export declare const px: (value?: number) => string | undefined;
export declare const alignStyle: (align?: string) => React.CSSProperties;
export declare const resolveClassNames: <TRecord, TRowData>(props: TableProps<TRecord, TRowData>) => Partial<Record<TableSemanticDOM, string>>;
export declare const resolveStyles: <TRecord, TRowData>(props: TableProps<TRecord, TRowData>) => Partial<Record<TableSemanticDOM, React.CSSProperties>>;
export declare const appearanceStyle: (appearance?: TableAppearance) => React.CSSProperties;
export declare const defaultRootClass: string;
export declare const tableClass = "w-full border-collapse table-auto";
export declare const ellipsisCellClass = "bui-table-cell-ellipsis truncate overflow-hidden whitespace-nowrap";
export declare const headerCellClass: string;
export declare const bodyCellClass: string;
export declare const DefaultFilterIcon: ({ filtered }: {
    filtered: boolean;
}) => React.JSX.Element;
export declare const DefaultSortIcon: ({ order }: {
    order: TableSorterResult<unknown>["order"];
}) => React.JSX.Element;
