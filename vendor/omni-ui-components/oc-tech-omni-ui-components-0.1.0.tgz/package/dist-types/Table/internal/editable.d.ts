import { TableCellOverride, TableColumn, TableDataRow, TableEditableCellConfig, TableEditableColumnConfig, TableEditableConfig, TableEditableRowConfig, TableProps, TableRegistry } from '../Table.types';
export type ResolvedCellEditable<TRecord, TRowData = unknown> = {
    mode: 'cell' | 'row';
    source: 'cell' | 'column';
    columnConfig?: TableEditableColumnConfig<TRecord, TRowData>;
    cellConfig?: TableEditableCellConfig<TRecord, TRowData>;
};
export declare const editableColumnConfig: <TRecord, TRowData>(editable: TableColumn<TRecord, TRowData>["editable"]) => TableEditableColumnConfig<TRecord, TRowData> | null;
export declare const editableRowConfig: <TRecord, TRowData>(editable: TableDataRow<TRecord, TRowData>["editable"]) => TableEditableRowConfig<TRecord, TRowData> | null;
export declare const resolvedCellEditableConfig: <TRecord, TRowData>(override: TableCellOverride<TRecord, TRowData> | undefined, col: TableColumn<TRecord, TRowData>) => ResolvedCellEditable<TRecord, TRowData> | null;
export declare const normalizeEditableInputValue: (value: unknown) => string;
export declare const tableEditableConfig: <TRecord, TRowData>(editable: TableProps<TRecord, TRowData>["editable"]) => TableEditableConfig<TRecord, TRowData> | null;
export declare const editableRenderer: <TRecord, TRowData>(registry: TableRegistry<TRecord, TRowData>, column: TableColumn<TRecord, TRowData>, override: TableCellOverride<TRecord, TRowData> | undefined, editableConfig: ResolvedCellEditable<TRecord, TRowData>) => import('..').TableCellEditorRenderer<TRecord, TRowData> | undefined;
