import { BadgeProps } from './Badge.types';
import * as React from 'react';
export declare const Badge: React.MemoExoticComponent<({ children, ...props }: BadgeProps) => React.JSX.Element>;
