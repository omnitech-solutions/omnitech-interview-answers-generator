import { InputSize, InputVariant } from '../Input/Input.variants';
import { SelectOption } from '../Select';
import * as React from 'react';
export interface MultiSelectLabels {
    searchPlaceholder: string;
    noResults: string;
    /** Accessible name of a chip's remove control. */
    remove: (label: string) => string;
}
export declare const DEFAULT_MULTI_SELECT_LABELS: MultiSelectLabels;
export interface MultiSelectPrimitiveProps {
    id?: string;
    name?: string;
    options: SelectOption[];
    value?: string[];
    onChange?: (next: string[]) => void;
    placeholder?: string;
    searchable?: boolean;
    maxItems?: number;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    /** Read-only: stays focusable and readable, is announced as read-only, and cannot be changed. `disabled` wins. */
    readOnly?: boolean;
    /** The look of the field box. Default `bordered`. */
    variant?: InputVariant;
    /** The height of the field box. Default `default`. */
    inputSize?: InputSize;
    /** Words drawn or spoken by the control. */
    labels?: Partial<MultiSelectLabels>;
    'aria-label'?: string;
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw multi-select: popover trigger + command + chips. */
export declare const MultiSelectPrimitive: React.ForwardRefExoticComponent<MultiSelectPrimitiveProps & React.RefAttributes<HTMLButtonElement>>;
