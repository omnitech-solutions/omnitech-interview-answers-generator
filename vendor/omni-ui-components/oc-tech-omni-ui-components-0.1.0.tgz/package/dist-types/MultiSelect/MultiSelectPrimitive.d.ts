import { SelectOption } from '../Select';
import * as React from 'react';
export interface MultiSelectPrimitiveProps {
    id?: string;
    name?: string;
    options: SelectOption[];
    value?: string[];
    onChange?: (next: string[]) => void;
    placeholder?: string;
    searchable?: boolean;
    maxItems?: number;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw multi-select: popover trigger + command + chips. */
export declare const MultiSelectPrimitive: React.ForwardRefExoticComponent<MultiSelectPrimitiveProps & React.RefAttributes<HTMLButtonElement>>;
