import type * as React from 'react';
export interface BreadcrumbItem {
    key?: React.Key;
    title: React.ReactNode;
    href?: string;
    onClick?: React.MouseEventHandler<HTMLAnchorElement | HTMLButtonElement>;
}
export interface BreadcrumbProps extends React.HTMLAttributes<HTMLElement> {
    items?: BreadcrumbItem[];
    separator?: React.ReactNode;
}
export declare const Breadcrumb: ({ items, separator, className, children, ...props }: BreadcrumbProps) => React.JSX.Element;
