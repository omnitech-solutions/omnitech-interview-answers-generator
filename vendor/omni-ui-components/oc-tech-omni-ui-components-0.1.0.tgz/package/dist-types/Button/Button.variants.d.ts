import { VariantProps } from 'class-variance-authority';
/**
 * Tailwind class config for the Omni Button. Mirrors the shadcn
 * Button API (variant × size) but routes colors through Omni tokens
 * + Tailwind palette so the look matches the rest of omni-ui-components.
 */
export declare const buttonVariants: (props?: ({
    variant?: "default" | "link" | "ghost" | "destructive" | "outline" | "secondary" | null | undefined;
    buttonSize?: "default" | "icon" | "sm" | "md" | "lg" | "control" | "control-labelled" | null | undefined;
    tone?: "neutral" | "accent" | "success" | "warning" | "danger" | "dim" | null | undefined;
    soft?: boolean | null | undefined;
    fillIcon?: boolean | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type ButtonVariantProps = VariantProps<typeof buttonVariants>;
export type ButtonVariant = NonNullable<ButtonVariantProps['variant']>;
export type ButtonTone = NonNullable<ButtonVariantProps['tone']>;
export type ButtonSize = NonNullable<ButtonVariantProps['buttonSize']>;
