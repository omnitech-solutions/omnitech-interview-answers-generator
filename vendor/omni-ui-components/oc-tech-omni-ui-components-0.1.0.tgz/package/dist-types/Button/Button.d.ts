import { ButtonProps } from './Button.types';
import * as React from 'react';
/**
 * Omni Button — namespaced wrapper over the shadcn Button shape, with
 * Omni field-height tokens + design-system palette. Use this in place
 * of `components/ui/button` for any new omni-ui-components feature
 * surface so the look stays consistent with Input / Select / Slider.
 *
 * Configuration-driven variations: `tone` (+ `soft`), the `control` /
 * `control-labelled` sizes, `fillIcon`, `shortcut`, `loading`, `pressed`,
 * `labelMaxWidth` and `asChild`. Callbacks are ordinary props (`onClick`).
 *
 * @example
 * <Button variant="default" buttonSize="default" onClick={save}>Save</Button>
 * <Button variant="destructive" icon={<Trash2 />}>Delete</Button>
 * <Button buttonSize="control" tone="danger" soft onClick={end}>End session</Button>
 * <Button buttonSize="control" shortcut={['⌘', '⇧', 'S']}>Capture</Button>
 * <Button asChild><a href="/docs">Docs</a></Button>
 */
declare const ButtonInner: React.ForwardRefExoticComponent<ButtonProps & React.RefAttributes<HTMLButtonElement>>;
export declare const Button: typeof ButtonInner;
export {};
