import { SelectOption } from './Select.types';
/**
 * ISO-3166-1 alpha-2 country list, alphabetised by display name.
 * Used by Select demos + the kitchen-sink Country field so the dropdown
 * exercises a realistic dataset (200+ rows, scroll, search).
 */
export declare const COUNTRY_OPTIONS: SelectOption[];
