import { SelectProps } from './Select.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Select. Composes {@link SelectPrimitive} with
 * label / description / error rows via {@link FieldShell}.
 */
declare const SelectInner: React.ForwardRefExoticComponent<Omit<SelectProps, "ref"> & React.RefAttributes<HTMLSelectElement>>;
export declare const Select: typeof SelectInner;
export {};
