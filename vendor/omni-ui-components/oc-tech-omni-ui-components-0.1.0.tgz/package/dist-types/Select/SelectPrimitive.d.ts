import { SelectPrimitiveProps } from './Select.types';
import * as React from 'react';
/**
 * Raw Omni Select primitive — a searchable Popover + Command combobox
 * that mirrors `@rjsf/shadcn`'s `FancySelect` look (chevron trigger,
 * search input, scrollable list, checkmark on the selected row). Renders
 * a hidden native `<select>` for native form-submit + a11y, so the
 * controlled `value`/`onChange` contract matches Input + Textarea.
 *
 * Wrapped in `React.memo` so RJSF parent re-renders only touch fields
 * whose props actually changed.
 *
 * @example
 * <SelectPrimitive
 *   options={[{ value: 'US', label: 'United States' }, …]}
 *   placeholder="Select country…"
 *   value={country}
 *   onChange={setCountry}
 * />
 */
declare const SelectPrimitiveInner: React.ForwardRefExoticComponent<Omit<SelectPrimitiveProps, "ref"> & React.RefAttributes<HTMLSelectElement>>;
export declare const SelectPrimitive: typeof SelectPrimitiveInner;
export {};
