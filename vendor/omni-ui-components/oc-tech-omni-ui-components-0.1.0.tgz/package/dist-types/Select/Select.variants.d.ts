import { VariantProps } from 'class-variance-authority';
/**
 * Tailwind class config for the Select primitive. Shares the Input
 * variant + size scale so `<Select selectSize="md">` reads the same
 * metrics as `<Input inputSize="md">`. Tokens come from
 * `omni-ui-components/styles/tokens.css`.
 */
export declare const selectVariants: (props?: ({
    variant?: "bordered" | "ghost" | null | undefined;
    selectSize?: "default" | "sm" | "md" | "lg" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type SelectVariantProps = VariantProps<typeof selectVariants>;
export type SelectVariant = NonNullable<SelectVariantProps['variant']>;
export type SelectSize = NonNullable<SelectVariantProps['selectSize']>;
