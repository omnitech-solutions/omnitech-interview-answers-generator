import { InputPrimitiveProps } from '../Input/Input.types';
import * as React from 'react';
export interface PhoneInputPrimitiveProps extends Omit<InputPrimitiveProps, 'type' | 'inputMode' | 'value' | 'onChange'> {
    value?: string;
    onChange?: (next: string) => void;
    /** Default dial code (e.g. `+1`) — switches to international format. */
    defaultDialCode?: string;
}
declare const PhoneInputPrimitiveInner: React.ForwardRefExoticComponent<Omit<PhoneInputPrimitiveProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const PhoneInputPrimitive: typeof PhoneInputPrimitiveInner;
export {};
