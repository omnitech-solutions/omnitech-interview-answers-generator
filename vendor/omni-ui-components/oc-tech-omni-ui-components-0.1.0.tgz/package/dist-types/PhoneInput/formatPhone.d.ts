/**
 * Format a phone string into a human-friendly grouping as the user types.
 * - `+` prefix or `defaultDialCode` supplied → `+CC XXX XXX XXXX`
 * - otherwise (US-style)                      → `(XXX) XXX-XXXX`
 */
export declare const formatPhone: (raw: string, defaultDialCode?: string) => string;
