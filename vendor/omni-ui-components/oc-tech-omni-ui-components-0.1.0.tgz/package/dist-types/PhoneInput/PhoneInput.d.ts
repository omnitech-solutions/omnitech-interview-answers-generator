import { InputProps } from '../Input';
import * as React from 'react';
export { formatPhone } from './formatPhone';
export interface PhoneInputProps extends Omit<InputProps, 'type' | 'inputMode' | 'value' | 'onChange'> {
    value?: string;
    onChange?: (next: string) => void;
    /** Default dial code (e.g. `+1`). When set, formats as `+CC XXX XXX XXXX`. */
    defaultDialCode?: string;
}
/**
 * Omni PhoneInput — chrome-wrapped {@link PhoneInputPrimitive}.
 *
 * @example
 * <PhoneInput label="Phone" value={phone} onChange={setPhone} />
 */
declare const PhoneInputInner: React.ForwardRefExoticComponent<Omit<PhoneInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const PhoneInput: typeof PhoneInputInner;
