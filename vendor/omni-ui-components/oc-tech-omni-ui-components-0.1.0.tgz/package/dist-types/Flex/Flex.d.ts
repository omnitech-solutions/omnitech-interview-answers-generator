import type * as React from 'react';
export interface FlexProps extends React.HTMLAttributes<HTMLDivElement> {
    vertical?: boolean;
    gap?: number | string;
    align?: React.CSSProperties['alignItems'];
    justify?: React.CSSProperties['justifyContent'];
    wrap?: React.CSSProperties['flexWrap'];
}
export declare const Flex: ({ vertical, gap, align, justify, wrap, className, style, ...props }: FlexProps) => React.JSX.Element;
