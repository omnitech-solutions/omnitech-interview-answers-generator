import { DatePickerPrimitiveProps } from './DatePicker.types';
import * as React from 'react';
/**
 * Raw Omni DatePicker primitive — Popover-triggered Calendar.
 * Supports both single-date and date-range modes.
 *
 * @example
 * <DatePickerPrimitive value={date} onChange={setDate} placeholder="Pick a date" />
 * <DatePickerPrimitive mode="range" value={range} onChange={setRange} />
 */
declare const DatePickerPrimitiveInner: React.ForwardRefExoticComponent<DatePickerPrimitiveProps & React.RefAttributes<HTMLButtonElement>>;
export declare const DatePickerPrimitive: typeof DatePickerPrimitiveInner;
export {};
