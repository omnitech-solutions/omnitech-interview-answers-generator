import { DatePickerProps } from './DatePicker.types';
import * as React from 'react';
/** Chrome-wrapped Omni DatePicker (Popover + Calendar). Single or range mode. */
declare const DatePickerInner: React.ForwardRefExoticComponent<DatePickerProps & React.RefAttributes<HTMLButtonElement>>;
export declare const DatePicker: typeof DatePickerInner;
export {};
