import { ConversationItem } from '../ConversationList/ConversationList.types';
import { ConversationHeaderAction, ConversationHeaderLabels, ConversationHeaderProps, ConversationMenuItem } from './ConversationHeader.types';
import * as React from 'react';
/** English defaults of every string. Pass `labels` to translate any of them. */
export declare const DEFAULT_CONVERSATION_HEADER_LABELS: ConversationHeaderLabels;
/**
 * Omni ConversationHeader: the bar above a conversation. Leading buttons (history), the title as a menu button
 * (the library ActionMenu, rows from `menuItems` with `danger` and `separated`), inline rename (max 256, select-all on
 * open, Enter or blur commits, Escape cancels), the model control and the trailing icon buttons (new chat, expand,
 * settings, close with its shortcut in the tooltip). Everything is a prop; icons are caller nodes.
 *
 * Slots: `data-slot="conversation-header" | "conversation-title" | "conversation-rename"`.
 *
 * @example
 * <ConversationHeader title={thread.title} onRename={rename} menuIcon={<ChevronDown />}
 *   menuItems={[{ id: 'rename', label: 'Rename', startsRename: true }, { id: 'delete', label: 'Delete', danger: true, separated: true, onClick: remove }]}
 *   actions={[{ key: 'close', label: 'Close', shortcut: '⌘ J', icon: <X />, onClick: close }]} />
 */
export declare const ConversationHeader: <C extends ConversationItem = ConversationItem, M extends ConversationMenuItem<M> = ConversationMenuItem, A extends ConversationHeaderAction<A> = ConversationHeaderAction>({ conversation, menuItems, menuIcon, onRename, onRenameStart, onRenameCancel, maxLength, renaming: renamingProp, onHistoryToggle, historyIcon, historyShortcut, leading, modelControl, actions, trailing, labels: labelOverrides, className, "data-testid": testId, }: ConversationHeaderProps<C, M, A>) => React.JSX.Element;
