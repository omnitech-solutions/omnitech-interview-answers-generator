import { DictationBarProps } from './DictationBar.types';
import * as React from 'react';
/**
 * The dictation bar that replaces a composer's field while the microphone is listening: a pulsing record dot
 * (stacked variant), the live transcript or `Listening…` in a polite live region, a 20-bar CSS waveform
 * (`aria-hidden`, decorative) and Cancel and Done buttons. All animation stops under `prefers-reduced-motion`.
 * Wire `onDone` to append `text` to the draft and `onCancel` to discard it.
 * Slots: `data-slot="dictation-bar" | "dictation-record" | "dictation-text" | "dictation-wave" | "dictation-cancel" | "dictation-done"`.
 *
 * @example
 * <DictationBar text={heard} onCancel={cancel} onDone={finish} cancelIcon={<X />} doneIcon={<Check />} />
 */
export declare const DictationBar: React.ForwardRefExoticComponent<DictationBarProps & React.RefAttributes<HTMLDivElement>>;
