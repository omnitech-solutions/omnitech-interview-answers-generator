/** The bar replaces the field: same height and see-through background as the panel Input. */
export declare const dictationBarVariants: (props?: ({
    variant?: "stacked" | "pill" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export declare const dictationRecordClasses = "size-2 flex-none rounded-full bg-[color:var(--oui-tone-danger-solid-bg)] animate-[oui-record-pulse_1.2s_ease-in-out_infinite]";
export declare const dictationTextClasses = "min-w-0 flex-1 truncate";
export declare const dictationWaveClasses = "flex h-5 flex-none items-center gap-[2px]";
export declare const dictationBarClasses = "block h-full w-[2px] origin-center rounded-full bg-[color:var(--oui-tone-danger-fg)] animate-[oui-wave_0.9s_ease-in-out_infinite]";
