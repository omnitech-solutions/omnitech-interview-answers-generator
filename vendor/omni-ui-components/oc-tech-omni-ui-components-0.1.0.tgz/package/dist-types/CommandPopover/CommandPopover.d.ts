import { CommandItem, CommandPopoverProps } from './CommandPopover.types';
import * as React from 'react';
export declare const CommandPopover: <T extends CommandItem = CommandItem>(props: CommandPopoverProps<T> & {
    ref?: React.Ref<HTMLDivElement>;
}) => React.ReactElement | null;
