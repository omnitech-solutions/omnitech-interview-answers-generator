import { CommandItem, CommandTrigger } from './CommandPopover.types';
/** The slash trigger of the original: only when the WHOLE draft is `/word`. Group 1 is the word. */
export declare const SLASH_PATTERN: RegExp;
/** The `@` trigger of the original: an `@` at the start or after whitespace, to the end of the draft. Group 1 is the query. */
export declare const MENTION_PATTERN: RegExp;
/** The saved-prompts trigger: `/prompts` then a space, to the end of the draft. Group 1 is the search text (may be empty). */
export declare const SAVED_PROMPTS_PATTERN: RegExp;
/** Slash commands filter by prefix (`command.startsWith(query)`), as the original does. */
export declare const startsWithFilter: (item: {
    id: string;
}, query: string) => boolean;
/** A `/` trigger with the original's pattern and prefix filter; give it `source`, `onPick` and `popover` text. */
export declare const slashTrigger: <T extends CommandItem = CommandItem>(config: Omit<CommandTrigger<T>, "id" | "pattern"> & Partial<Pick<CommandTrigger<T>, "id" | "pattern">>) => CommandTrigger<T>;
/** An `@` trigger with the original's pattern; the default filter is `label contains query`. */
export declare const mentionTrigger: <T extends CommandItem = CommandItem>(config: Omit<CommandTrigger<T>, "id" | "pattern"> & Partial<Pick<CommandTrigger<T>, "id" | "pattern">>) => CommandTrigger<T>;
/**
 * A saved-prompts trigger: `/prompts ` then a search. Give it a `source` (an array filtered by label and description, or
 * `source(query)` sync or async, so a library can search a server) whose rows extend `CommandItem` with the prompt text, and an
 * `onPick` that receives the SAME row object back (put the text in the draft there).
 */
export declare const savedPromptsTrigger: <T extends CommandItem = CommandItem>(config: Omit<CommandTrigger<T>, "id" | "pattern"> & Partial<Pick<CommandTrigger<T>, "id" | "pattern">>) => CommandTrigger<T>;
