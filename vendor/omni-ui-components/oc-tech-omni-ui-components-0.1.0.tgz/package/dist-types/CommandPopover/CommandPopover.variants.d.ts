/**
 * The popover surface: an opaque panel above (or below) its relative parent. Opaque on purpose: it floats over
 * the log, so it uses the panel colour rather than the see-through mix.
 */
export declare const commandPopoverVariants: (props?: ({
    placement?: "inline" | "above" | "below" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export declare const commandPopoverTitleClasses = "px-3 pt-2 pb-1 text-[11px] font-medium tracking-wide text-[color:var(--oui-panel-meta-fg)] uppercase";
export declare const commandPopoverListClasses = "flex min-h-0 flex-1 flex-col overflow-y-auto p-1";
export declare const commandPopoverOptionClasses: string;
export declare const commandPopoverDescriptionClasses = "min-w-0 flex-1 truncate text-xs text-[color:var(--oui-panel-meta-fg)]";
export declare const commandPopoverEmptyClasses = "px-3 py-2 text-[13px] text-[color:var(--oui-panel-meta-fg)]";
export declare const commandPopoverHintClasses = "border-t border-solid border-[color:var(--oui-panel-divider)] px-3 py-1.5 text-[11px] text-[color:var(--oui-panel-meta-fg)]";
export declare const commandPopoverSearchClasses = "flex flex-none items-center gap-2 border-b border-solid border-[color:var(--oui-panel-divider)] px-3 py-2 text-[color:var(--oui-panel-meta-fg)] [&_svg]:size-4 [&_svg]:flex-none";
export declare const commandPopoverSearchInputClasses = "min-w-0 flex-1 appearance-none border-0 bg-transparent p-0 text-sm text-[color:var(--oui-foreground)] outline-none placeholder:text-[color:var(--oui-panel-meta-fg)]";
export declare const commandPopoverGroupLabelClasses = "px-2.5 pt-2 pb-1 text-[11px] font-medium text-[color:var(--oui-panel-meta-fg)]";
export declare const commandPopoverShortcutClasses = "ml-auto flex flex-none items-center gap-1 pl-2";
export declare const commandPopoverKeyClasses = "rounded border border-solid border-[color:var(--oui-panel-divider)] px-1 font-sans text-[11px] leading-4 text-[color:var(--oui-panel-meta-fg)]";
