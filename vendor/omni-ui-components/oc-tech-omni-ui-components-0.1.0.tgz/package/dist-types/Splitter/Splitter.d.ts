import { SplitterLabels, SplitterPanelProps, SplitterProps } from './Splitter.types';
import * as React from 'react';
/** English strings of {@link Splitter}. */
export declare const DEFAULT_SPLITTER_LABELS: SplitterLabels;
/**
 * One panel of a {@link Splitter}. A panel with a numeric `defaultSize` (px) has a size of its own and, in a
 * `resizable` splitter, a handle; a panel with none takes the room that is left.
 *
 * Slot: `data-slot="splitter-panel"`.
 */
export declare const SplitterPanel: {
    ({ defaultSize, minSize: _min, maxSize: _max, label: _label, style, ...props }: SplitterPanelProps): React.JSX.Element;
    displayName: string;
};
/**
 * Omni Splitter: panels side by side (or stacked). Static by default. With `resizable`, a handle sits between
 * panels: drag it, or focus it and use the arrow keys, Home and End; double-click (or Enter) puts that panel back
 * to its default size. Sizes are px by panel `id`, controlled (`sizes`) or kept inside (`defaultSizes`);
 * `onSizesChange` fires either way. A panel is never sized past its `minSize` / `maxSize` or past the room the
 * other panels leave. Change `resetKey` to put every panel back.
 *
 * Slots: `data-slot="splitter" | "splitter-panel" | "splitter-handle"`.
 *
 * @example
 * <Splitter resizable onSizesChange={save}>
 *   <SplitterPanel id="list" label="List" defaultSize={250} maxSize={360} />
 *   <SplitterPanel id="main" />
 *   <SplitterPanel id="side" label="Side" defaultSize={400} />
 * </Splitter>
 */
export declare const Splitter: {
    ({ className, children, resizable, orientation, sizes: sizesProp, defaultSizes, onSizesChange, onResizeStart, onResizeEnd, resetKey, keyboardStep, handleProps, labels: labelOverrides, ...props }: SplitterProps): React.JSX.Element;
    displayName: string;
};
