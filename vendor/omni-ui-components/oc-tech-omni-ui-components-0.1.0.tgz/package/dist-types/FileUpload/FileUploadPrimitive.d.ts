import * as React from 'react';
export interface FileUploadPrimitiveProps {
    id?: string;
    name?: string;
    value?: File[] | null;
    onChange?: (next: File[]) => void;
    accept?: string;
    multiple?: boolean;
    maxSize?: number;
    maxFiles?: number;
    onError?: (message: string) => void;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw drop-zone + file list (no chrome). */
export declare const FileUploadPrimitive: React.ForwardRefExoticComponent<FileUploadPrimitiveProps & React.RefAttributes<HTMLInputElement>>;
