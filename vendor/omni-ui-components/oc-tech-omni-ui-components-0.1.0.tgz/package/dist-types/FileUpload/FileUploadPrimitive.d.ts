import * as React from 'react';
/** Words of the drop zone, the file list and the refusals. */
export interface FileUploadLabels {
    prompt: string;
    /** The words of the compact button (`appearance="button"`). */
    choose: string;
    dropPrompt: string;
    anyType: string;
    accepted: (accept: string) => string;
    upTo: (size: string) => string;
    remove: (name: string) => string;
    tooLarge: (name: string, size: string) => string;
    tooMany: (max: number) => string;
    wrongType: (name: string) => string;
}
export declare const DEFAULT_FILE_UPLOAD_LABELS: FileUploadLabels;
/** Whether a file matches an `accept` list (`.pdf`, `image/*`, `text/plain`), as the browser's picker would. */
export declare const fileMatchesAccept: (file: File, accept: string | undefined) => boolean;
export interface FileUploadPrimitiveProps {
    id?: string;
    name?: string;
    value?: File[] | null;
    onChange?: (next: File[]) => void;
    accept?: string;
    multiple?: boolean;
    maxSize?: number;
    maxFiles?: number;
    onError?: (message: string) => void;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    labels?: Partial<FileUploadLabels>;
    /** `dropzone` (default): the large drop area. `button`: a compact button for a dense form; files can still be dropped on it. */
    appearance?: 'dropzone' | 'button';
    'aria-label'?: string;
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw drop-zone + file list (no chrome). */
export declare const FileUploadPrimitive: React.ForwardRefExoticComponent<FileUploadPrimitiveProps & React.RefAttributes<HTMLInputElement>>;
