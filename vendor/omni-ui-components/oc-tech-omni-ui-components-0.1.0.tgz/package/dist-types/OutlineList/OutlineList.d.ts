import { OutlineItem, OutlineListLabels, OutlineListProps } from './OutlineList.types';
import * as React from 'react';
/** English strings of {@link OutlineList}. */
export declare const DEFAULT_OUTLINE_LIST_LABELS: OutlineListLabels;
/** Generic over the item type: an extended item reaches `onValueChange` by reference. */
export declare const OutlineList: <T extends OutlineItem = OutlineItem>(props: OutlineListProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
