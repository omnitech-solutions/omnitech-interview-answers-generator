import { OutlineItem, OutlineListItemProps, OutlineListLabels, OutlineListProps } from './OutlineList.types';
import * as React from 'react';
/** English strings of {@link OutlineList}. */
export declare const DEFAULT_OUTLINE_LIST_LABELS: OutlineListLabels;
/**
 * One row of an {@link OutlineList}, usable on its own: a number, a label that wraps, a quiet meta line and an
 * optional `trailing` part (a `Tag`, a `Badge`). It is a button when `onSelect` is given, plain otherwise.
 *
 * Slots: `data-slot="outline-list-row" | "outline-list-number" | "outline-list-label" | "outline-list-meta" |
 * "outline-list-trailing"`.
 *
 * @example
 * <OutlineListItem item={question} number={3} current onSelect={(q) => open(q.id)} />
 */
export declare const OutlineListItem: <T extends OutlineItem = OutlineItem>({ item, number, current, live, onSelect, labels: labelOverrides, className, }: OutlineListItemProps<T>) => React.ReactElement;
/** Generic over the item type: an extended item reaches `onValueChange` and `renderItem` by reference. */
export declare const OutlineList: <T extends OutlineItem = OutlineItem>(props: OutlineListProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
