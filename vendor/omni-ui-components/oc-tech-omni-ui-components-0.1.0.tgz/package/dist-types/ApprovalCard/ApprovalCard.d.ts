import { ApprovalCardProps, ApprovalItem, ApprovalLabels } from './ApprovalCard.types';
import * as React from 'react';
/** English strings of {@link ApprovalCard}. */
export declare const DEFAULT_APPROVAL_LABELS: ApprovalLabels;
/** Generic over the item type: an extended item reaches every callback and slot by reference. */
export declare const ApprovalCard: <T extends ApprovalItem = ApprovalItem>(props: ApprovalCardProps<T> & React.RefAttributes<HTMLElement>) => React.ReactElement | null;
