export declare const approvalCardVariants: (props?: ({
    status?: "always" | "pending" | "once" | "denied" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
/** The shield badge: warning tint while pending is the caller's choice of icon; the tile is always warning-tinted. */
export declare const approvalBadgeClasses = "flex size-8 flex-none items-center justify-center rounded-[9px] bg-[color:var(--oui-tone-warning-bg)] text-[color:var(--oui-tone-warning-fg)] [&_svg]:size-[18px]";
