export declare const starterGridVariants: (props?: ({
    columns?: 1 | 2 | 3 | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export declare const STARTER_CARD_CLASS = "flex min-w-0 flex-col items-start gap-1 rounded-xl border border-solid border-[color:var(--oui-panel-border)] bg-[color:var(--oui-panel-bg)] p-3 text-left outline-none transition-colors hover:border-[color:var(--oui-tone-accent-border)] hover:bg-[color:var(--oui-tone-accent-bg)] focus-visible:ring-2 focus-visible:ring-ring/50 motion-reduce:transition-none";
