import { EmptyStartersLabels, EmptyStartersProps, StarterItem } from './EmptyStarters.types';
export declare const DEFAULT_EMPTY_STARTERS_LABELS: EmptyStartersLabels;
/**
 * Omni EmptyStarters: the empty conversation. A heading, an optional description and starter cards (`icon`, `title`,
 * `subtitle`, `prompt`); choosing a card calls `onStart(prompt)` so the app sends it. It fills its parent and centres,
 * so it drops into a Panel body or the PanelShell.
 *
 * Slots: `data-slot="empty-starters" | "empty-starters-title" | "empty-starters-grid" | "empty-starter"`.
 *
 * @example
 * <EmptyStarters title="What are we working on?" description="Ask anything about the interview."
 *   starters={[{ icon: <Sparkles />, title: 'Explain a concept', subtitle: 'Spoken in 60 seconds', prompt: 'Explain closures' }]}
 *   onStart={(prompt) => send(prompt)} />
 */
export declare const EmptyStarters: <S extends StarterItem = StarterItem>({ title, description, starters, onStart, columns, labels: labelOverrides, className, ...rest }: EmptyStartersProps<S>) => import("react").JSX.Element;
