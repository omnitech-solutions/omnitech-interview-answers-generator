import * as React from 'react';
export interface PaginationProps extends Omit<React.HTMLAttributes<HTMLElement>, 'onChange'> {
    current?: number;
    total: number;
    pageSize?: number;
    disabled?: boolean;
    showPrevNext?: boolean;
    showSizeChanger?: boolean;
    pageSizeOptions?: number[];
    onChange?: (page: number, pageSize: number) => void;
    onShowSizeChange?: (page: number, pageSize: number) => void;
    testIdPrefix?: string;
}
export declare const Pagination: ({ current, total, pageSize, disabled, showPrevNext, showSizeChanger, pageSizeOptions, onChange, onShowSizeChange, className, testIdPrefix, ...props }: PaginationProps) => React.JSX.Element;
