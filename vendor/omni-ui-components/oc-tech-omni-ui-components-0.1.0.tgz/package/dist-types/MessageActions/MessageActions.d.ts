import { MessageActionButton, MessageActionsProps } from './MessageActions.types';
import * as React from 'react';
/** Generic over the action item type: an extended action reaches its `onClick` by reference. */
export declare const MessageActions: <T extends MessageActionButton = MessageActionButton>(props: MessageActionsProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
