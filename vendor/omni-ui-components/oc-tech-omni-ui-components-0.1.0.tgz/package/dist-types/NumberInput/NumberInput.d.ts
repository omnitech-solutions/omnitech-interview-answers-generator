import { NumberInputProps } from './NumberInput.types';
import * as React from 'react';
/** Chrome-wrapped Omni NumberInput. */
declare const NumberInputInner: React.ForwardRefExoticComponent<NumberInputProps & React.RefAttributes<HTMLInputElement>>;
export declare const NumberInput: typeof NumberInputInner;
export {};
