import { NumberInputPrimitiveProps } from './NumberInput.types';
import * as React from 'react';
/**
 * Raw Omni NumberInput primitive — formatted numeric input with
 * optional prefix / suffix, thousand separators, and decimal control.
 *
 * Uncontrolled internally (raw text state) so the user can type a partial
 * value like `"-"` or `"1."` without it getting clobbered. Emits a
 * parsed `number | null` via `onChange`.
 *
 * @example
 * <NumberInputPrimitive value={amount} onChange={setAmount} prefix="$" thousandSeparator />
 */
declare const NumberInputPrimitiveInner: React.ForwardRefExoticComponent<NumberInputPrimitiveProps & React.RefAttributes<HTMLInputElement>>;
export declare const NumberInputPrimitive: typeof NumberInputPrimitiveInner;
export {};
