import { NumberInputProps } from '../NumberInput';
import * as React from 'react';
export interface CurrencyInputProps extends Omit<NumberInputProps, 'prefix' | 'thousandSeparator'> {
    /** ISO 4217 code (e.g. `USD`, `EUR`). Default `USD`. */
    currency?: string;
    /** Locale. */
    locale?: string;
    /** Decimal places. Default 2. */
    decimals?: number;
}
/**
 * Omni CurrencyInput — chrome-wrapped {@link CurrencyInputPrimitive}.
 *
 * @example
 * <CurrencyInput label="Amount" currency="USD" value={amount} onChange={setAmount} />
 */
declare const CurrencyInputInner: React.ForwardRefExoticComponent<CurrencyInputProps & React.RefAttributes<HTMLInputElement>>;
export declare const CurrencyInput: typeof CurrencyInputInner;
export {};
