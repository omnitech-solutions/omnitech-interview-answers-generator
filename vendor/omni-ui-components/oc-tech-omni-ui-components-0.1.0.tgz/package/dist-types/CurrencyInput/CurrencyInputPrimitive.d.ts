import { NumberInputPrimitiveProps } from '../NumberInput/NumberInput.types';
import * as React from 'react';
export interface CurrencyInputPrimitiveProps extends Omit<NumberInputPrimitiveProps, 'prefix' | 'thousandSeparator'> {
    /** ISO 4217 code (e.g. `USD`, `EUR`). Default `USD`. */
    currency?: string;
    /** Locale for symbol + thousand separator. */
    locale?: string;
    /** Decimal places. Default 2. */
    decimals?: number;
}
declare const CurrencyInputPrimitiveInner: React.ForwardRefExoticComponent<CurrencyInputPrimitiveProps & React.RefAttributes<HTMLInputElement>>;
export declare const CurrencyInputPrimitive: typeof CurrencyInputPrimitiveInner;
export {};
