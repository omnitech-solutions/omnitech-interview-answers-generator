import { QueuedItem, QueuedListProps } from './QueuedList.types';
import * as React from 'react';
export declare const QueuedList: <T extends QueuedItem = QueuedItem>(props: QueuedListProps<T> & {
    ref?: React.Ref<HTMLUListElement>;
}) => React.ReactElement | null;
