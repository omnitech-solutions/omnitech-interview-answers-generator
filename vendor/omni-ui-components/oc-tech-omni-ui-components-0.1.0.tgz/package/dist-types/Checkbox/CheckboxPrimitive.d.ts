import { CheckboxPrimitiveProps } from './Checkbox.types';
import * as React from 'react';
/**
 * Raw Omni single-checkbox primitive. Composes Radix
 * `@radix-ui/react-checkbox` so the markup is `button[role=checkbox]`
 * (full keyboard / a11y support) while the visual chrome matches the
 * Omni checkbox spec:
 *
 * - **Unchecked**: rounded-square with `border-muted-foreground/60`,
 *   transparent fill; hover darkens the border to the primary color.
 * - **Checked**: solid `bg-primary` with white check icon and primary
 *   border.
 *
 * Wrapped in `React.memo` so RJSF parent re-renders only touch fields
 * whose props actually changed.
 */
declare const CheckboxPrimitiveInner: React.ForwardRefExoticComponent<CheckboxPrimitiveProps & React.RefAttributes<HTMLButtonElement>>;
export declare const CheckboxPrimitive: typeof CheckboxPrimitiveInner;
export {};
