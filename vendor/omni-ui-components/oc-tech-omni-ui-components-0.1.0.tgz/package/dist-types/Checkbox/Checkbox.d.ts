import { CheckboxProps } from './Checkbox.types';
import * as React from 'react';
/**
 * Chrome-wrapped single Omni Checkbox. Composes {@link CheckboxPrimitive}
 * with an inline label + optional description; the whole row is a
 * `<label>` so clicking anywhere toggles the checkbox.
 *
 * @example
 * <Checkbox
 *   label="Subscribe to product updates"
 *   description="Once a week, no spam."
 *   checked={subscribed}
 *   onChange={setSubscribed}
 * />
 */
declare const CheckboxInner: React.ForwardRefExoticComponent<CheckboxProps & React.RefAttributes<HTMLButtonElement>>;
export declare const Checkbox: typeof CheckboxInner;
export {};
