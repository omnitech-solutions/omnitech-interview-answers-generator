import { CheckboxGroupProps } from './Checkbox.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni checkbox group. Composes
 * {@link CheckboxGroupPrimitive} with {@link FieldShell}.
 */
declare const CheckboxGroupInner: React.ForwardRefExoticComponent<CheckboxGroupProps & React.RefAttributes<HTMLDivElement>>;
export declare const CheckboxGroup: typeof CheckboxGroupInner;
export {};
