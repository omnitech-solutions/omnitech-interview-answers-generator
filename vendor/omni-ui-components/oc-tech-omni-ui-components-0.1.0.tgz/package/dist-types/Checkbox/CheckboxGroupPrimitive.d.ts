import { CheckboxGroupPrimitiveProps } from './Checkbox.types';
import * as React from 'react';
/**
 * Raw Omni checkbox group primitive — a list of {@link CheckboxPrimitive}
 * items with per-option label/description rows. Whole row is clickable
 * (each item wraps its checkbox in a `<label>`).
 *
 * Defaults to `vertical` orientation; pass `orientation="horizontal"` for
 * inline layout (mirrors RJSF's `ui:options.inline=true`).
 */
declare const CheckboxGroupPrimitiveInner: React.ForwardRefExoticComponent<CheckboxGroupPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
export declare const CheckboxGroupPrimitive: typeof CheckboxGroupPrimitiveInner;
export {};
