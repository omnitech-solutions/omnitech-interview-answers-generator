import { DividerProps } from './Divider.types';
import * as React from 'react';
declare const DividerInner: React.ForwardRefExoticComponent<DividerProps & React.RefAttributes<HTMLDivElement>>;
export declare const Divider: typeof DividerInner;
export {};
