import { DiffChange, DiffReviewLabels, DiffReviewProps } from './DiffReview.types';
import * as React from 'react';
/** English defaults for every string. Pass a partial `labels` to translate or rephrase. */
export declare const DEFAULT_DIFF_REVIEW_LABELS: DiffReviewLabels;
/** Generic over the change type: extra fields on your changes reach every callback by reference. */
export declare const DiffReview: <C extends DiffChange = DiffChange>(props: DiffReviewProps<C> & React.RefAttributes<HTMLElement>) => React.ReactElement | null;
