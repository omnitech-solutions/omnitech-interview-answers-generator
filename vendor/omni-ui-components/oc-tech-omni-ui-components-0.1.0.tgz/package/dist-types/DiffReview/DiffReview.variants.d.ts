import { VariantProps } from 'class-variance-authority';
/** The card: a bordered panel surface. */
export declare const diffReviewClasses = "min-w-0 overflow-hidden rounded-xl border border-solid border-[color:var(--oui-panel-border)] bg-[color:var(--oui-panel-bg)] text-[13px] text-[color:var(--oui-foreground)]";
/** The status pill, tinted from the tone tokens. Written out in full for Tailwind's source scan. */
export declare const diffReviewPillVariants: (props?: ({
    status?: "pending" | "preview" | "applied" | "rejected" | "reverted" | "conflicted" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type DiffReviewPillVariantProps = VariantProps<typeof diffReviewPillVariants>;
/** A diff row: a tinted band for added and removed lines. */
export declare const diffRowVariants: (props?: ({
    kind?: "add" | "remove" | "context" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type DiffRowVariantProps = VariantProps<typeof diffRowVariants>;
/** The +/- gutter cell of a row. */
export declare const diffSignVariants: (props?: ({
    kind?: "add" | "remove" | "context" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export declare const diffAddClasses = "font-mono text-[11.5px] text-[color:var(--oui-tone-success-fg)]";
export declare const diffRemoveClasses = "font-mono text-[11.5px] text-[color:var(--oui-tone-danger-fg)]";
export declare const diffTabClasses: string;
/** The checklist toggle: a box that shows a CSS check while ticked (no icon set needed). */
export declare const diffCheckClasses: string;
