import { DiffRow, DiffRowsOptions, DiffStats } from './DiffReview.types';
/** Added and removed line counts between two texts. */
export declare function diffStats(before: string, after: string): DiffStats;
/** The sum of the stats of several changes. */
export declare const sumStats: (changes: readonly {
    before: string;
    after: string;
}[]) => DiffStats;
/**
 * The rows of a unified diff: every changed line plus `contextLines` unchanged lines on each side, with one `gap`
 * row wherever lines were left out. Tokens come from the highlighter when given, else one plain token per line.
 */
export declare function diffRows(before: string, after: string, { highlight, language, contextLines }?: DiffRowsOptions): DiffRow[];
