import { SettingsDialogLabels, SettingsDialogProps, SettingsTab } from './SettingsDialog.types';
import * as React from 'react';
export declare const DEFAULT_SETTINGS_DIALOG_LABELS: SettingsDialogLabels;
/**
 * Omni SettingsDialog: the library Modal (Radix Dialog) with a vertical tablist on the left and the active tab's
 * panel on the right. Focus is trapped inside while open and returns to the control that was focused before it
 * opened; Escape and the backdrop call `onClose`. Tabs follow the WAI-ARIA tabs pattern: Up / Down / Home / End move
 * focus and select, only the active tab is in the tab order.
 *
 * Tabs are data (`tabs[{ id, label, icon, render }]`); the shown tab is `activeTab` (controlled) or kept inside.
 *
 * Slots: `data-slot="settings-dialog" | "settings-nav" | "settings-tab" | "settings-body" | "settings-content"`.
 *
 * @example
 * <SettingsDialog open={open} onClose={() => setOpen(false)} tabs={[{ id: 'general', label: 'General', icon: <Sliders />, render: () => <General /> }]} />
 */
export declare const SettingsDialog: <Tab extends SettingsTab<Tab> = SettingsTab>({ open, onClose, tabs, activeTab, defaultTab, onTabChange, closeIcon, container, labels: labelOverrides, className, "data-testid": testId, }: SettingsDialogProps<Tab>) => React.JSX.Element | null;
