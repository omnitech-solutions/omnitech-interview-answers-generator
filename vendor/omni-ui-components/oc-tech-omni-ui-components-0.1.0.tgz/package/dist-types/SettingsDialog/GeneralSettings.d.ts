import { GeneralSettingsLabels, GeneralSettingsProps } from './SettingsDialog.types';
export declare const DEFAULT_GENERAL_SETTINGS_LABELS: GeneralSettingsLabels;
/**
 * The General tab of the settings dialog: Theme (Segmented), Send with Enter (Switch) and the shortcut list. Both
 * values work controlled or uncontrolled and fire their change callback either way; a row whose callback is absent
 * is not rendered.
 *
 * @example
 * <GeneralSettings theme={theme} onThemeChange={setTheme} onSendOnEnterChange={setSend} shortcuts={shortcuts} />
 */
export declare const GeneralSettings: ({ theme: themeProp, defaultTheme, onThemeChange, themeOptions, sendOnEnter: sendProp, defaultSendOnEnter, onSendOnEnterChange, shortcuts, labels: labelOverrides, }: GeneralSettingsProps) => import("react").JSX.Element;
