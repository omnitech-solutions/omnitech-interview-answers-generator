export declare const settingRowVariants: (props?: ({
    tone?: "danger" | "plain" | "boxed" | null | undefined;
    layout?: "inline" | "stack" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export declare const SETTINGS_TAB_CLASS = "flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[13px] outline-none transition-colors hover:bg-[color:var(--oui-tone-neutral-bg)] focus-visible:ring-2 focus-visible:ring-ring/50 aria-selected:bg-[color:var(--oui-tone-accent-bg)] aria-selected:font-medium aria-selected:text-[color:var(--oui-tone-accent-fg)] motion-reduce:transition-none [&_svg]:size-4";
