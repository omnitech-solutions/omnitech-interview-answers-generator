import { SettingRowProps } from './SettingsDialog.types';
/**
 * One setting: a title, an optional description and a control. `tone="boxed"` draws it as a card, `tone="danger"`
 * as a destructive card; `layout="stack"` puts the control under the text (a textarea, a list). Use the library
 * Switch, Segmented or Button as the control.
 *
 * @example
 * <SettingRow title="Send with Enter" description="Shift+Enter adds a new line"><Switch aria-label="Send with Enter" checked={on} onChange={setOn} /></SettingRow>
 */
export declare const SettingRow: ({ title, description, tone, layout, htmlFor, children, className, }: SettingRowProps) => import("react").JSX.Element;
