import { VariantProps } from 'class-variance-authority';
/**
 * Classes of one Rate mark (the `role="radio"` button). The filled mark is drawn in the warning tone: the solid
 * colour inside, the tone's text colour as the outline, so the shape keeps its contrast on a light surface.
 *
 * @example
 * <button className={rateMarkVariants({ size: 'lg', filled: true })} />
 */
export declare const rateMarkVariants: (props?: ({
    size?: "default" | "sm" | "md" | "lg" | null | undefined;
    filled?: boolean | null | undefined;
    interactive?: boolean | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type RateSize = NonNullable<VariantProps<typeof rateMarkVariants>['size']>;
