import * as React from 'react';
export interface RateProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    count?: number;
    value?: number;
    defaultValue?: number;
    disabled?: boolean;
    onChange?: (value: number) => void;
    /** Names a star for assistive technology. Defaults to `1 star`, `2 stars`, … */
    starLabel?: (value: number, count: number) => string;
}
export declare function Rate({ count, value, defaultValue, disabled, onChange, starLabel, className, ...props }: RateProps): React.JSX.Element;
