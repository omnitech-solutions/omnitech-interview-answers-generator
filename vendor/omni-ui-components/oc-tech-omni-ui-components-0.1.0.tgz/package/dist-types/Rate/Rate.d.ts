import * as React from 'react';
export interface RateProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    count?: number;
    value?: number;
    defaultValue?: number;
    disabled?: boolean;
    onChange?: (value: number) => void;
}
export declare function Rate({ count, value, defaultValue, disabled, onChange, className, ...props }: RateProps): React.JSX.Element;
