import { RateProps } from './Rate.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Rate. Composes {@link RatePrimitive} with {@link FieldShell}: the label names the radio
 * group, the description and the error describe it.
 *
 * @example
 * <Rate label="Answer quality" description="How well did it land?" value={score} onChange={setScore} />
 */
declare const RateInner: React.ForwardRefExoticComponent<RateProps & React.RefAttributes<HTMLDivElement>>;
export declare const Rate: typeof RateInner;
export {};
