import { RatePrimitiveProps } from './Rate.types';
import * as React from 'react';
/**
 * Raw Omni Rate primitive: a `radiogroup` of marks. The mark equal to the value is the checked radio; marks up to
 * it are drawn filled. One tab stop; Left / Down lower, Right / Up raise, Home and End jump to the ends, and the
 * value follows focus as in any radio group. Activating the current value again clears it (`allowClear`).
 *
 * @example
 * <RatePrimitive aria-label="Score" defaultValue={3} onChange={(next) => save(next)} />
 */
declare const RatePrimitiveInner: React.ForwardRefExoticComponent<RatePrimitiveProps & React.RefAttributes<HTMLDivElement>>;
export declare const RatePrimitive: typeof RatePrimitiveInner;
export {};
