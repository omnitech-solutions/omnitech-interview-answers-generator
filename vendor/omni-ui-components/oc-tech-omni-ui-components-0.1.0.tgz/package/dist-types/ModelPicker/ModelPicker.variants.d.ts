/** The menu surface; the library popover supplies position, portal and animation. */
export declare const modelMenuClasses = "w-[340px] max-w-[calc(100vw-24px)] max-h-[70vh] overflow-y-auto p-1.5 text-[13px]";
export declare const modelGroupLabelClasses = "flex items-center gap-1.5 px-2.5 pt-2 pb-1 text-[11.5px] font-medium text-[color:var(--oui-panel-meta-fg)]";
export declare const modelRowClasses: string;
export declare const modelTagClasses = "rounded-full bg-[color:var(--oui-panel-dock-bg)] px-1.5 py-px text-[10.5px] leading-4 text-[color:var(--oui-panel-meta-fg)]";
export declare const modelChipClasses = "max-w-[220px] gap-1 px-2 text-[12.5px] font-medium text-[color:var(--oui-panel-meta-fg)] [&_svg]:size-3.5";
