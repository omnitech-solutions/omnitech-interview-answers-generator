import { ModelInfo, ModelMenuProps, ModelPickerLabels, ModelPickerProps } from './ModelPicker.types';
import * as React from 'react';
/** English defaults for every string. */
export declare const DEFAULT_MODEL_PICKER_LABELS: ModelPickerLabels;
/** Generic over the model type: extra fields on your models reach `onPick` and `onEffortChange` by reference. */
export declare const ModelMenu: <M extends ModelInfo = ModelInfo>(props: ModelMenuProps<M> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
/** Generic over the model type: extra fields on your models reach every callback by reference. */
export declare const ModelPicker: <M extends ModelInfo = ModelInfo>(props: ModelPickerProps<M> & React.RefAttributes<HTMLButtonElement>) => React.ReactElement | null;
