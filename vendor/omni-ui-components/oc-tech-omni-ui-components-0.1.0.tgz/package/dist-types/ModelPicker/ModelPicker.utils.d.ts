import { ModelCapabilityLabels, ModelGroup, ModelInfo, ModelPickerLabels, ModelProvider, ReasoningEffort } from './ModelPicker.types';
export declare const DEFAULT_MODEL_CAPABILITY_LABELS: ModelCapabilityLabels;
export declare const DEFAULT_EFFORT_LABELS: Record<ReasoningEffort, string>;
export declare const EFFORT_ORDER: readonly ReasoningEffort[];
/** `1_000_000` → `1M`, otherwise thousands (1024 per k, as model cards quote windows): `262144` → `256k`. */
export declare function formatWindow(count: number): string;
/** The chip name of a model: its short name, else its name, else nothing. */
export declare const shortName: (model: ModelInfo | undefined) => string;
/** `DeepSeek R1 · Medium` for a reasoning model, its short name otherwise; empty without a model. */
export declare function modelLabel(model: ModelInfo | undefined, effort: string, effortLabels?: Record<string, string>): string;
/**
 * What the model can do in plain words: `262k context · tools · vision · reasoning · 30B`. Parts that do not apply
 * are left out; a model with none gives an empty string.
 */
export declare function capabilitiesOf(model: ModelInfo, labels?: ModelCapabilityLabels): string;
/**
 * Consecutive models from the same provider form one group, in listing order; the same provider listed twice with
 * another between stays two groups. Models without their own provider belong to `fallback`.
 */
export declare function groupModels<M extends ModelInfo>(models: readonly M[], fallback?: ModelProvider): ModelGroup<M>[];
/** The `labels` with defaults filled (a partial `capabilities` or `efforts` keeps the rest). */
export declare const withLabelDefaults: (defaults: ModelPickerLabels, labels?: Partial<ModelPickerLabels>) => ModelPickerLabels;
