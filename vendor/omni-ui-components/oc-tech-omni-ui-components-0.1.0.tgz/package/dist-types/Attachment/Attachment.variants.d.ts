/**
 * The attachment card: a bordered row, at most 220px wide. Backgrounds follow `--oui-panel-see-through` the way the
 * panel Input does (the dock colour mixed with the token), so a card sits on a see-through Panel; text stays opaque.
 */
export declare const attachmentCardVariants: (props?: ({
    variant?: "card" | "chip" | null | undefined;
    status?: "ready" | "uploading" | "extracting" | "failed" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
/** The 32px thumbnail tile: an image fills it, an icon centres in it. */
export declare const attachmentThumbClasses = "flex size-8 flex-none items-center justify-center overflow-hidden rounded-md bg-[color:var(--oui-tone-accent-bg)] text-[color:var(--oui-tone-accent-fg)] [&_svg]:size-4";
/** Name and meta stack. */
export declare const attachmentTextClasses = "flex min-w-0 flex-1 flex-col text-left leading-[1.25]";
export declare const attachmentNameClasses = "truncate text-[12.5px] font-medium";
export declare const attachmentMetaClasses = "truncate text-[11px] text-[color:var(--oui-panel-meta-fg)]";
export declare const attachmentErrorClasses = "truncate text-[11px] text-[color:var(--oui-tone-danger-fg)]";
/** Progress track under the card; the bar width is inline (`progress`). Never animates when motion is reduced. */
export declare const attachmentProgressTrackClasses = "absolute inset-x-1.5 bottom-0 h-0.5 overflow-hidden rounded-full bg-[color:var(--oui-panel-divider)]";
export declare const attachmentProgressBarClasses = "block h-full bg-[color:var(--oui-tone-accent-solid-bg)] transition-[width] duration-200 motion-reduce:transition-none";
/** An upload with no known progress: a sliding bar. */
export declare const attachmentIndeterminateClasses = "block h-full w-1/3 bg-[color:var(--oui-tone-accent-solid-bg)] animate-pulse motion-reduce:animate-none";
export declare const attachmentStripVariants: (props?: ({
    layout?: "scroll" | "wrap" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
/** The drop overlay: a dashed accent frame over the container that says where to drop. */
export declare const attachmentDropOverlayClasses: string;
