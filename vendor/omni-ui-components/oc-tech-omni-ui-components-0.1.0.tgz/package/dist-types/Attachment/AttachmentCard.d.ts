import { AttachmentCardProps, AttachmentItem } from './Attachment.types';
import * as React from 'react';
export declare const AttachmentCard: <T extends AttachmentItem = AttachmentItem>(props: AttachmentCardProps<T> & {
    ref?: React.Ref<HTMLDivElement>;
}) => React.ReactElement | null;
