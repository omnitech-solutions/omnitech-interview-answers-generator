import { AttachmentLabels } from './Attachment.types';
import { AttachmentDropOptions, useAttachmentDrop } from './use-attachments';
import type * as React from 'react';
export interface AttachmentDropzoneProps extends AttachmentDropOptions, Omit<React.HTMLAttributes<HTMLDivElement>, 'onDrop' | 'children'> {
    labels?: Partial<Pick<AttachmentLabels, 'dropHere'>>;
    /** Receives the hook's result so a child can use `onPaste`, `inputProps` and `openPicker` (the picker input is rendered for you). */
    children: React.ReactNode | ((drop: ReturnType<typeof useAttachmentDrop>) => React.ReactNode);
}
/**
 * A container that accepts dropped files and shows a drop overlay (`labels.dropHere`) while a file is dragged over it.
 * It renders the hidden file `<input>` too, so a child only has to call `drop.openPicker()`. Pass a function as
 * `children` to receive `drop` (`onPaste` for the textarea, `openPicker`, `addFiles`).
 * Slots: `data-slot="attachment-dropzone" | "attachment-drop-overlay"`; `data-dragging` is set while dragging.
 *
 * @example
 * <AttachmentDropzone current={files.length} onFiles={add} onReject={toast}>
 *   {(drop) => <Composer onPaste={drop.onPaste} … />}
 * </AttachmentDropzone>
 */
export declare function AttachmentDropzone({ children, labels, className, current, accept, maxFiles, maxBytes, onFiles, onReject, disabled, ...rest }: AttachmentDropzoneProps): React.JSX.Element;
