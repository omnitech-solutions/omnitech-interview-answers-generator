import { AttachmentItem, AttachmentStripProps } from './Attachment.types';
import * as React from 'react';
export declare const AttachmentStrip: <T extends AttachmentItem = AttachmentItem>(props: AttachmentStripProps<T> & {
    ref?: React.Ref<HTMLDivElement>;
}) => React.ReactElement | null;
