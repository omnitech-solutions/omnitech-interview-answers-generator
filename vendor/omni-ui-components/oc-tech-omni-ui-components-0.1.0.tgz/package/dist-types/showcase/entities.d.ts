export declare const NEW_COMPANY_OPTION = "__new__";
export declare const NEW_CONTACT_OPTION = "__new__";
export interface CompanyEntity {
    id: string;
    name: string;
    domain: string;
    initials: string;
    color: string;
    avatarUrl: string | null;
    description: string;
    industry: string;
}
export interface ContactEntity {
    id: string;
    name: string;
    email: string;
    phoneNumber: string;
    initials: string;
    avatarUrl: string | null;
    jobTitle: string;
}
export interface MemberEntity {
    id: string;
    name: string;
    initials: string;
    color: string | null;
    group: 'PROJECT TEAM' | 'TEAM MEMBERS';
}
export interface ProjectEntity {
    id: string;
    name: string;
    organization: string;
    color: string;
    icon: string;
}
export interface TaskEntity {
    id: string;
    name: string;
}
export interface TaxRateEntity {
    id: string;
    label: string;
    percent: number;
}
export interface ExpenseCategoryEntity {
    id: string;
    label: string;
    group: 'ADS & MARKETING' | 'COGS' | 'COMMISSIONS & FEES';
}
export declare const SHOWCASE_COMPANIES: CompanyEntity[];
export declare const SHOWCASE_CONTACTS: ContactEntity[];
export declare const SHOWCASE_MEMBERS: MemberEntity[];
export declare const SHOWCASE_PROJECTS: ProjectEntity[];
export declare const SHOWCASE_TASKS: TaskEntity[];
export declare const SHOWCASE_TAX_RATES: TaxRateEntity[];
export declare const SHOWCASE_EXPENSE_CATEGORIES: ExpenseCategoryEntity[];
