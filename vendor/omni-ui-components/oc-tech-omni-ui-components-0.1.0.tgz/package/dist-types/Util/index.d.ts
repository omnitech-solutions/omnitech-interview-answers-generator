export declare const warning: (condition: unknown, message: string) => void;
export declare const isNil: (value: unknown) => value is null | undefined;
export declare const clamp: (value: number, min: number, max: number) => number;
