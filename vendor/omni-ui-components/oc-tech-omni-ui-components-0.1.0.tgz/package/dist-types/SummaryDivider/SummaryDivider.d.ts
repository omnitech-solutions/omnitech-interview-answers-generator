import { SummaryDividerLabels, SummaryDividerProps } from './SummaryDivider.types';
import * as React from 'react';
/** English strings of {@link SummaryDivider}. */
export declare const DEFAULT_SUMMARY_DIVIDER_LABELS: SummaryDividerLabels;
/**
 * Omni SummaryDivider: a rule in the conversation where the model's full view begins, with a disclosure
 * (`aria-expanded`) "N earlier messages summarised" that reveals the summary text and a note.
 *
 * Slots: `data-slot="summary-divider" | "summary-divider-toggle" | "summary-divider-body"`.
 *
 * @example
 * <SummaryDivider count={12} text={summary.text} icon={<ListCollapse />} chevron={<ChevronDown />} />
 */
export declare const SummaryDivider: React.ForwardRefExoticComponent<SummaryDividerProps & React.RefAttributes<HTMLDivElement>>;
