export type Selector<T, V> = keyof T | ((item: T) => V);
export type ProjectMapping<T, R> = {
    [K in keyof R]: Selector<T, R[K]>;
};
export declare const pluck: <T, V>(item: T, selector: Selector<T, V>) => V;
export declare const project: <T, R extends Record<string, unknown>>(items: readonly T[], mapping: ProjectMapping<T, R>) => R[];
