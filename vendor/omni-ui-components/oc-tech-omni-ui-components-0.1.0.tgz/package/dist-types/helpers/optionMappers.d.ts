import { OmniSelectOption } from '../dynamic-form/lib/formContext';
import { ProjectMapping } from './project';
export { pluck, project } from './project';
export interface FormOption {
    value: string;
    label: string;
}
export declare const selectOptions: <T>(items: readonly T[], mapping: Partial<ProjectMapping<T, OmniSelectOption>>) => OmniSelectOption[];
export declare const formOptions: <T extends {
    id: string;
}>(items: readonly T[], mapping?: ProjectMapping<T, FormOption>) => FormOption[];
