import { StatusClockProps } from './StatusClock.types';
import * as React from 'react';
/**
 * Omni StatusClock: the live-session status of the footer. A caller-supplied icon node (the filled record
 * icon), a monospace elapsed timer the caller has already formatted, and a `live | paused` state. Paused
 * swaps in the amber pause icon, turns the timer amber and adds a "Paused" label; nothing else changes
 * colour. An optional `buildTag` renders `<commit icon> <short sha> · <branch icon> <branch>` in mono after a divider, click to copy
 * (`copied` is controlled; the caller decides it is a development build and only passes it then).
 *
 * @example
 * <StatusClock state="paused" elapsed="2:18:20" icon={<RecordIcon />} pausedIcon={<PauseCircleIcon />}
 *   buildTag={{ sha: 'a1b2c3d', branch: 'main', commitIcon: <GitCommit />, branchIcon: <GitBranch />, title: 'a1b2c3d4e5f6…', onCopy: copySha, copied }} />
 */
export declare const StatusClock: React.ForwardRefExoticComponent<StatusClockProps & React.RefAttributes<HTMLDivElement>>;
