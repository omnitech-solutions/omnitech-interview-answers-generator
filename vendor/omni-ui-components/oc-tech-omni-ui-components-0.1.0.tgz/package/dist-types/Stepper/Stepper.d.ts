import { StepperProps } from './Stepper.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Stepper. Composes {@link StepperPrimitive} with a
 * label / description / error stack via {@link FieldShell}.
 */
declare const StepperInner: React.ForwardRefExoticComponent<StepperProps & React.RefAttributes<HTMLDivElement>>;
export declare const Stepper: typeof StepperInner;
export {};
