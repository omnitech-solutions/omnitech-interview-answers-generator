import { StepperPrimitiveProps } from './Stepper.types';
import * as React from 'react';
/**
 * Raw Omni Stepper primitive — pill-shaped row with optional leading
 * icon, value display, and minus/plus buttons. Used standalone, or
 * wrapped by `{@link Stepper}` for label / description / error chrome.
 *
 * Defaults: `min=0`, `max=Infinity`, `step=1`. Buttons respect bounds
 * (decrement disabled at `min`, increment at `max`).
 *
 * @example
 * <StepperPrimitive icon={<FileText />} unit="page" value={pages} onChange={setPages} min={1} max={50} />
 */
declare const StepperPrimitiveInner: React.ForwardRefExoticComponent<StepperPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
export declare const StepperPrimitive: typeof StepperPrimitiveInner;
export {};
