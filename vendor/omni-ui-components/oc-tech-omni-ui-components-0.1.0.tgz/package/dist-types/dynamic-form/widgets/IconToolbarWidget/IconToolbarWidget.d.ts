import { IconButtonVariant } from '../../../index.ts';
import { WidgetProps } from '@rjsf/utils';
/**
 * One entry of `ui:options.actions`: plain data. It names an action; the host supplies the action itself (its
 * words, its icon node and what it does) in `formContext.actions[actionKey]`. No function and no icon name ever
 * sits in a schema.
 */
export interface IconToolbarAction {
    actionKey: string;
    variant?: IconButtonVariant;
}
/**
 * `iconToolbar`: a row of actions that belong to the form (duplicate, clear, delete). It holds no value and
 * nothing is submitted. An entry whose key the host did not supply is not drawn; an action with no icon is
 * drawn as a text button; an action with an `href` and no `onSelect` is a link.
 *
 * @example
 * uiSchema: { quick: { 'ui:widget': 'iconToolbar', 'ui:options': { actions: [{ actionKey: 'duplicate', variant: 'ghost' }] } } }
 * formContext: { actions: { duplicate: { actionId: 'duplicate', label: 'Duplicate', href: null, icon: <Copy />, onSelect: duplicate } } }
 */
export declare const IconToolbarWidget: (props: WidgetProps) => import("react").JSX.Element;
