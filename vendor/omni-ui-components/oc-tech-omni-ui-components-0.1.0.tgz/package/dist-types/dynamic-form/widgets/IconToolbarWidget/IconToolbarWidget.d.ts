import { IconButtonVariant } from '../../../index.ts';
import { WidgetProps } from '@rjsf/utils';
/**
 * IconToolbarWidget — a non-data RJSF widget that renders a row of
 * Omni {@link IconButton}s declared in `ui:options.actions`. Useful
 * for kitchen-sink demos and form-level affordances that don't map to a
 * traditional input.
 *
 * Per-action shape:
 *   { icon: 'trash' | 'copy' | 'move-up' | 'move-down' | 'x', label, variant?, onClick? }
 *
 * Lucide `Trash2` auto-defaults to the `destructive` variant via the
 * Omni `IconButton`, so callers don't need to repeat it.
 *
 * @example
 * const uiSchema = {
 *   quick_actions: {
 *     'ui:widget': 'iconToolbar',
 *     'ui:options': {
 *       actions: [
 *         { icon: 'move-up',   label: 'Move up',   variant: 'ghost' },
 *         { icon: 'move-down', label: 'Move down', variant: 'ghost' },
 *         { icon: 'copy',      label: 'Duplicate', variant: 'ghost' },
 *         { icon: 'x',         label: 'Clear',     variant: 'ghost' },
 *         { icon: 'trash',     label: 'Delete' },
 *       ],
 *     },
 *   },
 * };
 */
export interface IconToolbarAction {
    icon: 'trash' | 'copy' | 'move-up' | 'move-down' | 'x';
    label: string;
    variant?: IconButtonVariant;
    onClick?: () => void;
}
export declare const IconToolbarWidget: (props: WidgetProps) => import("react").JSX.Element;
