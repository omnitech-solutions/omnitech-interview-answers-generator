import { WidgetProps } from '@rjsf/utils';
/**
 * `range`: a slider. The schema type picks the mode: a number is one thumb; an array of two numbers
 * (`minItems: 2`, `maxItems: 2`, bounds on `items`) is a from-to range with two thumbs.
 * `ui:options.step`, `minStepsBetweenThumbs`, and `thumbLabels: ['From', 'To']` to name the two thumbs.
 */
export declare const RangeWidget: (props: WidgetProps) => import("react").JSX.Element;
