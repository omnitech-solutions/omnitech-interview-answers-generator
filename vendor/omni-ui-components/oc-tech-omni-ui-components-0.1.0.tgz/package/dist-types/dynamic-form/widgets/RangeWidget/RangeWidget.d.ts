import { WidgetProps } from '@rjsf/utils';
/** RJSF Range widget — slider for numeric schemas. */
export declare const RangeWidget: (props: WidgetProps) => import("react").JSX.Element;
