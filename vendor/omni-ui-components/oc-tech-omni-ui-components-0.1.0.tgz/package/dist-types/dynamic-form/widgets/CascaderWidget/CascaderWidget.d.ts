import { WidgetProps } from '@rjsf/utils';
/**
 * `cascader`: a choice made level by level; the stored value is the PATH, an array of strings
 * (`['europe', 'france', 'paris']`). The tree is `formContext.optionTrees[ui:options.optionTreeKey]`, or plain
 * data in `ui:options.tree`. `ui:options.changeOnSelect` lets a branch be the answer; `displaySeparator`.
 */
export declare const CascaderWidget: (props: WidgetProps) => import("react").JSX.Element;
