import { WidgetProps } from '@rjsf/utils';
/**
 * `composer`: the chat message box as a form field; the stored value is the draft text. The form submits it,
 * so the box draws no send, attach or dictate control (each exists only with its callback, and a widget passes
 * none). Enter is a new line. `ui:options.appearance: 'stacked' | 'pill'`, `maxHeight` (px).
 */
export declare const ComposerWidget: (props: WidgetProps) => import("react").JSX.Element;
