import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * `mentions`: several lines of text in which a trigger character offers a list of names; the stored value is
 * the plain text. The names are `formContext.optionSets[ui:options.optionSetKey]`. `ui:options.trigger`
 * (default `@`, a string or a list of strings) and `rows`.
 */
export declare const MentionsWidget: (props: WidgetProps) => React.JSX.Element;
