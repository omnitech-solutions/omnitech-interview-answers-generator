import { WidgetProps } from '@rjsf/utils';
/** RJSF Stepper widget for `type: 'integer' | 'number'` schemas. */
export declare const StepperWidget: (props: WidgetProps) => import("react").JSX.Element;
