import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Radio widget. */
export declare const RadioWidget: (props: WidgetProps) => React.JSX.Element;
