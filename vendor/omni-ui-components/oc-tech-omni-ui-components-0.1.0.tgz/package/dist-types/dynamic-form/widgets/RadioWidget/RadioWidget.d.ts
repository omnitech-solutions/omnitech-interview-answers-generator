import { WidgetProps } from '@rjsf/utils';
/** `radio`: one choice, every option visible. `ui:options.inline`, `optionDescriptions`, `enumDisabled`, and `appearance: 'card'` for selectable cards. */
export declare const RadioWidget: (props: WidgetProps) => import("react").JSX.Element;
