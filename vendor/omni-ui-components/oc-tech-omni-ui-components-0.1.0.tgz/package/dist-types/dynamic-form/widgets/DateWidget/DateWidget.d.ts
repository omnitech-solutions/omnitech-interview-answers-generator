import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * `date`: one day, stored as `YYYY-MM-DD`. `ui:options.min` and `max` (the same format) bound the calendar;
 * `ui:options.placeholder`.
 */
export declare const DateWidget: (props: WidgetProps) => React.JSX.Element;
