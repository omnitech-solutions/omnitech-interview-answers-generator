import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Date widget — stores YYYY-MM-DD strings. */
export declare const DateWidget: (props: WidgetProps) => React.JSX.Element;
