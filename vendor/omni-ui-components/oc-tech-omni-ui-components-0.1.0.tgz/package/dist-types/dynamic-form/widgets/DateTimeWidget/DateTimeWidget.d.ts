import { WidgetProps } from '@rjsf/utils';
/** RJSF DateTime widget for `type: 'string', format: 'date-time'`. */
export declare const DateTimeWidget: (props: WidgetProps) => import("react").JSX.Element;
