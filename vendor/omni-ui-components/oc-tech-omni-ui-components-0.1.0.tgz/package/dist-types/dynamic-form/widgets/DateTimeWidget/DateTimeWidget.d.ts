import { WidgetProps } from '@rjsf/utils';
/** An ISO instant (`2026-10-09T16:30:00.000Z`) as the local `YYYY-MM-DDTHH:mm` the control shows. */
export declare const instantToLocal: (value: string) => string;
/** The control's local `YYYY-MM-DD[THH:mm]` as an ISO instant; a day with no time is local midnight. */
export declare const localToInstant: (value: string) => string | undefined;
/**
 * `dateTime`: a day and a time. Stored as a local ISO string (`YYYY-MM-DDTHH:mm`) by default, or with
 * `ui:options.storage: 'instant'` as an ISO instant in UTC (`…Z`), which is what a server usually keeps.
 * Clearing the day stores `undefined`. `ui:options.min` and `max` (`YYYY-MM-DD`).
 */
export declare const DateTimeWidget: (props: WidgetProps) => import("react").JSX.Element;
