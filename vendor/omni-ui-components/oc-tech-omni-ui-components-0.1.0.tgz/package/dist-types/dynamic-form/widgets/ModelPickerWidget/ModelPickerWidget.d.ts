import { WidgetProps } from '@rjsf/utils';
/**
 * `modelPicker`: the chat model menu as a form field; the stored value is the chosen model's `id`. The models
 * are `formContext.modelSets[ui:options.modelSetKey]`: the host supplies them, the schema only names the list.
 * The reasoning-effort row is not drawn: a widget holds one value.
 *
 * Read-only rule: the menu is a button that opens a list and has no read-only state of its own, so a read-only
 * field is drawn disabled.
 */
export declare const ModelPickerWidget: (props: WidgetProps) => import("react").JSX.Element;
