import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * `autocomplete`: free text with suggestions. A value outside the suggestions is valid: use `select` when it
 * must be one of a list. Suggestions come from the schema's `examples`, or with `ui:options.optionSetKey` from
 * `formContext.optionSets` (a list the host loads).
 */
export declare const AutoCompleteWidget: (props: WidgetProps) => React.JSX.Element;
