import { WidgetProps } from '@rjsf/utils';
/** RJSF RichText widget for HTML string values. */
export declare const RichTextWidget: (props: WidgetProps) => import("react").JSX.Element;
