import { WidgetProps } from '@rjsf/utils';
/** `richText`: formatted text, stored as an HTML string. */
export declare const RichTextWidget: (props: WidgetProps) => import("react").JSX.Element;
