import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Segmented widget — single-select pill row. */
export declare const SegmentedWidget: (props: WidgetProps) => React.JSX.Element;
