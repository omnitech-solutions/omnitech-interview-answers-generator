import { WidgetProps } from '@rjsf/utils';
/**
 * `segmented`: a row of toggles. The schema type picks the mode: a string stores one choice, an array of choices
 * (`uniqueItems`) stores several, and its `minItems` is the fewest that must stay on.
 * `ui:options.appearance: 'pill' | 'control'`.
 */
export declare const SegmentedWidget: (props: WidgetProps) => import("react").JSX.Element;
