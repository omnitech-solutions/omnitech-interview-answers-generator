import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * `calendar`: one day chosen on an always-open month grid, stored as `YYYY-MM-DD` (the same value as `date`).
 * `ui:options.min` and `max` (the same format) bound the days that can be chosen.
 */
export declare const CalendarWidget: (props: WidgetProps) => React.JSX.Element;
