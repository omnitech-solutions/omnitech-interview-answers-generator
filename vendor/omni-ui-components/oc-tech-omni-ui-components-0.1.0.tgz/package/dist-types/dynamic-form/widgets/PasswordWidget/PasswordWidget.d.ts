import { WidgetProps } from '@rjsf/utils';
/**
 * `password`: a password box with its reveal control. `ui:options.toggleable: false` draws the bare box;
 * `ui:options.autocomplete` is `current-password` (default) or `new-password`.
 */
export declare const PasswordWidget: (props: WidgetProps) => import("react").JSX.Element;
