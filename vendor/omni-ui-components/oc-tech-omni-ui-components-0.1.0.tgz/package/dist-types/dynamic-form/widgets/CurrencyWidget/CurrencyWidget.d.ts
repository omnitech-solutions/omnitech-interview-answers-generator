import { WidgetProps } from '@rjsf/utils';
/** RJSF Currency widget for monetary fields. */
export declare const CurrencyWidget: (props: WidgetProps) => import("react").JSX.Element;
