import { WidgetProps } from '@rjsf/utils';
/**
 * `currency`: an amount of money as a number; empty is `undefined`. `ui:options.currency` (default `USD`);
 * `ui:options.locale`, else the form's `formContext.locale`.
 */
export declare const CurrencyWidget: (props: WidgetProps) => import("react").JSX.Element;
