import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * RJSF Select widget. Sources options from one of two places:
 *   1. `ui:options.optionSetKey`: look up
 *      `formContext.optionSets[optionSetKey]` (preferred for grouped,
 *      avatar-bearing, or shared lists).
 *   2. Default: `schema.enum` / `oneOf` (the existing RJSF route).
 *
 * Honors `ui:options.footerActionKey` to render a dropdown footer
 * action — resolved from `formContext.actions[footerActionKey]`. The
 * primitive owns visual treatment.
 */
export declare const SelectWidget: (props: WidgetProps) => React.JSX.Element;
