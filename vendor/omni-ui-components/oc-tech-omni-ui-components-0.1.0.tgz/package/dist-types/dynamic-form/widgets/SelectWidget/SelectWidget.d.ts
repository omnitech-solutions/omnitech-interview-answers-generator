import { WidgetProps } from '@rjsf/utils';
/**
 * The one-of-a-list control behind `select` and `combobox`. Choices come from the schema (`enum` / `oneOf`) or,
 * with `ui:options.optionSetKey`, from `formContext.optionSets` (grouped, with avatar, colour, description).
 * `ui:options.footerActionKey` names an action in `formContext.actions` drawn under the list: a link when it has
 * an `href`, a call to the host's `onSelect` otherwise. The library never navigates.
 */
export declare const SelectControl: ({ props, searchable, }: {
    props: WidgetProps;
    searchable: boolean;
}) => import("react").JSX.Element;
/**
 * `select`: one choice from a list. An array schema is handed to `multiSelect`. `ui:options.searchable` adds a
 * search box (the same as `combobox`).
 */
export declare const SelectWidget: (props: WidgetProps) => import("react").JSX.Element;
