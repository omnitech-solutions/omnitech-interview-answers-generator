import { WidgetProps } from '@rjsf/utils';
/**
 * `rating`: a score as marks, stored as an integer. The number of marks is `ui:options.count`, else the
 * schema's `maximum`, else 5. Choosing the chosen mark again clears the field unless it is required.
 */
export declare const RatingWidget: (props: WidgetProps) => import("react").JSX.Element;
