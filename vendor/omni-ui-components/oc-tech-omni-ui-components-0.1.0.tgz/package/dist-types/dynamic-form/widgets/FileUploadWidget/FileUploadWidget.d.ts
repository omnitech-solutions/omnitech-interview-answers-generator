import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
export type FileWidgetMode = 'file' | 'data-url' | 'name';
/** A file as RJSF's `data-url` string: `data:<type>;name=<name>;base64,<bytes>`. */
export declare const fileToDataUrl: (file: File) => Promise<string>;
/**
 * `file`: one file, or several for an array schema. The library never uploads: the value leaves through
 * `onSubmit` and the host sends it. `ui:options.mode` says what the form holds:
 *   - `'file'` (default): the real `File` object(s). Validate with Zod (`z.instanceof(File)`).
 *   - `'data-url'`: a `data:` string per file (RJSF's `format: 'data-url'`), for small files and pure JSON.
 *   - `'name'`: the file name(s) only.
 * `ui:options.appearance: 'button'` draws a compact button instead of the drop area.
 * `ui:options.accept`, `maxSize` (bytes) and `maxFiles` are checked by the control; a refused file is reported
 * as the field's error.
 */
export declare const FileUploadWidget: (props: WidgetProps) => React.JSX.Element;
