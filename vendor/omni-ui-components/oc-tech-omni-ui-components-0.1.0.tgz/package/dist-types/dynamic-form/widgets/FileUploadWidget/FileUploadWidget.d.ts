import { WidgetProps } from '@rjsf/utils';
/**
 * RJSF FileUpload widget — emits file.name strings (placeholder behavior).
 * Real uploads require feature code to override onChange.
 */
export declare const FileUploadWidget: (props: WidgetProps) => import("react").JSX.Element;
