import { WidgetProps } from '@rjsf/utils';
/** `hidden`: a value the form carries and never shows. It is submitted unchanged. */
export declare const HiddenWidget: (props: WidgetProps) => import("react").JSX.Element;
