import { WidgetProps } from '@rjsf/utils';
/**
 * RJSF Hidden widget — renders nothing visible but keeps the value in
 * the form data. Use for IDs, tokens, or computed fields.
 *
 * @example
 * const uiSchema = { recordId: { 'ui:widget': 'hidden' } };
 */
export declare const HiddenWidget: (props: WidgetProps) => import("react").JSX.Element;
