import { WidgetProps } from '@rjsf/utils';
/**
 * Read-only RJSF widget that renders a string from
 * `formContext.derived[derivedKey]` instead of from `formData`. Use it
 * to surface computed display values (Excluding Tax, Sales Price,
 * counts, formatted dates) without writing them back into the
 * canonical submit payload.
 *
 * The widget never reads or writes `formData`; the underlying schema
 * property can be omitted from the parent object (the widget will
 * still render) or kept as a no-op string with `readOnly: true`.
 */
export type DerivedTextTone = 'default' | 'muted' | 'success' | 'danger';
export declare const DerivedTextWidget: (props: WidgetProps) => import("react").JSX.Element;
