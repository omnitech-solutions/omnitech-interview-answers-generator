import { WidgetProps } from '@rjsf/utils';
export type DerivedTextTone = 'default' | 'muted' | 'success' | 'danger';
/**
 * `derivedText`: a line of text computed from the form's data. It reads
 * `formContext.derived[ui:options.derivedKey]`; it never reads or writes the form data and nothing is submitted.
 * `ui:options.tone: 'default' | 'muted' | 'success' | 'danger'`.
 */
export declare const DerivedTextWidget: (props: WidgetProps) => import("react").JSX.Element;
