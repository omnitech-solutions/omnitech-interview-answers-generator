import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * `feedbackReasons`: the chat feedback panel's reason chips as a form field; the stored value is the chosen
 * reason ids, an array of strings. Same schema as `checkboxes` (an array of `enum` / `oneOf`, or
 * `ui:options.optionSetKey`). The panel's own note box and its submit and cancel buttons are not drawn: the form
 * submits, and a note is its own `textarea` field.
 *
 * Read-only rule: the panel has no read-only or disabled state of its own, so a locked field is `aria-disabled`,
 * takes no pointer, keeps its chips focusable and readable, and ignores every change.
 */
export declare const FeedbackReasonsWidget: (props: WidgetProps) => React.JSX.Element;
