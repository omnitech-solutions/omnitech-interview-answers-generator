import { WidgetProps } from '@rjsf/utils';
/** RJSF Switch widget for boolean schemas. */
export declare const SwitchWidget: (props: WidgetProps) => import("react").JSX.Element;
