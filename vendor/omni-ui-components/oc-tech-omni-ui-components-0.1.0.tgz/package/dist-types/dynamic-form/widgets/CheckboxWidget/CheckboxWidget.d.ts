import { WidgetProps } from '@rjsf/utils';
/**
 * `checkbox`: a boolean. The one widget that draws its own label, beside the box. Required only when the schema
 * demands `true`. `ui:options.label: false` keeps the label for a screen reader and hides it on screen.
 */
export declare const CheckboxWidget: (props: WidgetProps) => import("react").JSX.Element;
