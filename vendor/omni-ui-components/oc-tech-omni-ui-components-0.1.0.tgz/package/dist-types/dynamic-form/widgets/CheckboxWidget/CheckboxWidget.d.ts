import { WidgetProps } from '@rjsf/utils';
/**
 * RJSF Checkbox widget for boolean schemas. The field template draws no label for a boolean field, so the
 * widget draws it beside the box (`ui:title` replaces it, `ui:options.label: false` hides it). Hidden or not,
 * the box is named by it.
 */
export declare const CheckboxWidget: (props: WidgetProps) => import("react").JSX.Element;
