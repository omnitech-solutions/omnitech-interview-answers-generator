import { WidgetProps } from '@rjsf/utils';
/** RJSF Checkbox widget for boolean schemas. */
export declare const CheckboxWidget: (props: WidgetProps) => import("react").JSX.Element;
