import { WidgetProps } from '@rjsf/utils';
/** `phone`: a phone number as text. `ui:options.defaultDialCode`. */
export declare const PhoneWidget: (props: WidgetProps) => import("react").JSX.Element;
