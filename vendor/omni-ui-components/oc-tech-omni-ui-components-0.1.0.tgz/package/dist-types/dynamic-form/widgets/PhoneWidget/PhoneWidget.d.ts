import { WidgetProps } from '@rjsf/utils';
/** RJSF Phone widget. `ui:options.defaultDialCode` (e.g. `+1`) prefills the dial code. */
export declare const PhoneWidget: (props: WidgetProps) => import("react").JSX.Element;
