import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF MultiSelect widget — chip-rendering popover. */
export declare const MultiSelectWidget: (props: WidgetProps) => React.JSX.Element;
