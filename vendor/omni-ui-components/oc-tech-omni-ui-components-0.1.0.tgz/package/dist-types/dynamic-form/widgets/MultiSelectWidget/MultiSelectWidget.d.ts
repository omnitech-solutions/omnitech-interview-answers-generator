import { WidgetProps } from '@rjsf/utils';
/** `multiSelect`: several choices from a list, as chips. `maxItems` comes from the schema. */
export declare const MultiSelectWidget: (props: WidgetProps) => import("react").JSX.Element;
