import { WidgetProps } from '@rjsf/utils';
/** RJSF Color widget — submits `#rrggbb`. */
export declare const ColorWidget: (props: WidgetProps) => import("react").JSX.Element;
