import { WidgetProps } from '@rjsf/utils';
/**
 * `color`: a colour, stored as `#rrggbb`. An empty field shows no colour of its own: the screen never shows a
 * value the data does not hold. `ui:options.presets: string[]` offers swatches.
 */
export declare const ColorWidget: (props: WidgetProps) => import("react").JSX.Element;
