import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** `checkboxes`: several choices, every option visible. `ui:options.inline`, `optionDescriptions`, `enumDisabled`. */
export declare const CheckboxesWidget: (props: WidgetProps) => React.JSX.Element;
