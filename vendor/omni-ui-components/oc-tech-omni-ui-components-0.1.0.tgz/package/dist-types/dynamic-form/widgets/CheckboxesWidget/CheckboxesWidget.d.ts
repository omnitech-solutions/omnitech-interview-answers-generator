import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Checkboxes widget for `type: 'array'` with `items.enum` / `items.oneOf`. */
export declare const CheckboxesWidget: (props: WidgetProps) => React.JSX.Element;
