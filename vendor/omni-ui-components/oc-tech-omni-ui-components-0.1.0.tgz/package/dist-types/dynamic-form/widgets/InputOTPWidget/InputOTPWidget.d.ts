import { WidgetProps } from '@rjsf/utils';
/** `otp`: a one-time code, one box per character. Length: `ui:options.length`, else `maxLength`, else 6. */
export declare const InputOTPWidget: (props: WidgetProps) => import("react").JSX.Element;
