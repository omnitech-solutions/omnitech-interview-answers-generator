import { WidgetProps } from '@rjsf/utils';
/** RJSF InputOTP widget — one-time-code grid. */
export declare const InputOTPWidget: (props: WidgetProps) => import("react").JSX.Element;
