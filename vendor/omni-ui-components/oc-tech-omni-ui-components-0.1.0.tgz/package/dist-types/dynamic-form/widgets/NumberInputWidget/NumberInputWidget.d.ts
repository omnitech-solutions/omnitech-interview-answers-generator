import { WidgetProps } from '@rjsf/utils';
/** RJSF NumberInput widget — formatted numeric input. */
export declare const NumberInputWidget: (props: WidgetProps) => import("react").JSX.Element;
