import { WidgetProps } from '@rjsf/utils';
/** `numberInput`: a typed number; empty is `undefined`. `ui:options.decimals`, `thousandSeparator`, `prefix`, `suffix`. */
export declare const NumberInputWidget: (props: WidgetProps) => import("react").JSX.Element;
