import { WidgetProps } from '@rjsf/utils';
/** `combobox`: `select` with the search box always on. Same schema, same options, same stored value. */
export declare const ComboboxWidget: (props: WidgetProps) => import("react").JSX.Element;
