import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * RJSF Combobox widget — searchable select. Same option-source contract
 * as {@link SelectWidget}: `ui:options.optionSetKey` resolves from
 * `formContext.optionSets`, otherwise falls back to `schema.enum`.
 * `ui:options.footerActionKey` resolves from `formContext.actions`.
 */
export declare const ComboboxWidget: (props: WidgetProps) => React.JSX.Element;
