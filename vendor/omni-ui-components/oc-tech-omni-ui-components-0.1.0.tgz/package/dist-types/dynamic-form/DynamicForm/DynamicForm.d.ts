import { RegistryFieldsType, RegistryWidgetsType, RJSFSchema, TemplatesType, UiSchema } from '@rjsf/utils';
import { z } from 'zod';
import { FormError } from '../appFormSchema';
import * as React from 'react';
/**
 * Props for {@link DynamicForm}. `onSubmit` only runs when Zod parsing of
 * the current `formData` succeeds; failures map into RJSF `extraErrors`
 * (inline display) and call `onError` with `source: 'zod'`. Callback
 * throws / rejections surface through `onError` with `source: 'api'`.
 */
export interface DynamicFormProps<TFormData, TSubmitData> {
    schema: RJSFSchema;
    uiSchema?: UiSchema;
    zodSchema: z.ZodType<TSubmitData>;
    formData?: TFormData;
    fields?: RegistryFieldsType;
    widgets?: RegistryWidgetsType;
    templates?: Partial<TemplatesType>;
    formContext?: Record<string, unknown>;
    onChange?: (next: TFormData) => void;
    onSubmit: (parsed: TSubmitData) => void | Promise<void>;
    onError?: (errors: FormError[]) => void;
    disabled?: boolean;
    readOnly?: boolean;
    children?: React.ReactNode;
}
/**
 * Omni RJSF facade. Composes `omni-ui-components/Form` as the outer
 * root (form element, Zod-gated submit, FormError plumbing) with the
 * `@rjsf/shadcn` rendering tree as a `tagName="div"` child. Single submit
 * contract — there is only one form element, owned by Omni Form.
 *
 * Layout uses `@rjsf/shadcn` conventions: flat `ui:rows: string[][]` or the
 * full `ui:layoutGrid` / `LayoutGridField` pattern.
 *
 * @example
 * <DynamicForm
 *   schema={schema}
 *   uiSchema={uiSchema}
 *   zodSchema={zodSchema}
 *   formData={formData}
 *   onSubmit={(parsed) => save(parsed)}
 *   onError={(errors) => setErrors(errors)}
 * >
 *   <Button type="submit">Save</Button>
 * </DynamicForm>
 */
declare function DynamicFormImpl<TFormData extends Record<string, unknown>, TSubmitData>(props: DynamicFormProps<TFormData, TSubmitData>): JSX.Element;
export declare const DynamicForm: typeof DynamicFormImpl;
export {};
