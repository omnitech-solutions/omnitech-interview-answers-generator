import { RegistryFieldsType, RegistryWidgetsType, RJSFSchema, TemplatesType, UiSchema } from '@rjsf/utils';
import { z } from 'zod';
import { FormError } from '../appFormSchema';
import { OmniUiSchema } from '../lib/formContext';
import * as React from 'react';
/** What a host can ask of a mounted {@link DynamicForm} through `apiRef`. */
export interface DynamicFormHandle {
    /**
     * Moves focus to a field by its key: `'email'`, `'address.city'` or `['address', 'city']`. A host uses it to go
     * from a preview, an outline or an error summary to the field. Returns false when the form has no such field.
     */
    focusField: (path: string | readonly string[]) => boolean;
}
/**
 * Props for {@link DynamicForm}. `onSubmit` only runs when Zod parsing of
 * the current `formData` succeeds; failures map into RJSF `extraErrors`
 * (inline display) and call `onError` with `source: 'zod'`. Callback
 * throws / rejections surface through `onError` with `source: 'api'`.
 */
export interface DynamicFormProps<TFormData, TSubmitData> {
    schema: RJSFSchema;
    uiSchema?: UiSchema | OmniUiSchema;
    zodSchema: z.ZodType<TSubmitData>;
    formData?: TFormData;
    fields?: RegistryFieldsType;
    widgets?: RegistryWidgetsType;
    templates?: Partial<TemplatesType>;
    formContext?: Record<string, unknown>;
    onChange?: (next: TFormData) => void;
    onSubmit: (parsed: TSubmitData) => void | Promise<void>;
    onError?: (errors: FormError[]) => void;
    disabled?: boolean;
    readOnly?: boolean;
    /**
     * Prefix of every field id (`<idPrefix>_<field>`), and so of the labels' `for` and of `aria-describedby`.
     * Default `root`. Give each form its own when two forms share a screen, or their ids collide.
     */
    idPrefix?: string;
    /**
     * Errors the server returned, drawn through the same display as validation errors: an empty `path` is a
     * form-level error (drawn once for the whole form), any other path lands under its field. They are hidden as soon as the
     * person changes a value; pass a new array to show errors again.
     */
    serverErrors?: FormError[];
    /** Focus entered a field (from outside the form or from another field). `key` is its path: `email`, `address.city`. */
    onFieldFocus?: (key: string) => void;
    /** Focus left a field. A host saves on it, or stops highlighting a preview. */
    onFieldBlur?: (key: string) => void;
    /** A ref the form fills with its {@link DynamicFormHandle} (`focusField`). */
    apiRef?: React.Ref<DynamicFormHandle>;
    children?: React.ReactNode;
}
/**
 * Omni RJSF facade. Composes `omni-ui-components/Form` as the outer
 * root (form element, Zod-gated submit, FormError plumbing) with the
 * `@rjsf/shadcn` rendering tree as a `tagName="div"` child. Single submit
 * contract — there is only one form element, owned by Omni Form.
 *
 * Layout uses `@rjsf/shadcn` conventions: flat `ui:rows: string[][]` or the
 * full `ui:layoutGrid` / `LayoutGridField` pattern.
 *
 * @example
 * <DynamicForm
 *   schema={schema}
 *   uiSchema={uiSchema}
 *   zodSchema={zodSchema}
 *   formData={formData}
 *   onSubmit={(parsed) => save(parsed)}
 *   onError={(errors) => setErrors(errors)}
 * >
 *   <Button type="submit">Save</Button>
 * </DynamicForm>
 */
declare function DynamicFormImpl<TFormData extends Record<string, unknown>, TSubmitData>(props: DynamicFormProps<TFormData, TSubmitData>): JSX.Element;
export declare const DynamicForm: typeof DynamicFormImpl;
export {};
