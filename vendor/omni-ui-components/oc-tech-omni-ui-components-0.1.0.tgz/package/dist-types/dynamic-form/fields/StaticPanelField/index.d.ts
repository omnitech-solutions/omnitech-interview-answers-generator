export { StaticPanelField } from './StaticPanelField';
