import { FieldProps } from '@rjsf/utils';
import * as React from 'react';
/** What the field stores: both ends as `YYYY-MM-DD`. An end that is not chosen is absent. */
export interface DateRangeValue {
    from?: string;
    to?: string;
}
/**
 * `dateRange` (a FIELD, chosen with `ui:field`, because its value is an object): a first and a last day in one
 * control. Schema: an object with `from` and `to`, each `{ type: 'string', format: 'date' }`. It draws its own
 * label, description and errors through the shared field chrome, since the form's template draws none for an
 * object. `ui:options.min`, `max` (`YYYY-MM-DD`), `placeholder`, `size`, `variant`, `layout`.
 *
 * @example
 * schema: { period: { type: 'object', title: 'Period', properties: { from: { type: 'string', format: 'date' }, to: { type: 'string', format: 'date' } } } }
 * uiSchema: { period: { 'ui:field': 'dateRange' } }
 */
export declare const DateRangeField: (props: FieldProps) => React.JSX.Element;
