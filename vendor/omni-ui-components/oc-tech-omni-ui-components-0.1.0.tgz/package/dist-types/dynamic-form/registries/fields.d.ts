import { RegistryFieldsType } from '@rjsf/utils';
/**
 * The library's field registry. A field owns a whole schema node: one whose value is an object (`dateRange`),
 * or one with no value at all (`staticPanel`). Chosen with `ui:field`.
 *
 * @example
 * const merged = { ...appFields, scheduleConfiguration: ScheduleConfigurationField };
 */
export declare const appFields: RegistryFieldsType;
