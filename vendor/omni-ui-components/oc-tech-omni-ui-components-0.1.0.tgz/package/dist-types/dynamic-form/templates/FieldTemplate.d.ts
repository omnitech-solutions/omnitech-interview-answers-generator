import { FieldTemplateProps } from '@rjsf/utils';
/**
 * The chrome of every schema field: the SAME `FieldShell` a hand-built field uses (label, required mark, hidden
 * "Required" hint, description, error with `role="alert"`, vertical or horizontal layout), so the two kinds of
 * form cannot drift apart.
 *
 * The ids of the description, the error and the help are {@link fieldPartIds}; each widget points its control at
 * them with `aria-describedby` through `widgetField`. The label carries the id `<field>__title` so a group
 * control can be named by `aria-labelledby`.
 *
 * Options, per field in `ui:options` or for the whole form in `ui:globalOptions`:
 *   - `layout: 'vertical' | 'horizontal'`: the label above (default) or to the left of the control.
 *   - `labelActionKey`: a link or button beside the label, from `formContext.actions`.
 * A status beside the label comes from `formContext.fieldStatus[<field key>]` (a tone and its words).
 */
export declare const FieldTemplate: (props: FieldTemplateProps) => import("react").JSX.Element;
