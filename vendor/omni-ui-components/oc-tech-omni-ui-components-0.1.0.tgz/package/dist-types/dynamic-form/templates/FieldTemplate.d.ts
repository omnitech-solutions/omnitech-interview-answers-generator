import { FieldTemplateProps } from '@rjsf/utils';
/**
 * Omni override of the shadcn `FieldTemplate`. Same structure as the
 * upstream template but the required `*` always renders in
 * `text-destructive`, matching the legacy `.form-field` modal asterisk
 * styling.
 */
export declare const FieldTemplate: (props: FieldTemplateProps) => import("react").JSX.Element;
