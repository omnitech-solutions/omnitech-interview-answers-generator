import { ObjectFieldTemplateProps } from '@rjsf/utils';
import * as React from 'react';
export declare const ObjectFieldTemplate: (props: ObjectFieldTemplateProps) => React.JSX.Element;
