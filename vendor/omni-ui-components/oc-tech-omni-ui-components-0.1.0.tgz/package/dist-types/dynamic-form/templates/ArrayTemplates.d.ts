import { ArrayFieldItemTemplateProps, ArrayFieldTemplateProps, IconButtonProps } from '@rjsf/utils';
/**
 * The "add a row" button of an array, a library `Button`. Its words are `formContext.labels.addItem`, or
 * `ui:options.addLabel` on the array for one list ("Add person").
 */
export declare const AddButton: (props: IconButtonProps) => import("react").JSX.Element;
/** One row of an array: the row's fields, and its move, copy and remove buttons beside them. */
export declare const ArrayFieldItemTemplate: (props: ArrayFieldItemTemplateProps) => import("react").JSX.Element;
/**
 * An array of rows, drawn from library parts: a title that is not a stray heading, the description, the rows as
 * a list, and the add button. `ui:options.addLabel` names the button for this list; `ui:options.headingLevel`
 * makes the title a heading.
 */
export declare const ArrayFieldTemplate: (props: ArrayFieldTemplateProps) => import("react").JSX.Element;
