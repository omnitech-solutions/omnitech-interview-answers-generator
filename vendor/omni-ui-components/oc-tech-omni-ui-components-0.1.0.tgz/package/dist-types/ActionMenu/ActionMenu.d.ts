import { ActionMenuProps } from './ActionMenu.types';
import * as React from 'react';
/**
 * Omni ActionMenu: a popup menu described entirely as data. `sections` of rows
 * (checked / icon column that stays aligned, description, shortcut glyphs, danger
 * tone, disabled with a visible reason), an optional leading `notice` (status +
 * fix action), a pinned `hint` row, viewport-aware height with internal scroll,
 * and configurable placement. Every callback is a prop.
 *
 * `kind="menu"` is a Radix dropdown menu (arrow keys, Enter, Escape, typeahead;
 * radio / checkbox / plain rows by `selection`). `kind="list"` is a read-only
 * grouped reference list (a Popover dialog) such as the shortcuts menu.
 *
 * @example
 * <ActionMenu
 *   trigger={<button>Mode</button>}
 *   label="When to analyse"
 *   sections={[{ id: 'mode', label: 'When to analyse', items: [
 *     { id: 'manual', label: 'Manual', description: 'Analyse only when you press it', checked: true, shortcut: ['⌘', '⇧', 'S'] },
 *     { id: 'auto', label: 'Auto', checked: false, shortcut: ['⌥', '⇧', 'U'] },
 *   ] }]}
 *   onSelect={(id) => setMode(id)}
 * />
 */
export declare const ActionMenu: React.FC<ActionMenuProps>;
