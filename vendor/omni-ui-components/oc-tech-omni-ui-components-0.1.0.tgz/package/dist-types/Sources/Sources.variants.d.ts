/** A source chip: number badge, title, quiet meta. Pressed = its card is open. */
export declare const sourceChipVariants: (props?: import('class-variance-authority/types').ClassProp | undefined) => string;
export declare const sourceNumberClasses = "inline-flex h-4 min-w-4 flex-none items-center justify-center rounded-full bg-[color:var(--oui-tone-accent-bg)] px-1 text-[10.5px] font-semibold text-[color:var(--oui-tone-accent-fg)]";
/** The open card: panel colour, panel divider, a quotation under the head row. */
export declare const sourceCardClasses = "mt-2 rounded-lg border border-solid border-[color:var(--oui-panel-divider)] bg-[color:color-mix(in_srgb,var(--oui-panel-dock-bg)_calc(var(--oui-panel-see-through,1)_*_100%),transparent)] px-3 py-2 text-[12.5px]";
