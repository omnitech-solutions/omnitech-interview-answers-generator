import { SourceItem, SourcesLabels, SourcesProps } from './Sources.types';
import * as React from 'react';
/** English strings of {@link Sources}. */
export declare const DEFAULT_SOURCES_LABELS: SourcesLabels;
/** Generic over the item type: an extended item flows to every callback and slot, by reference. */
export declare const Sources: <T extends SourceItem = SourceItem>(props: SourcesProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
