import { FloatButton } from '../FloatButton';
import * as React from 'react';
export interface BackTopProps extends React.ComponentProps<typeof FloatButton> {
    visibilityHeight?: number;
    target?: () => HTMLElement | Window | Document;
    duration?: number;
}
export declare const BackTop: ({ visibilityHeight, target, duration, children, onClick, ...props }: BackTopProps) => React.JSX.Element | null;
