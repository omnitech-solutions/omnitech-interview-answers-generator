import type * as React from 'react';
export interface QRCodeProps extends React.HTMLAttributes<HTMLDivElement> {
    value: string;
    size?: number;
}
export declare const QRCode: ({ value, size, className, ...props }: QRCodeProps) => React.JSX.Element;
