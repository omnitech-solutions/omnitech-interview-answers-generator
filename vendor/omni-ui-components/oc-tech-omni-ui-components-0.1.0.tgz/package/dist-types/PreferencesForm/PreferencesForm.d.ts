import { MemoryItem, PreferencesFormLabels, PreferencesFormProps } from './PreferencesForm.types';
import * as React from 'react';
export declare const DEFAULT_PREFERENCES_FORM_LABELS: PreferencesFormLabels;
/**
 * Omni PreferencesForm: custom instructions (a textarea, max 4000) and the memory the assistant keeps (a switch plus a
 * list with Forget). `onChange(text)` fires on every keystroke, so a host that autosaves debounces it itself (the
 * `useDebouncedCallback` util is exported for that). The memory section appears when `memories` is given; its switch
 * needs `onMemoryToggle` and each Forget button needs `onForget`, which receives the full memory item (the same object
 * you passed, extra fields included).
 *
 * Slots: `data-slot="preferences-form" | "preferences-instructions" | "preferences-memory" | "preferences-memory-item"`.
 *
 * @example
 * <PreferencesForm instructions={saved} onChange={save} memories={memories} memoryEnabled={on} onMemoryToggle={setOn} onForget={(m) => forget(m.id)} />
 */
export declare const PreferencesForm: <M extends MemoryItem = MemoryItem>({ instructions, onChange, maxLength, rows, loading, memories, memoryEnabled, onMemoryToggle, onForget, forgetIcon, labels: labelOverrides, className, }: PreferencesFormProps<M>) => React.JSX.Element;
