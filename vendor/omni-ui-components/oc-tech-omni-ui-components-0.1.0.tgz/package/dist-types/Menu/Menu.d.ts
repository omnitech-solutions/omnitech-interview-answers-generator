import { MenuItem, MenuProps } from './Menu.types';
import * as React from 'react';
/**
 * Omni Menu: a list of items for side navigation. Items are typed data: an item with `href` is an anchor (the menu
 * never navigates; return `false` from `onSelect` to keep the click), the current item carries
 * `aria-current="page"`, `indicator` is a named dot, `shortcut` draws keys, a `group` draws its label over its
 * children and a `divider` a rule. `collapsed` shows icons only with the label as a tooltip; `appearance="plain"`
 * drops the card for use in a `Sider`.
 *
 * @example
 * <Menu<Route> label="Main" appearance="plain" items={routes} selectedKeys={[current]}
 *   onSelect={(route) => { go(route.path); return false; }} />
 */
export declare const Menu: <T extends MenuItem = MenuItem>({ items, selectedKeys, onSelect, collapsed, appearance, size, label, className, ...props }: MenuProps<T>) => React.JSX.Element;
