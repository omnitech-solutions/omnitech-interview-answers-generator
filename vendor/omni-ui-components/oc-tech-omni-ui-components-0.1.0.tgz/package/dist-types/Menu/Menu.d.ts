import * as React from 'react';
export interface MenuItem {
    key: React.Key;
    label: React.ReactNode;
    icon?: React.ReactNode;
    children?: MenuItem[];
    onClick?: () => void;
}
export interface MenuProps extends React.HTMLAttributes<HTMLUListElement> {
    items: MenuItem[];
    selectedKeys?: React.Key[];
}
export declare const Menu: ({ items, selectedKeys, className, ...props }: MenuProps) => React.JSX.Element;
