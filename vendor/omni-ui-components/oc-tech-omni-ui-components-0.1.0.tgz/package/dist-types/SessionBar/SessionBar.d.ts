import { SessionBarProps } from './SessionBar.types';
import * as React from 'react';
/**
 * Omni SessionBar: the live-session footer. It is the Toolbar `bar` variant (full width, wraps, nothing
 * absolutely positioned) with the panel surface, a `leading` slot (the StatusClock) and right-aligned
 * actions built from config: Pause (neutral outline, filled icon) and Resume (green solid, filled icon) share one
 * slot and swap with `status`; End is an outlined red button whose optional `confirm` config opens a
 * Popconfirm. Every label, icon node and callback is a prop. The background never depends on `status`.
 *
 * @example
 * <SessionBar status={paused ? 'paused' : 'live'} leading={<StatusClock … />}
 *   pause={{ icon: <Pause />, onClick: pause }} resume={{ icon: <Play />, onClick: resume }}
 *   end={{ onClick: end, confirm: { title: 'End the session?' } }} />
 */
export declare const SessionBar: React.ForwardRefExoticComponent<SessionBarProps & React.RefAttributes<HTMLDivElement>>;
