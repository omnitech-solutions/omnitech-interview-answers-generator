/**
 * The footer surface. It is the same in every session state: the panel colour (mixed with the see-through
 * token on the background only), the panel border and radius. Written out in full for Tailwind's scan.
 */
export declare const SESSION_BAR_SURFACE: string;
