import { InputProps } from '../Input/Input.types';
import * as React from 'react';
export type EmailInputProps = Omit<InputProps, 'type' | 'inputMode'>;
/**
 * Omni EmailInput — chrome-wrapped {@link EmailInputPrimitive}.
 *
 * @example
 * <EmailInput label="Email" value={email} onChange={setEmail} />
 */
declare const EmailInputInner: React.ForwardRefExoticComponent<Omit<EmailInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const EmailInput: typeof EmailInputInner;
export {};
