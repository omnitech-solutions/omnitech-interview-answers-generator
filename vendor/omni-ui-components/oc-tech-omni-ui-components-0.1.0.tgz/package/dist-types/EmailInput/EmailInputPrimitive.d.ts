import { InputPrimitiveProps } from '../Input/Input.types';
import * as React from 'react';
export type EmailInputPrimitiveProps = Omit<InputPrimitiveProps, 'type' | 'inputMode'>;
declare const EmailInputPrimitiveInner: React.ForwardRefExoticComponent<Omit<EmailInputPrimitiveProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const EmailInputPrimitive: typeof EmailInputPrimitiveInner;
export {};
