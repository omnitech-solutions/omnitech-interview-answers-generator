import { SegmentedPrimitiveProps } from './Segmented.types';
import * as React from 'react';
/**
 * Raw Omni Segmented primitive — a toggle row built on Radix `ToggleGroup`.
 *
 * - `mode="single"` (default): one selected option; `value`/`onChange` are a string.
 *   Selected uses `bg-primary` + white text in the default `pill` appearance.
 * - `mode="multiple"`: a toggle group; `value`/`onChange` are `string[]` and
 *   `minActive` keeps the last on-option(s) from being turned off.
 * - `appearance="control"`: the 36px bordered control-row group used by the
 *   Native App toolbar (icon options, accent-tinted active, transparent inactive).
 *
 * Options may carry an `icon`, a `label` (optional when icon-only), and a
 * `disabledReason` (`aria-disabled` + tooltip). Whole control is
 * keyboard-friendly (Left / Right move focus inside the group).
 */
declare const SegmentedPrimitiveInner: React.ForwardRefExoticComponent<SegmentedPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
export declare const SegmentedPrimitive: typeof SegmentedPrimitiveInner;
export {};
