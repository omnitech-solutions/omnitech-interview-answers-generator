import { SegmentedProps } from './Segmented.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Segmented control. Composes
 * {@link SegmentedPrimitive} with {@link FieldShell}.
 */
declare const SegmentedInner: React.ForwardRefExoticComponent<SegmentedProps & React.RefAttributes<HTMLDivElement>>;
export declare const Segmented: typeof SegmentedInner;
export {};
