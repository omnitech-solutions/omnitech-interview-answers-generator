interface MdText {
    type: 'text';
    value: string;
}
interface MdParent {
    type: string;
    children: MdNode[];
    data?: Record<string, unknown>;
}
type MdNode = MdText | MdParent;
type Root = MdParent;
/** The element name the citation plugin emits; `Markdown` maps it to the pill. */
export declare const CITE_ELEMENT = "oui-cite";
/**
 * remark plugin: turns `[2]` into a citation node when a source numbered 2 exists. Only text nodes are visited, so
 * code (inline or fenced) is never touched, and a number nobody cites stays plain text.
 */
export declare function remarkCitations(cited: ReadonlySet<number>): () => (tree: Root) => void;
export {};
