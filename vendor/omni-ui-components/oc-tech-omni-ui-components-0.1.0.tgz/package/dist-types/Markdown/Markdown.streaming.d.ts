/**
 * Closes what a half-streamed reply leaves open, for display only (the stored text is never changed):
 * an unclosed code fence gets its closing fence, then an unclosed inline code span or `**` in the last paragraph
 * gets its closer. Complete markdown comes back unchanged. Code is never touched by the emphasis rule.
 *
 * @example
 * closeOpenMarkdown('Try:\n```ts\nconst a = 1;'); // 'Try:\n```ts\nconst a = 1;\n```'
 * closeOpenMarkdown('This is **bold');             // 'This is **bold**'
 */
export declare function closeOpenMarkdown(source: string): string;
