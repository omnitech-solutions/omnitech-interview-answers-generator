/**
 * Look of the rendered reply. Written out in full for Tailwind's source scan. Text colour is inherited, so the
 * parent (a Panel, a bubble) decides it; surfaces use the `--oui-panel-*` tokens like the Transcript code block.
 */
export declare const markdownRootClasses = "min-w-0 text-[13px] leading-[1.55] break-words select-text [&>*:first-child]:mt-0 [&>*:last-child]:mb-0";
export declare const markdownHeadingClasses = "mt-3 mb-1 text-[14px] leading-[1.35] font-semibold";
export declare const markdownParagraphClasses = "my-2";
export declare const markdownListClasses = "my-2 ps-5 [&_ol]:my-1 [&_ul]:my-1";
export declare const markdownBlockquoteClasses = "my-2 border-s-2 border-solid border-[color:var(--oui-panel-divider)] ps-3 text-[color:var(--oui-panel-meta-fg)]";
export declare const markdownLinkClasses = "text-[color:var(--oui-tone-accent-fg)] underline underline-offset-2 rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";
export declare const markdownInlineCodeClasses = "rounded-[5px] bg-[color:var(--oui-tone-accent-bg)] px-1 py-px font-mono text-[0.92em] text-[color:var(--oui-code-plain)]";
export declare const markdownRuleClasses = "my-3 border-0 border-t border-solid border-[color:var(--oui-panel-divider)]";
export declare const markdownTableWrapClasses = "my-2 max-w-full overflow-x-auto";
export declare const markdownTableClasses = "w-full border-collapse text-[12.5px]";
export declare const markdownCellClasses = "border border-solid border-[color:var(--oui-panel-divider)] px-2 py-1 text-start align-top";
export declare const markdownHeadCellClasses = "border border-solid border-[color:var(--oui-panel-divider)] px-2 py-1 text-start align-top bg-[color:var(--oui-panel-dock-bg)] font-semibold";
/** Citation pill: a small round accent number, the size of a superscript. */
export declare const markdownCiteClasses: string;
/** Code block: the same look as the Transcript's (dock colour mixed with the see-through token, backgrounds only). */
export declare const markdownCodeBlockClasses: string;
export declare const markdownCodeHeaderClasses = "flex h-7 items-center justify-between gap-2 border-b border-solid border-[color:var(--oui-panel-divider)] pr-1 pl-2.5 font-mono text-[11px] text-[color:var(--oui-panel-meta-fg)] select-none";
export declare const markdownCodeTextClasses = "m-0 px-2.5 py-2 font-mono text-[12px] leading-[1.5] select-text";
export declare const markdownCopyClasses = "h-6 gap-1 rounded-md px-1.5 text-[11px] font-normal text-[color:var(--oui-panel-meta-fg)] select-none [&_svg]:size-3";
/** Streaming cursor: a blinking block; static for people who prefer reduced motion. */
export declare const markdownCursorClasses = "ms-0.5 inline-block h-[1.05em] w-[0.5em] translate-y-[0.15em] animate-pulse rounded-[1px] bg-current opacity-70 motion-reduce:animate-none";
