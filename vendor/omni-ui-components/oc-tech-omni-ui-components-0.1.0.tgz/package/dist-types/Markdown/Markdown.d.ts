import { CitationSource, MarkdownLabels, MarkdownProps } from './Markdown.types';
import * as React from 'react';
/** English strings of {@link Markdown}; pass `labels` to replace any of them. */
export declare const DEFAULT_MARKDOWN_LABELS: MarkdownLabels;
/** Generic over the source item type: an extended source reaches `onCite` by reference. */
export declare const Markdown: <T extends CitationSource = CitationSource>(props: MarkdownProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
