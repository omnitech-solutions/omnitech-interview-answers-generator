/** The navigation shell: docked sits beside the conversation with a divider, overlay floats over it with a shadow. */
export declare const conversationListVariants: (props?: ({
    docked?: boolean | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
/** One conversation row. The open row keeps a tinted background. */
export declare const conversationRowVariants: (props?: ({
    active?: boolean | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
/** The hover action cluster: collapsed (but still focusable) until the row is hovered or focused. */
export declare const ROW_ACTIONS_CLASS = "flex flex-none items-center overflow-hidden max-w-0 opacity-0 transition-[max-width,opacity] motion-reduce:transition-none group-hover/row:max-w-24 group-hover/row:opacity-100 group-focus-within/row:max-w-24 group-focus-within/row:opacity-100 [@media(hover:none)]:max-w-24 [@media(hover:none)]:opacity-100";
