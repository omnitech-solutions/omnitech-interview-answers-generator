import { ConversationItem, ConversationListLabels, ConversationListProps } from './ConversationList.types';
import * as React from 'react';
/** English defaults of every string. Pass `labels` to translate any of them. */
export declare const DEFAULT_CONVERSATION_LIST_LABELS: ConversationListLabels;
/**
 * Omni ConversationList: the sidebar of an assistant. Headed groups of rows (build them with `groupByRecency`), a
 * search field with a key hint, hover actions per row (`rowActions`: pin, delete, restore), an archived view and a
 * footer slot. Everything is a prop: the open row is `activeId` (it gets `aria-current`), rows report `onOpen(item)`,
 * every string is in `labels`, every icon is a caller node. The caller debounces `onSearchChange`.
 *
 * The rows are one tab stop: Up and Down move between rows, Left and Right between a row's title and its actions, Home and
 * End to the first and last row; Tab leaves the list.
 *
 * Slots for host styling: `data-slot="conversation-list" | "conversation-list-head" | "conversation-list-search" |
 * "conversation-list-body" | "conversation-group" | "conversation-row" | "conversation-list-empty" | "conversation-list-archived"`.
 *
 * @example
 * <ConversationList groups={groupByRecency(threads, new Date(), { pinned: (t) => t.pinned })} activeId={id}
 *   onOpen={open} onSearchChange={setQuery} searchShortcut="⌘K" onNewChat={create}
 *   rowActions={[{ key: 'pin', label: (t) => (t.pinned ? 'Unpin' : 'Pin'), icon: (t) => <Pin filled={t.pinned} />, pressed: (t) => !!t.pinned, onClick: togglePin }]} />
 */
export declare function ConversationList<T extends ConversationItem = ConversationItem>({ groups, activeId, onOpen, rowActions, docked, onClose, onNewChat, newChatShortcut, query: queryProp, defaultQuery, onSearchChange, searchShortcut, searchRef, archived, onBack, archivedCount, onShowArchived, empty, footer, icons, labels: labelOverrides, className, 'data-testid': testId, }: ConversationListProps<T>): React.JSX.Element;
