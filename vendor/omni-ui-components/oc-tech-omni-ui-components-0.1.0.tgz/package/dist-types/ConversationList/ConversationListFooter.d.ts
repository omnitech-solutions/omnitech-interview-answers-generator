import { ConversationListFooterProps } from './ConversationList.types';
/**
 * The foot of a ConversationList: avatar initials (from `user.initials`, else the name), the name and detail, and a
 * settings gear. Renders nothing when there is neither a user nor a gear.
 */
export declare const ConversationListFooter: ({ user, onOpenSettings, settingsIcon, settingsLabel, className, }: ConversationListFooterProps) => import("react").JSX.Element | null;
