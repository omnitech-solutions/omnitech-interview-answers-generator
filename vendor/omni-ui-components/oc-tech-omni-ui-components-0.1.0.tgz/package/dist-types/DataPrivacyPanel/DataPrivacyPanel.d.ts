import { DataPrivacyPanelLabels, DataPrivacyPanelProps, RetentionOption } from './DataPrivacyPanel.types';
export declare const DEFAULT_DATA_PRIVACY_LABELS: DataPrivacyPanelLabels;
export declare const DEFAULT_RETENTION_OPTIONS: RetentionOption[];
/**
 * Omni DataPrivacyPanel: what is kept, for how long, and taking it away. A retention Segmented, an activity log you
 * View or Hide (a list capped at 220px that scrolls), Export all data, and Delete everything behind the library
 * Popconfirm (replacing the original's two-click confirmation). Every section appears only when its callback is
 * given; all strings are in `labels`.
 *
 * Slots: `data-slot="data-privacy" | "data-privacy-retention" | "data-privacy-log" | "data-privacy-export" | "data-privacy-delete"`.
 *
 * @example
 * <DataPrivacyPanel retention={r} onRetentionChange={setR} activity={rows} activityOpen={open} onShowActivityChange={load}
 *   onExport={exportAll} onDeleteAll={deleteAll} />
 */
export declare const DataPrivacyPanel: ({ retention: retentionProp, defaultRetention, retentionOptions, onRetentionChange, activity, activityOpen: activityOpenProp, defaultActivityOpen, onShowActivityChange, activityLoading, onExport, onDeleteAll, formatDate, labels: labelOverrides, className, }: DataPrivacyPanelProps) => import("react").JSX.Element;
