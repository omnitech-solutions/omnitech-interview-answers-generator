import { FieldLayoutProps } from '../Input/Input.variants';
import { RootProps } from '../lib';
import * as React from 'react';
export interface ColorPickerProps extends RootProps, FieldLayoutProps {
    id?: string;
    name?: string;
    value?: string;
    defaultValue?: string;
    onChange?: (next: string) => void;
    /** Preset swatches. Defaults to a 11-color Omni palette. */
    presets?: string[];
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    wrapperClassName?: string;
    labelClassName?: string;
    className?: string;
    'data-testid'?: string;
}
/** Chrome-wrapped Omni ColorPicker. */
export declare const ColorPicker: React.NamedExoticComponent<ColorPickerProps>;
