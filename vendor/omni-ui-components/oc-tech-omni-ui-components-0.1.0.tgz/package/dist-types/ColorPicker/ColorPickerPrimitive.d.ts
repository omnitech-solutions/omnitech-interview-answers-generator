import * as React from 'react';
export interface ColorPickerPrimitiveProps {
    id?: string;
    name?: string;
    value?: string;
    defaultValue?: string;
    onChange?: (next: string) => void;
    presets?: string[];
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw color picker control: popover trigger + hex input + preset palette. */
export declare const ColorPickerPrimitive: React.ForwardRefExoticComponent<ColorPickerPrimitiveProps & React.RefAttributes<HTMLButtonElement>>;
