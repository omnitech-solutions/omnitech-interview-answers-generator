import { ApprovalItem } from '../ApprovalCard';
import { FeedbackReason } from '../FeedbackPanel';
import { ChatAttachmentPart, ChatSource, ChatVersion, ConversationTurn } from '../Transcript';
import { ConversationTranscriptProps, DEFAULT_CONVERSATION_TRANSCRIPT_LABELS } from './ConversationTranscript.types';
import * as React from 'react';
export { DEFAULT_CONVERSATION_TRANSCRIPT_LABELS };
/**
 * A conversation with the default composition of the chat parts, from props only: your questions, then each reply with its
 * step timeline, reasoning, markdown (code, citations), sources, actions (copy, regenerate, version pager, thumbs), the
 * feedback panel, follow-ups, approvals, the error with Retry, the stopped banner and summary dividers. Each part is drawn
 * only when its data or its callback is given. It is the Transcript's conversation mode with the slots filled in; for a
 * different arrangement use `Transcript` and its `slots`.
 *
 * @example
 * <ConversationTranscript turns={buildTurns(messages, runs)} copyIcon={<Copy />} onCite={(source) => open(source)} onSelectSuggestion={send} />
 */
export declare function ConversationTranscript<U extends ConversationTurn = ConversationTurn, V extends ChatVersion = ChatVersion, A extends ChatAttachmentPart = ChatAttachmentPart, S extends ChatSource = ChatSource, P extends ApprovalItem = ApprovalItem, R extends FeedbackReason = FeedbackReason>({ icons, copyIcon, copiedIcon, labels: labelOverrides, transcriptLabels, partLabels, highlight, codeLineNumbers, wrapCode, copiedMs, stepLabel, stepDetail, onToggleSteps, onToggleThinking, onCite, onCopyCode, openSource: openSourceProp, defaultOpenSource, onOpenSourceChange, onToggleSource, onSelectSuggestion, onCopyReply, onRate, ratings, defaultRatings, feedbackReasons, onSubmitFeedback, onCancelFeedback, actionsMeta, approvals, onDecideApproval, summaries, onToggleSummary, extraActions, turns, onRetry, ...rest }: ConversationTranscriptProps<U, V, A, S, P, R>): React.JSX.Element;
