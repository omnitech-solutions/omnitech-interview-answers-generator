/** Wrappers the composition adds around parts that need one. The Transcript owns the column and the turn spacing. */
export declare const conversationTranscriptPartVariants: (props?: ({
    part?: "approval" | "feedback" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
