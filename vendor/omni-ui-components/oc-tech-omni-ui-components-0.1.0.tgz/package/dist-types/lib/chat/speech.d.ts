/** True when the browser can read text aloud. */
export declare const canSpeak: () => boolean;
/** What a reply sounds like read aloud: prose without Markdown punctuation, code blocks replaced by `codeOmitted`. */
export declare const speakable: (markdown: string, codeOmitted?: string) => string;
/**
 * Read-aloud toggle: `speak(id, text)` starts reading, or stops when `id` is already being read. `speaking` is the id
 * being read. Speech stops when the component unmounts.
 */
export declare const useSpeech: () => {
    speaking: string | undefined;
    speak: (id: string, text: string) => void;
    stop: () => void;
};
