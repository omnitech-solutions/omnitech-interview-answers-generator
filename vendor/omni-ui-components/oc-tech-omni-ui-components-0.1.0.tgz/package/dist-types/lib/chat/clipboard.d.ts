/** Writes text to the clipboard. Resolves true when it was written, false when the clipboard is unavailable or refused. */
export declare const copyText: (text: string) => Promise<boolean>;
