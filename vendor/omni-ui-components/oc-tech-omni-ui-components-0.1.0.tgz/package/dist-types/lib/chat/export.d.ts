/** A message as the export helpers read it: who said it and what. Callers drop tool traffic before exporting. */
export interface ExportMessage {
    role: 'user' | 'assistant' | (string & {});
    text: string;
}
/** English defaults of the headings the export writes. */
export interface ExportLabels {
    /** Heading above a user message. Default `You`. */
    user: string;
    /** Heading above an assistant message. Default `Assistant`. */
    assistant: string;
    /** Title used when the conversation has none. Default `Conversation`. */
    untitled: string;
}
export declare const DEFAULT_EXPORT_LABELS: ExportLabels;
/** Keep what people read: user and assistant messages with text. */
export declare const readableMessages: <T extends ExportMessage>(messages: readonly T[]) => T[];
/** The conversation as Markdown: `# title`, then `## You` and `## Assistant` sections. */
export declare const toMarkdown: (title: string | undefined, messages: readonly ExportMessage[], labels?: Partial<ExportLabels>) => string;
/** The conversation as pretty JSON: `{ thread, messages }`. `thread` is whatever the caller passes (or null). */
export declare const toJson: (thread: unknown, messages: readonly unknown[]) => string;
/** A file name slugged from the title: `Plan the launch!` is `plan-the-launch.md`. */
export declare const exportFileName: (title: string | undefined, extension: string, fallback?: string) => string;
/** Saves text as a file through a temporary link (an object URL where the browser has them, a data URL otherwise). */
export declare const download: (name: string, body: string, type: string) => void;
/** The printable HTML page of a conversation (exported for tests; `printConversation` writes it into a hidden iframe). */
export declare const conversationHtml: (title: string | undefined, messages: readonly ExportMessage[], labels?: Partial<ExportLabels>) => string;
/** Opens the browser print dialog on a printable page of the conversation (the user saves it as PDF). */
export declare const printConversation: (title: string | undefined, messages: readonly ExportMessage[], labels?: Partial<ExportLabels>) => void;
