/** Up to two initials of a name: `Ada Lovelace` is `AL`, `ada` is `A`, an empty name is ``. */
export declare const initialsOf: (name: string | undefined, max?: number) => string;
