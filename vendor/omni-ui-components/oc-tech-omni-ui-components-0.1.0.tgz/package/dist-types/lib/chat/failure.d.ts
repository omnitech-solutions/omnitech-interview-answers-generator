export interface FailureDescription {
    title: string;
    message: string;
}
/**
 * Turn an infrastructure error (network, timeout, rate limit, auth, server, abort) into a plain `{ title, message }` for people.
 * Pure. It only classifies: the raw error text, stack and codes are never returned, and anything unrecognised gets a generic message.
 */
export declare function describeFailure(error: unknown): FailureDescription;
