/** True on Apple platforms (⌘ ⇧ ⌥ glyphs). Pass a platform string to test; default reads `navigator.platform`. */
export declare const isMac: (platform?: string) => boolean;
/**
 * Does the keyboard event match a shortcut string such as `mod+shift+o`? `mod` is Meta or Ctrl, `shift` and `alt` are
 * exact (an unlisted modifier must be up). The last part is the key; it matches `event.key` (case-insensitive) or the
 * physical key (`KeyO`, `Digit1`), so ⌥ on a Mac (which changes `event.key`) still matches.
 */
export declare const matchesShortcut: (event: Pick<KeyboardEvent, "key" | "code" | "metaKey" | "ctrlKey" | "shiftKey" | "altKey">, shortcut: string) => boolean;
/** The key glyphs of a shortcut, one entry per key: `mod+shift+o` is `['⌘', '⇧', 'O']` on a Mac and `['Ctrl', '⇧', 'O']` elsewhere. */
export declare const describeShortcutKeys: (shortcut: string, mac?: boolean) => string[];
/** A shortcut as text: `mod+shift+o` is `⌘ ⇧ O` on a Mac. Use `separator: ''` for `⌘⇧O`. */
export declare const describeShortcut: (shortcut: string, options?: {
    mac?: boolean;
    separator?: string;
}) => string;
export interface HotkeyBinding {
    /** A shortcut string such as `mod+k`. */
    shortcut: string;
    /** Called when the shortcut is pressed; `preventDefault` has already run unless `preventDefault: false`. */
    handler: (event: KeyboardEvent) => void;
    /** Default true. */
    preventDefault?: boolean;
}
export interface UseHotkeysOptions {
    /** Turn every binding off (default true). */
    enabled?: boolean;
    /** Where to listen. Default `window`. */
    target?: Pick<Window, 'addEventListener' | 'removeEventListener'> | null;
}
/**
 * Listens for shortcut strings on `window`: the first binding that matches handles the event. Bindings may change on
 * every render (the latest list is read through a ref), so callers never memoise them.
 *
 * @example
 * useHotkeys([{ shortcut: 'mod+k', handler: () => searchRef.current?.focus() }]);
 */
export declare const useHotkeys: (bindings: readonly HotkeyBinding[], options?: UseHotkeysOptions) => void;
