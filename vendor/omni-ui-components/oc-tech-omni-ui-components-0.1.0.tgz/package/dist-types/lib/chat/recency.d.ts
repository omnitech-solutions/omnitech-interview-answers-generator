/** The five recency buckets of a conversation list, in display order. */
export type RecencyGroupKey = 'pinned' | 'today' | 'week' | 'month' | 'older';
export declare const RECENCY_GROUP_ORDER: readonly RecencyGroupKey[];
/** English default headings; pass `labels` to translate any of them. */
export declare const DEFAULT_RECENCY_LABELS: Record<RecencyGroupKey, string>;
export interface RecencyGroup<T> {
    key: RecencyGroupKey;
    label: string;
    items: T[];
}
export interface GroupByRecencyOptions<T> {
    /** Items for which this returns true go to the `pinned` group. Omit (or pass `false`) to disable the pinned group. */
    pinned?: false | ((item: T) => boolean);
    /** The timestamp of an item (ISO string, epoch ms or Date). Default: the item's `updatedAt`. */
    at?: (item: T) => string | number | Date;
    /** Heading overrides. */
    labels?: Partial<Record<RecencyGroupKey, string>>;
}
/**
 * The bucket of one timestamp. Day boundaries are local midnight (as in omnitech-assistant's `dateGroup`):
 * today is on or after midnight, week is the 7 days before it, month the 30 days before it, everything else older.
 * An unparseable timestamp is `older`.
 */
export declare const recencyGroupOf: (at: string | number | Date, now?: Date | number, pinned?: boolean) => RecencyGroupKey;
/**
 * Groups items by recency: Pinned, Today, Previous 7 days, Previous 30 days, Older. Empty groups are dropped, the
 * input order is kept inside each group (the caller sorts), and nothing is mutated.
 *
 * @example
 * groupByRecency(threads, new Date(), { pinned: (t) => t.pinned })
 */
export declare const groupByRecency: <T>(items: readonly T[], now?: Date | number, options?: GroupByRecencyOptions<T>) => RecencyGroup<T>[];
