import { FieldLayoutProps } from '../Input/Input.variants';
import type * as React from 'react';
export interface FieldChromeArgs {
    id?: string;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    invalid?: boolean;
    required?: boolean;
    /**
     * For a control whose role cannot carry `aria-required` (a button that opens a list or a dialog, a slider, a
     * group): when it is required, the shell draws a "Required" hint for assistive technology and the control is
     * described by it.
     */
    requiredHint?: boolean;
    prefix: string;
}
export interface FieldChrome {
    id: string;
    isInvalid: boolean;
    descriptionId?: string;
    errorId?: string;
    /** Id of the hidden "Required" hint; pass it to {@link FieldShell}. Set only with `requiredHint` on a required field. */
    requiredId?: string;
    describedBy?: string;
}
export declare function useFieldChrome({ id, label: _label, description, error, invalid, required, requiredHint, prefix, }: FieldChromeArgs): FieldChrome;
export interface FieldShellProps extends FieldLayoutProps {
    id: string;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    required?: boolean;
    descriptionId?: string;
    errorId?: string;
    /** From {@link useFieldChrome} with `requiredHint`: draws the hidden "Required" hint the control is described by. */
    requiredId?: string;
    /** A line under the control that stays visible beside the description and the error (a schema form's `ui:help`). */
    help?: React.ReactNode;
    helpId?: string;
    /** A node at the end of the label row (a link or a button the host supplies). */
    labelAction?: React.ReactNode;
    /** The words of the hidden "Required" hint. Default `Required`. */
    requiredLabel?: string;
    labelTag?: 'label' | 'span';
    labelId?: string;
    role?: string;
    ariaLabelledBy?: string;
    wrapperClassName?: string;
    labelClassName?: string;
    children: React.ReactNode;
}
export declare const FieldShell: React.FC<FieldShellProps>;
