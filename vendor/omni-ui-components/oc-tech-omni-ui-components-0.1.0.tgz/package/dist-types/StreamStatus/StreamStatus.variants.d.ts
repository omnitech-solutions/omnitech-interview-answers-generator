import { VariantProps } from 'class-variance-authority';
export declare const streamStatusVariants: (props?: ({
    tone?: "neutral" | "success" | "warning" | "danger" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type StreamStatusVariantProps = VariantProps<typeof streamStatusVariants>;
export declare const streamStatusPulseClasses = "animate-pulse motion-reduce:animate-none";
export declare const streamStatusTimerClasses = "tabular-nums opacity-80";
