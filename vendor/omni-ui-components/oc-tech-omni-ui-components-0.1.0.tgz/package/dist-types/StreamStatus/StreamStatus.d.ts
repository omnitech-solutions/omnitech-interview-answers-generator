import { StreamStatusLabels, StreamStatusProps } from './StreamStatus.types';
import * as React from 'react';
/** English defaults for every string. */
export declare const DEFAULT_STREAM_STATUS_LABELS: StreamStatusLabels;
/**
 * Omni StreamStatus: one status line for a streaming reply: a tool call (`Calling X…`, `X completed`, `X failed`), reasoning
 * (`Reasoning…`) or a stall notice, with an `mm:ss` elapsed timer that starts when the component mounts (or at `startedAt`)
 * and stops once a tool call has completed or failed. It is a polite live region (`role="status"`); the timer is not announced.
 *
 * @example
 * <StreamStatus kind="tool" toolName="search_docs" status="running" />
 */
export declare const StreamStatus: React.ForwardRefExoticComponent<StreamStatusProps & React.RefAttributes<HTMLDivElement>>;
