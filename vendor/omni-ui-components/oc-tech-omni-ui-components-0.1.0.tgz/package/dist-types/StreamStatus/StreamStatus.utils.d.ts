/** `mm:ss` for a number of elapsed milliseconds (never negative; minutes grow past 59). */
export declare function formatElapsed(ms: number): string;
