type NotificationApi = {
    success: (args: {
        message: string;
        description?: string;
    }) => void;
    error: (args: {
        message: string;
        description?: string;
    }) => void;
    info: (args: {
        message: string;
        description?: string;
    }) => void;
    warning: (args: {
        message: string;
        description?: string;
    }) => void;
};
export declare const notification: NotificationApi;
export {};
