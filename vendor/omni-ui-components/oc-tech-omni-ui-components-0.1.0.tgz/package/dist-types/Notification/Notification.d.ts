import { MessageTone } from '../Message/Message';
export interface NotificationArgs {
    message: string;
    description?: string;
    /** Milliseconds on screen; 0 keeps it until Escape. Default: the toast's. */
    duration?: number;
}
export type NotificationApi = Record<MessageTone, (args: NotificationArgs) => void>;
/**
 * A titled notice from anywhere, without rendering a component. It is the library `Toast` (role `status`), raised
 * at the top right with the title over the description; one notice is on screen at a time.
 */
export declare const notification: NotificationApi;
