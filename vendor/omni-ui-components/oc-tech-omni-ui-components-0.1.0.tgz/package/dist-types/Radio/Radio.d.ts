import { RadioProps } from './Radio.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Radio group. Composes {@link RadioPrimitive} with
 * a label / description / error stack mirroring Input + Select.
 *
 * @example
 * <Radio
 *   label="Billing plan"
 *   required
 *   value={plan}
 *   onChange={setPlan}
 *   options={[
 *     { value: 'free', label: 'Free' },
 *     { value: 'pro',  label: 'Pro', description: '$15 / month' },
 *   ]}
 * />
 */
declare const RadioInner: React.ForwardRefExoticComponent<RadioProps & React.RefAttributes<HTMLDivElement>>;
export declare const Radio: typeof RadioInner;
export {};
