import { RadioPrimitiveProps } from './Radio.types';
import * as React from 'react';
/**
 * Raw Omni Radio primitive — composes the shadcn RadioGroup +
 * RadioGroupItem with per-option label + optional description rows.
 *
 * Defaults to `vertical` orientation (stacked) like the shadcn primitive;
 * pass `orientation="horizontal"` to lay options inline (mirrors RJSF's
 * `ui:options.inline=true`).
 *
 * Wrapped in `React.memo` so RJSF parent re-renders only touch fields
 * whose props actually changed.
 */
declare const RadioPrimitiveInner: React.ForwardRefExoticComponent<RadioPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
export declare const RadioPrimitive: typeof RadioPrimitiveInner;
export {};
