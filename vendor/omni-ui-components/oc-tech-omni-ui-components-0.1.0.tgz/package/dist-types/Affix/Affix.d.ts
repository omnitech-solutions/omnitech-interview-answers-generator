import * as React from 'react';
export interface AffixProps extends React.HTMLAttributes<HTMLDivElement> {
    offsetTop?: number;
    offsetBottom?: number;
}
export declare const Affix: React.ForwardRefExoticComponent<AffixProps & React.RefAttributes<HTMLDivElement>>;
