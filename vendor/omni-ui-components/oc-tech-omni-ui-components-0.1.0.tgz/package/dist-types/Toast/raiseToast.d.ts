import { ToastItem, ToastPlacement } from './Toast.types';
/** A toast raised from outside React, with where it is drawn. */
export interface RaisedToast extends ToastItem {
    placement?: ToastPlacement;
}
/**
 * Shows a `Toast` without rendering one: the first call mounts a single host at the end of `document.body`, and
 * each call replaces the toast on screen (as `useToast().notify` does). Does nothing where there is no document.
 * `message` and `notification` are built on it; inside React, prefer `useToast` and your own `<Toast>`.
 */
export declare const raiseToast: (toast: RaisedToast) => void;
/** Removes the raised toast and its host (a test's cleanup, a micro-frontend unmounting). */
export declare const clearRaisedToast: () => void;
