import * as React from 'react';
/** Checklist progress of one item. */
export type ChecklistState = 'done' | 'current' | 'pending';
/**
 * A step. The default variant uses `title` / `status`; the `checklist` variant
 * uses `label` (falls back to `title`) and `state`.
 */
export type StepItem = {
    key?: React.Key;
    title?: React.ReactNode;
    label?: React.ReactNode;
    state?: ChecklistState;
    description?: React.ReactNode;
    status?: 'wait' | 'process' | 'finish' | 'error';
    disabled?: boolean;
};
export interface StepsProps extends Omit<React.HTMLAttributes<HTMLOListElement>, 'onChange'> {
    /**
     * `default`: numbered, clickable steps. `checklist`: a read-only vertical list
     * (done check / current spinning ring / pending circle) for analysis progress.
     */
    variant?: 'default' | 'checklist';
    items?: StepItem[];
    current?: number;
    direction?: 'horizontal' | 'vertical';
    size?: 'default' | 'small';
    status?: 'wait' | 'process' | 'finish' | 'error';
    onChange?: (current: number) => void;
}
export declare const Steps: React.ForwardRefExoticComponent<StepsProps & React.RefAttributes<HTMLOListElement>>;
