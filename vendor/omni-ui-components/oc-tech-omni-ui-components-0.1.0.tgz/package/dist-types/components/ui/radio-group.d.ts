import { Item, Root } from '@radix-ui/react-radio-group';
import type * as React from 'react';
/**
 * Shadcn-style RadioGroup root + item primitives. Omni wraps these in
 * `omni-ui-components/Radio` — feature code should import from there,
 * not directly.
 */
declare function RadioGroup({ className, ...props }: React.ComponentProps<typeof Root>): React.JSX.Element;
declare function RadioGroupItem({ className, ...props }: React.ComponentProps<typeof Item>): React.JSX.Element;
export { RadioGroup, RadioGroupItem };
