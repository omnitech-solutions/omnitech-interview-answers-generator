import { Root } from '@radix-ui/react-slider';
import * as React from 'react';
/**
 * Shadcn-style Slider primitive. Omni wraps this in
 * `omni-ui-components/Slider` — feature code should import from there.
 */
declare function Slider({ className, defaultValue, value, min, max, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledBy, 'aria-describedby': ariaDescribedBy, ...props }: React.ComponentProps<typeof Root>): React.JSX.Element;
export { Slider };
