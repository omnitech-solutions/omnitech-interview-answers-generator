import { default as React } from 'react';
declare const alertVariants: (props?: ({
    variant?: "success" | "warning" | "error" | "info" | "loading" | null | undefined;
    size?: "default" | "sm" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type AlertVariant = 'info' | 'warning' | 'error' | 'loading' | 'success';
export type AlertSize = 'default' | 'sm';
export type AlertProps = {
    variant?: AlertVariant;
    size?: AlertSize;
    icon?: React.ReactNode | null;
    title?: React.ReactNode;
    className?: string;
    children?: React.ReactNode;
};
declare const Alert: React.ForwardRefExoticComponent<AlertProps & React.RefAttributes<HTMLDivElement>>;
export { Alert, alertVariants };
