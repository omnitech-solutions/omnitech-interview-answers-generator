import { MessageItem, MessageMenuProps } from './MessageMenu.types';
import * as React from 'react';
/**
 * The per-message menu, built on `ActionMenu`: copy, hide / unhide, delete behind an inline "cannot be undone" confirm,
 * and an optional "Download conversation". A row exists only when its callback is passed. Escape closes the confirm and
 * returns to the rows; a second Escape closes the menu.
 *
 * @example
 * <MessageMenu message={message} trigger={<button>More</button>} onCopy={notify} onHide={toggleHidden} onDelete={remove} />
 */
export declare function MessageMenu<T extends MessageItem = MessageItem>({ message, trigger, onCopy, onHide, onDelete, conversation, labels, icons, open: openProp, defaultOpen, onOpenChange, side, align, width, portal, container, className, 'data-testid': testId, }: MessageMenuProps<T>): React.JSX.Element;
export declare namespace MessageMenu {
    var displayName: string;
}
