import { CalendarPrimitiveProps } from './Calendar.types';
import * as React from 'react';
/**
 * An always-open month grid that holds ONE day: the date choice as a typed control (`value`, `onChange(next)`),
 * for a form that shows the calendar instead of hiding it behind a field. Use {@link CalendarField} for the
 * variant with a label, a description and an error; use `Calendar` for the raw grid with every
 * `react-day-picker` prop.
 *
 * Keyboard is the grid's own: arrow keys move by day and week, Page Up / Page Down by month, Enter or Space
 * chooses. Read-only keeps the grid focusable and browsable and refuses the choice.
 *
 * @example
 * <CalendarPrimitive value={day} onChange={setDay} min={new Date()} />
 */
declare const CalendarPrimitiveInner: React.ForwardRefExoticComponent<CalendarPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
export declare const CalendarPrimitive: typeof CalendarPrimitiveInner;
export {};
