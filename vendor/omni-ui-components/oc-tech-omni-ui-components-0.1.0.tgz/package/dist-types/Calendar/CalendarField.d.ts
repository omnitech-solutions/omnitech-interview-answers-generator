import { CalendarFieldProps } from './Calendar.types';
import * as React from 'react';
/**
 * {@link CalendarPrimitive} inside the shared field chrome: label, required mark, description and error.
 *
 * @example
 * <CalendarField label="Start date" description="Weekdays only." value={day} onChange={setDay} />
 */
declare const CalendarFieldInner: React.ForwardRefExoticComponent<CalendarFieldProps & React.RefAttributes<HTMLDivElement>>;
export declare const CalendarField: typeof CalendarFieldInner;
export {};
