import { DayPickerProps } from 'react-day-picker';
import * as React from 'react';
export type CalendarProps = DayPickerProps;
export declare const Calendar: React.MemoExoticComponent<React.ForwardRefExoticComponent<DayPickerProps & React.RefAttributes<HTMLDivElement>>>;
