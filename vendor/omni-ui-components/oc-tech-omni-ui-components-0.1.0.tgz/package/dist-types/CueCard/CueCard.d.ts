import { CueCardLabels, CueCardProps, CueSegment, HeardLineProps } from './CueCard.types';
import * as React from 'react';
/** English strings of {@link CueCard}. */
export declare const DEFAULT_CUE_CARD_LABELS: CueCardLabels;
/** Generic over the segment type: an extended segment reaches `onSourceSelect` by reference. */
export declare const CueCard: <S extends CueSegment = CueSegment>(props: CueCardProps<S> & React.RefAttributes<HTMLElement>) => React.ReactElement | null;
/**
 * Omni HeardLine: a sentence as it was heard, for placing what follows and not for reading out. All grey it
 * cannot be scanned and all foreground it competes with the card under it, so the words that carry it are lifted
 * a little and the rest stays quiet. It is cut after `maxLines`; the whole sentence is in its tooltip.
 *
 * Slots: `data-slot="heard-line" | "heard-line-label" | "heard-line-text"`.
 *
 * @example
 * <HeardLine label="Follow-up · 11:46" tone="ask" pieces={[{ text: 'What about ' }, { text: 'event-driven approaches', strong: true }]} />
 */
export declare const HeardLine: React.ForwardRefExoticComponent<HeardLineProps & React.RefAttributes<HTMLDivElement>>;
