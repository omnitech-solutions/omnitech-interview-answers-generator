import { CueCardLabels, CueCardProps, CueLine, CueLineInput, CueSegment, HeardLineProps } from './CueCard.types';
import * as React from 'react';
/** English strings of {@link CueCard}. */
export declare const DEFAULT_CUE_CARD_LABELS: CueCardLabels;
/**
 * Any short form of a line as a {@link CueLine}. A string is a sentence with its key words marked
 * (`**cue**`, `==evidence==`, `!!caution!!`); a list is its pieces, where a string is spoken text taken
 * exactly as written.
 */
export declare function toCueLine<S extends CueSegment = CueSegment>(line: CueLineInput<S>): CueLine<S>;
/**
 * The pieces of one {@link CueLine}, each drawn by its role (spoken, cue, evidence, caution, context). It is what
 * every line of a {@link CueCard} is made of, and is usable on its own inside any text element.
 *
 * Slot: `data-slot="cue-card-segment"` with `data-role`.
 *
 * @example
 * <p><CueLineText line={{ segments: [{ text: 'Start with ' }, { text: 'the result', role: 'cue' }] }} /></p>
 */
export declare function CueLineText<S extends CueSegment = CueSegment>({ line, inferred, onSourceSelect, }: {
    line: CueLineInput<S>;
    /** Tooltip of a piece whose grounding is `inferred`. */
    inferred?: string;
    /** A piece with a `source` was pressed. Without it the pieces are plain text. */
    onSourceSelect?: ((segment: S) => void) | undefined;
}): React.ReactElement;
/** Generic over the segment type: an extended segment reaches `onSourceSelect` by reference. */
export declare const CueCard: <S extends CueSegment = CueSegment>(props: CueCardProps<S> & React.RefAttributes<HTMLElement>) => React.ReactElement | null;
/**
 * Omni HeardLine: a sentence as it was heard, for placing what follows and not for reading out. All grey it
 * cannot be scanned and all foreground it competes with the card under it, so the words that carry it are lifted
 * a little and the rest stays quiet. It is cut after `maxLines`; the whole sentence is in its tooltip.
 *
 * Slots: `data-slot="heard-line" | "heard-line-label" | "heard-line-text"`.
 *
 * @example
 * <HeardLine label="Follow-up · 11:46" tone="ask" pieces={[{ text: 'What about ' }, { text: 'event-driven approaches', strong: true }]} />
 */
export declare const HeardLine: React.ForwardRefExoticComponent<HeardLineProps & React.RefAttributes<HTMLDivElement>>;
