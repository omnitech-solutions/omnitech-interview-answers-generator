import * as React from 'react';
export interface CollapseItem {
    key: React.Key;
    label: React.ReactNode;
    /** A quiet second line under the label, shown open or closed: a role, a date, a path. */
    description?: React.ReactNode;
    children: React.ReactNode;
    extra?: React.ReactNode;
    disabled?: boolean;
}
export interface CollapseProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    items: CollapseItem[];
    defaultActiveKey?: React.Key | React.Key[];
    activeKey?: React.Key | React.Key[];
    accordion?: boolean;
    onChange?: (activeKeys: React.Key[]) => void;
    /** `small` tightens the header and the body for a narrow column. Default `default`. */
    size?: 'default' | 'small';
    /** `accent` marks the whole group as the chosen one: an accent border and tint. Default `default`. */
    tone?: 'default' | 'accent';
}
/**
 * Omni Collapse: a group of headers that each open a body. A header is one button (`aria-expanded`) with its
 * `label`, an optional quiet `description` under it and an optional `extra` node at the end (a `Tag`, a count).
 *
 * Slots: `data-slot="collapse" | "collapse-item" | "collapse-header" | "collapse-label" |
 * "collapse-description" | "collapse-extra" | "collapse-content"`. The root carries `data-size` and `data-tone`.
 *
 * @example
 * <Collapse size="small" items={[{ key: 'api', label: 'API', description: 'v2 · stable', children: <Descriptions items={facts} /> }]} />
 */
export declare function Collapse({ items, defaultActiveKey, activeKey, accordion, onChange, size, tone, className, ...props }: CollapseProps): React.JSX.Element;
