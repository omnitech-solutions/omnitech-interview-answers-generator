import * as React from 'react';
export interface CollapseItem {
    key: React.Key;
    label: React.ReactNode;
    children: React.ReactNode;
    extra?: React.ReactNode;
    disabled?: boolean;
}
export interface CollapseProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    items: CollapseItem[];
    defaultActiveKey?: React.Key | React.Key[];
    activeKey?: React.Key | React.Key[];
    accordion?: boolean;
    onChange?: (activeKeys: React.Key[]) => void;
}
export declare function Collapse({ items, defaultActiveKey, activeKey, accordion, onChange, className, ...props }: CollapseProps): React.JSX.Element;
