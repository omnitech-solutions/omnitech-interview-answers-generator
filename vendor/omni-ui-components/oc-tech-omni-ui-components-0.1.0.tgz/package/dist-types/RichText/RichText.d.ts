import { FieldLayoutProps } from '../Input/Input.variants';
import { RootProps } from '../lib';
import * as React from 'react';
export interface RichTextProps extends RootProps, FieldLayoutProps {
    id?: string;
    name?: string;
    /** HTML string value. */
    value?: string;
    onChange?: (next: string) => void;
    placeholder?: string;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    wrapperClassName?: string;
    labelClassName?: string;
    className?: string;
    'data-testid'?: string;
}
/** Chrome-wrapped Omni RichText. */
export declare const RichText: React.NamedExoticComponent<RichTextProps>;
