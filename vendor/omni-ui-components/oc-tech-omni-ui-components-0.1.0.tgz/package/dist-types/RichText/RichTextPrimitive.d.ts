import * as React from 'react';
export interface RichTextPrimitiveProps {
    id?: string;
    name?: string;
    value?: string;
    onChange?: (next: string) => void;
    placeholder?: string;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw TipTap editor + toolbar (no chrome). */
export declare const RichTextPrimitive: React.ForwardRefExoticComponent<RichTextPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
