import { AlertProps } from './Alert.types';
import * as React from 'react';
declare const AlertInner: React.ForwardRefExoticComponent<AlertProps & React.RefAttributes<HTMLDivElement>>;
export declare const Alert: typeof AlertInner;
export {};
