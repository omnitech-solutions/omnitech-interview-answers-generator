import * as React from 'react';
export interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
    active?: boolean;
}
export declare const Skeleton: React.MemoExoticComponent<React.ForwardRefExoticComponent<SkeletonProps & React.RefAttributes<HTMLDivElement>>>;
