import * as React from 'react';
export interface CarouselProps extends React.HTMLAttributes<HTMLDivElement> {
    children?: React.ReactNode;
}
export declare function Carousel({ children, className, ...props }: CarouselProps): React.JSX.Element;
