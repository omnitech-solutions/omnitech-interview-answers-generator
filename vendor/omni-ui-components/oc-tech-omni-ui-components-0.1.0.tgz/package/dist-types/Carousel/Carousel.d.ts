import * as React from 'react';
export interface CarouselProps extends React.HTMLAttributes<HTMLDivElement> {
    children?: React.ReactNode;
    /** Names of the two buttons, for assistive technology. */
    labels?: {
        previous?: string;
        next?: string;
    };
}
export declare function Carousel({ children, className, labels, ...props }: CarouselProps): React.JSX.Element;
