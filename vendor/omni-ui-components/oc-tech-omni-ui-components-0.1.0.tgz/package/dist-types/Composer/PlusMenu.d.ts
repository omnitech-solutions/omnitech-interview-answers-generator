import { PlusMenuProps } from './Composer.types';
/**
 * The composer's `+` menu: the library ActionMenu configured from `items` (icon, label, description, `onClick`, and
 * `separated` for a divider before a group). The trigger is a round IconButton whose `aria-expanded` Radix keeps
 * in sync; focus returns to it when the menu closes from the keyboard.
 * Slot: `data-slot="plus-menu"` on the trigger.
 *
 * @example
 * <PlusMenu icon={<Plus />} items={[{ id: 'file', label: 'Upload a file', description: 'Text, Markdown or PDF', icon: <Paperclip />, onClick: openPicker }]} />
 */
export declare function PlusMenu({ items, icon, label, appearance, side, align, width, ...rest }: PlusMenuProps): import("react").JSX.Element | null;
