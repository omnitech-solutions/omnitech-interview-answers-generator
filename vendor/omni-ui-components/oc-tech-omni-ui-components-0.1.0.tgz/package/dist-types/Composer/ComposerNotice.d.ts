import { ComposerNoticeProps } from './Composer.types';
import * as React from 'react';
/**
 * A small inline callout above the composer, for a capability warning (an image is attached but the model cannot
 * see it) with one optional action (`Switch`). A polite `<output>` (as the original), tinted from the `--oui-tone-*`
 * scale in light and dark. The library `Alert` is a form-sized card with fixed spacing and no action slot, so this is
 * a purpose-built row instead. Slot: `data-slot="composer-notice"`.
 *
 * @example
 * <ComposerNotice message="Haiku can't see images. Switch to Sonnet?" icon={<EyeOff />} action={{ label: 'Switch', onClick: switchModel }} />
 */
export declare const ComposerNotice: React.ForwardRefExoticComponent<ComposerNoticeProps & React.RefAttributes<HTMLOutputElement>>;
