import { AttachmentItem } from '../Attachment';
import { QueuedItem } from '../QueuedList';
import { ComposerProps } from './Composer.types';
import * as React from 'react';
export declare const Composer: <A extends AttachmentItem = AttachmentItem, Q extends QueuedItem = QueuedItem>(props: ComposerProps<A, Q> & {
    ref?: React.Ref<HTMLDivElement>;
}) => React.ReactElement | null;
