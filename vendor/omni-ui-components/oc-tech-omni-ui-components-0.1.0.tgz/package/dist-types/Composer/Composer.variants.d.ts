/**
 * The composer box. Its background follows `--oui-panel-see-through` the way the panel Input does (the dock colour
 * mixed with the token, backgrounds only); the border brightens on focus.
 */
export declare const composerBoxVariants: (props?: ({
    variant?: "stacked" | "pill" | null | undefined;
    disabled?: boolean | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
/** The textarea: borderless, transparent, grows with its content (height is set inline up to `maxHeight`). */
export declare const composerTextareaClasses: string;
/** Round 34px control (send, plus). */
export declare const composerRoundClasses = "size-[34px] flex-none rounded-full";
export declare const composerHintClasses = "px-1 pt-1 text-[11.5px] text-[color:var(--oui-panel-meta-fg)]";
export declare const composerNoticeVariants: (props?: ({
    tone?: "neutral" | "accent" | "warning" | "danger" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
