import { SendButtonProps } from './Composer.types';
import * as React from 'react';
/**
 * The composer's round send control, in four states: `idle` (nothing to send: disabled arrow), `ready` (a draft: accent
 * arrow, `Send (Enter)`), `streaming` (a reply runs and the draft is empty: stop, `Stop (Esc)`) and `queue` (a reply runs
 * and there is a draft: `Queue message`). The state is decided by the caller (see `sendStateOf`); the icons are nodes
 * and the titles come from `labels`. Stop and queue are never disabled. Slot: `data-slot="send-button"` with `data-state`.
 *
 * @example
 * <SendButton state={sendStateOf({ streaming, hasDraft })} sendIcon={<ArrowUp />} stopIcon={<Square />} queueIcon={<ListPlus />} onClick={submit} />
 */
export declare const SendButton: React.ForwardRefExoticComponent<SendButtonProps & React.RefAttributes<HTMLButtonElement>>;
