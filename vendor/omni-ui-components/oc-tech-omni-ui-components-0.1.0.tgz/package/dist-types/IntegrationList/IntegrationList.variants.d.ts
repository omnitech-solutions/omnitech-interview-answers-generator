/** The status dot beside a row's detail, on the tone scale. */
export declare const integrationStatusVariants: (props?: ({
    status?: "off" | "other" | "connected" | "unreachable" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
