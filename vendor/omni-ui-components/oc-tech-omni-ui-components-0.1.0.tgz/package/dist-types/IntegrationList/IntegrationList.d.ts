import { IntegrationItem, IntegrationListLabels, IntegrationListProps } from './IntegrationList.types';
import * as React from 'react';
export declare const DEFAULT_INTEGRATION_LIST_LABELS: IntegrationListLabels;
/**
 * Omni IntegrationList: the tools an assistant may use. Rows (icon tile, name, detail with a status dot, switch,
 * remove), an add-by-address form, loading and empty states. Today's rows are MCP servers; an OAuth variant fits
 * the same list through `connectAction` (list header) and each row's `account` and `connectAction`. Callbacks:
 * `onToggle(id, enabled)`, `onRemove(id)`, `onAdd(url)`.
 *
 * Slots: `data-slot="integration-list" | "integration-row" | "integration-add"`.
 *
 * @example
 * <IntegrationList items={servers} onToggle={toggle} onRemove={remove} onAdd={add} itemIcon={<Network />} removeIcon={<Trash2 />} />
 */
export declare const IntegrationList: <I extends IntegrationItem = IntegrationItem>({ items, loading, intro, onToggle, onRemove, onAdd, empty, itemIcon, removeIcon, connectAction, labels: labelOverrides, className, }: IntegrationListProps<I>) => React.JSX.Element;
