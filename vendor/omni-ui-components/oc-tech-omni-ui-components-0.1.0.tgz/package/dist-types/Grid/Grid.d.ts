import type * as React from 'react';
/** Columns per container width: `base` always, then from 640, 768 and 1024 pixels of the row's own width. */
export interface RowColumns {
    base?: number;
    sm?: number;
    md?: number;
    lg?: number;
}
export interface RowProps extends React.HTMLAttributes<HTMLDivElement> {
    /** The gap in pixels, or `[horizontal, vertical]`. */
    gutter?: number | [number, number];
    /**
     * The row is a grid of this many equal tracks and its children need no `Col`. An object sets the count per
     * width of the row itself (container queries), so a grid inside a narrow panel folds.
     */
    columns?: number | RowColumns;
    /** The row is a grid that fits as many tracks of at least this many pixels as there is room for. */
    minItemWidth?: number;
}
export interface ColProps extends React.HTMLAttributes<HTMLDivElement> {
    span?: number;
}
/**
 * Omni Row: a wrapping flex row of `Col`s, or with `columns` or `minItemWidth` a CSS grid whose children are the
 * cells (`data-layout="grid"`).
 *
 * @example
 * <Row minItemWidth={260} gutter={16}>{cards}</Row>
 * <Row columns={{ base: 1, sm: 2, lg: 4 }} gutter={[16, 24]}>{cards}</Row>
 */
export declare const Row: ({ gutter, columns, minItemWidth, className, style, ...props }: RowProps) => React.JSX.Element;
export declare const Col: ({ span, className, style, ...props }: ColProps) => React.JSX.Element;
