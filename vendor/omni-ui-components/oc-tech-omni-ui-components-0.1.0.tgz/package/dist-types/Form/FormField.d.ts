import { FormFieldProps } from './Form.types';
import * as React from 'react';
/**
 * Binds a single field to the surrounding {@link Form}. Thin wrapper around
 * `@tanstack/react-form`'s `form.Field` that adapts the TanStack render-prop
 * shape into Omni's `{id, value, onChange, error, ...}` contract so any
 * `components/Input`-shaped primitive can be dropped in.
 *
 * @example
 * <FormField name="email" required>
 *   {({ id, value, onChange, error, required }) => (
 *     <Input id={id} type="email" label="Email" required={required}
 *       value={(value as string) ?? ''} onChange={onChange} error={error}
 *     />
 *   )}
 * </FormField>
 */
export declare function FormField<TValue = unknown>({ name, required, children, }: FormFieldProps<TValue>): React.JSX.Element;
