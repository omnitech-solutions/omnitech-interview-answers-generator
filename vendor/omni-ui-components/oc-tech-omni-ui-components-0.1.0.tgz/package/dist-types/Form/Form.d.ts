import { FormProps } from './Form.types';
declare function FormImpl<TFormData, TSubmitData = TFormData>(props: FormProps<TFormData, TSubmitData>): JSX.Element;
export declare const Form: typeof FormImpl;
export type OmniFormApi = any;
export {};
