import { FormProps } from './Form.types';
/**
 * Omni Form primitive. Wraps `@tanstack/react-form`'s `useForm` for state
 * (touched / dirty / async validators / array fields) and adds Omni's
 * Zod-gated submit contract.
 *
 * Submit contract (mirrors `dynamic-form`'s `DynamicForm`):
 * - Zod parse success → `onSubmit(parsed)` (awaited).
 * - Zod parse failure → `onError(errors)` with `source: 'zod'`.
 * - `onSubmit` throw / rejection → `onError([{ source: 'api', ... }])`.
 *
 * @example
 * <Form zodSchema={schema} formData={initial} onSubmit={save} onError={setErrors}>
 *   <FormField name="title">
 *     {({ id, value, onChange, error }) => (
 *       <Input id={id} label="Title" value={(value as string) ?? ''} onChange={onChange} error={error} />
 *     )}
 *   </FormField>
 *   <button type="submit">Save</button>
 * </Form>
 */
declare function FormImpl<TFormData, TSubmitData = TFormData>(props: FormProps<TFormData, TSubmitData>): JSX.Element;
export declare const Form: typeof FormImpl;
export type OmniFormApi = any;
export {};
