import { z } from 'zod';
import { FormError } from './Form.types';
/**
 * Translate a Zod issue list into Omni's `FormError[]` shape.
 * Shared by `Form` (via `onSubmitInvalid`) and `DynamicForm` (RJSF adapter).
 */
export declare const zodIssuesToFormErrors: (error: z.ZodError) => FormError[];
