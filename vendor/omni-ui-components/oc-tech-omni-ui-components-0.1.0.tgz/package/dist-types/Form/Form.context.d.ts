import * as React from 'react';
/**
 * Internal context bridging {@link Form} root to descendant {@link FormField}
 * consumers. Carries the TanStack form instance plus Omni-level disabled /
 * readOnly state so fields don't need to re-derive them.
 */
export interface OmniFormContextValue {
    form: any;
    disabled: boolean;
    readOnly: boolean;
}
export declare const FormContext: React.Context<OmniFormContextValue | null>;
/** Hook used by descendants that need direct access to the underlying TanStack form. */
export declare const useFormContext: () => OmniFormContextValue;
