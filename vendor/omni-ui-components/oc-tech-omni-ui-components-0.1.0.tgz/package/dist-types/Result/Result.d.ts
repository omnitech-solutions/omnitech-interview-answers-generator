import type * as React from 'react';
export interface ResultProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
    status?: 'info' | 'success' | 'warning' | 'error';
    title?: React.ReactNode;
    subTitle?: React.ReactNode;
    extra?: React.ReactNode;
}
export declare const Result: ({ status, title, subTitle, extra, className, ...props }: ResultProps) => React.JSX.Element;
