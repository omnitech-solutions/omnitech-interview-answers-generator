import { FeedbackPanelLabels, FeedbackPanelProps, FeedbackReason } from './FeedbackPanel.types';
import * as React from 'react';
/** English strings of {@link FeedbackPanel}. */
export declare const DEFAULT_FEEDBACK_LABELS: FeedbackPanelLabels;
/** Generic over the reason item type: an extended reason reaches every callback by reference. */
export declare const FeedbackPanel: <T extends FeedbackReason = FeedbackReason>(props: FeedbackPanelProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
