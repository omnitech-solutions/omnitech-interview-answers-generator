export declare const feedbackPanelClasses = "flex min-w-0 flex-col gap-2.5 rounded-xl border border-solid border-[color:var(--oui-panel-divider)] p-3 bg-[color:color-mix(in_srgb,var(--oui-panel-bg)_calc(var(--oui-panel-see-through,1)_*_100%),transparent)]";
/** A reason chip: outlined, accent tint when pressed. */
export declare const feedbackChipVariants: (props?: import('class-variance-authority/types').ClassProp | undefined) => string;
