import { VariantProps } from 'class-variance-authority';
import { ControlTone } from '../internal/support/controlTone';
import { ContextLevel } from './ContextMeter.types';
/** The ring's tone per level (`Progress` ring tones). */
export declare const contextLevelTone: Record<ContextLevel, ControlTone>;
/** The fill of the popover bar, per level. */
export declare const contextBarFillVariants: (props?: ({
    level?: "danger" | "normal" | "warn" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type ContextBarFillVariantProps = VariantProps<typeof contextBarFillVariants>;
export declare const contextPopoverClasses = "w-[280px] max-w-[calc(100vw-24px)] p-3 text-[13px]";
