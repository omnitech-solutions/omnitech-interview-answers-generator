import { ContextMeterLabels, ContextMeterProps, ContextSection } from './ContextMeter.types';
import * as React from 'react';
/** English defaults for every string. */
export declare const DEFAULT_CONTEXT_METER_LABELS: ContextMeterLabels;
/** Generic over the section type: extra fields reach `onSummarise` by reference. */
export declare const ContextMeter: <S extends ContextSection = ContextSection>(props: ContextMeterProps<S> & React.RefAttributes<HTMLButtonElement>) => React.ReactElement | null;
