import { ContextLevel, ContextThresholds } from './ContextMeter.types';
export declare const DEFAULT_CONTEXT_THRESHOLDS: ContextThresholds;
/** Tokens in thousands: `3100` → `3.1k`. `digits` 0 gives the window form: `262000` → `262k`. */
export declare const formatTokens: (tokens: number, digits?: number) => string;
/** How full the window is, 0 to 100, rounded; undefined when there is no window to measure against. */
export declare function contextPercent(used: number, window?: number): number | undefined;
/** `normal` up to `warn`, `warn` above it, `danger` above `danger` (both exclusive). No percent is always `normal`. */
export declare function contextLevel(percent: number | undefined, thresholds?: ContextThresholds): ContextLevel;
