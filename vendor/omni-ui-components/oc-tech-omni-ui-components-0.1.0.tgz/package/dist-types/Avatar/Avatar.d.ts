import { AvatarFallbackProps, AvatarProps } from './Avatar.types';
import * as React from 'react';
declare const AvatarInner: React.ForwardRefExoticComponent<AvatarProps & React.RefAttributes<HTMLSpanElement>>;
declare const AvatarImageInner: React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.ImgHTMLAttributes<HTMLImageElement>, HTMLImageElement>, "ref"> & React.RefAttributes<HTMLImageElement>>;
declare const AvatarFallbackInner: React.ForwardRefExoticComponent<AvatarFallbackProps & React.RefAttributes<HTMLSpanElement>>;
export declare const Avatar: typeof AvatarInner;
export declare const OmniAvatarImage: typeof AvatarImageInner;
export declare const OmniAvatarFallback: typeof AvatarFallbackInner;
export {};
