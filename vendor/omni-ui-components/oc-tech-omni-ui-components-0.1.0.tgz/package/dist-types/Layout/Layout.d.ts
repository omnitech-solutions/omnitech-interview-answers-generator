import { ContentProps, HeaderProps, LayoutProps, LayoutSectionProps, SiderProps } from './Layout.types';
import * as React from 'react';
/**
 * Omni Layout: the frame of a page. `direction="row"` lays a `Sider` beside the rest; `fill` makes it the height
 * of the viewport, so a `Content scroll` scrolls and the page does not.
 *
 * @example
 * <Layout direction="row" fill>
 *   <Sider collapsible label="Main navigation" header={brand}><Menu appearance="plain" items={items} /></Sider>
 *   <Layout>
 *     <Header title="Reports" actions={<Button>New</Button>} level={1} />
 *     <Content scroll maxWidth="lg">{page}</Content>
 *   </Layout>
 * </Layout>
 */
declare const LayoutInner: React.ForwardRefExoticComponent<LayoutProps & React.RefAttributes<HTMLElement>>;
export declare const Layout: typeof LayoutInner;
/**
 * Omni Header: a plain `<header>`, or with `title` a page header (eyebrow, a heading of `level`, description,
 * then `meta` and `actions` at the end). Children still render, under the row.
 *
 * Slots: `data-slot="header-row" | "header-eyebrow" | "header-title" | "header-description" | "header-meta" | "header-actions"`.
 */
declare const HeaderInner: React.ForwardRefExoticComponent<HeaderProps & React.RefAttributes<HTMLElement>>;
export declare const Header: typeof HeaderInner;
/**
 * Omni Content: the main region. `maxWidth` is the page container (the content is centred under that width),
 * `center` centres one child both ways, `scroll` scrolls inside, `as` picks the element when a page has a second
 * content region.
 */
declare const ContentInner: React.ForwardRefExoticComponent<ContentProps & React.RefAttributes<HTMLElement>>;
export declare const Content: typeof ContentInner;
declare const FooterInner: React.ForwardRefExoticComponent<LayoutSectionProps & React.RefAttributes<HTMLElement>>;
export declare const Footer: typeof FooterInner;
/**
 * Omni Sider: a plain `<aside>`, or with any of `header`, `footer`, `scroll`, `collapsible`, `collapsed` and
 * `defaultCollapsed` a side column with a pinned header and footer around a body. Collapsed, it is
 * `collapsedWidth` wide and carries `data-collapsed`; the control is drawn only when `collapsible`. The host
 * passes the same state on to what it holds (`<Menu collapsed>`).
 *
 * Slots: `data-slot="sider-header" | "sider-body" | "sider-footer" | "sider-collapse"`.
 */
declare const SiderInner: React.ForwardRefExoticComponent<SiderProps & React.RefAttributes<HTMLElement>>;
export declare const Sider: typeof SiderInner;
export {};
