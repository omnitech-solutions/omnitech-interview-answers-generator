import * as React from 'react';
export interface LayoutSectionProps extends React.HTMLAttributes<HTMLElement> {
}
export declare const Layout: React.ForwardRefExoticComponent<LayoutSectionProps & React.RefAttributes<HTMLElement>>;
export declare const Header: React.ForwardRefExoticComponent<LayoutSectionProps & React.RefAttributes<HTMLElement>>;
export declare const Content: React.ForwardRefExoticComponent<LayoutSectionProps & React.RefAttributes<HTMLElement>>;
export declare const Footer: React.ForwardRefExoticComponent<LayoutSectionProps & React.RefAttributes<HTMLElement>>;
export declare const Sider: React.ForwardRefExoticComponent<LayoutSectionProps & React.RefAttributes<HTMLElement>>;
