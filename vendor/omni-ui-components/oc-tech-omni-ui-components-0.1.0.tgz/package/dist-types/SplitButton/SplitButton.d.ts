import { SplitButtonProps } from './SplitButton.types';
import * as React from 'react';
/**
 * Omni SplitButton: a main action and a caret that opens an ActionMenu, sharing
 * ONE border (the caret has no border of its own, a 1px divider in the border
 * colour separates the halves). The whole control carries a `tone`; `status`
 * puts a badge at its top-right; `state="analysing"` swaps the icon for the
 * progress ring. The main half can be disabled (with a reason) while the caret
 * stays usable. Every callback is a prop.
 *
 * @example
 * <SplitButton
 *   tone="accent"
 *   main={{ label: 'Capture', icon: <Monitor />, tooltip: 'Auto · re-analyses when the screen changes', onPress: capture }}
 *   menu={{ label: 'Capture options', sections, onSelect: choose }}
 *   onOpenChange={reserveRoom}
 * />
 */
export declare const SplitButton: React.ForwardRefExoticComponent<SplitButtonProps & React.RefAttributes<HTMLDivElement>>;
