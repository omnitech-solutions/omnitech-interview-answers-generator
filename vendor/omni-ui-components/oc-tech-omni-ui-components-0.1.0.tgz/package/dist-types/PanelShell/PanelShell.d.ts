import { PanelShellLabels, PanelShellProps } from './PanelShell.types';
import * as React from 'react';
/** English strings of {@link PanelShell}. */
export declare const DEFAULT_PANEL_SHELL_LABELS: PanelShellLabels;
/**
 * Omni PanelShell: the shell of an assistant. In `panel` mode it is a side panel (default 440px) beside the
 * host page; in `full` mode it fills the area and hides the host. It lays out `header`, a body (`children`), an
 * optional docked or overlay `sidebar` and a pinned `footer`; it positions nothing against the window, so it never
 * leaves its parent. Closed (`open={false}`) in panel mode it renders only the host.
 *
 * Compose it from the library parts: ConversationList as `sidebar`, ConversationHeader as `header`, a Transcript
 * or EmptyStarters as `children`, a composer as `footer`, and a Toast (`position="absolute"`) as `overlay`.
 *
 * Slots: `data-slot="panel-shell" | "panel-shell-host" | "panel-shell-panel" | "panel-shell-sidebar" | "panel-shell-main" | "panel-shell-body"`.
 *
 * @example
 * <PanelShell mode={mode} open={open} onOpenChange={setOpen} host={<App />} header={<ConversationHeader … />}
 *   sidebar={<ConversationList … />} sidebarMode={mode === 'full' ? 'docked' : 'overlay'} sidebarOpen={history} footer={<Composer … />}>…</PanelShell>
 */
export declare const PanelShell: ({ mode, width, open: openProp, defaultOpen, onOpenChange, label, host, sidebar, sidebarMode, sidebarOpen: sidebarOpenProp, defaultSidebarOpen, onSidebarOpenChange, sidebarWidth, header, children, footer, overlay, closeOnEscape, labels: labelOverrides, className, panelClassName, "data-testid": testId, }: PanelShellProps) => React.JSX.Element;
