/** The assistant surface: the panel look of the library Panel (radius, border, background), as a flex column. */
export declare const panelShellSurfaceVariants: (props?: ({
    mode?: "panel" | "full" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
