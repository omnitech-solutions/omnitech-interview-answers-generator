type MessageApi = {
    success: (content: string) => void;
    error: (content: string) => void;
    info: (content: string) => void;
    warning: (content: string) => void;
};
export declare const message: MessageApi;
export {};
