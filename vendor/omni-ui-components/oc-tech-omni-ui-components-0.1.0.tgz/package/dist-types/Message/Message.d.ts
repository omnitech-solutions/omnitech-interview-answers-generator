import type * as React from 'react';
export type MessageTone = 'success' | 'error' | 'info' | 'warning';
export type MessageApi = Record<MessageTone, (content: string) => void>;
/** The icon of a tone, painted from its tone token. Shared with `notification`. */
export declare const toneIcon: (tone: MessageTone) => React.ReactNode;
/**
 * A short message from anywhere, without rendering a component. It is the library `Toast` (role `status`,
 * dismissed by its timer or Escape), raised at the top centre; one message is on screen at a time.
 */
export declare const message: MessageApi;
