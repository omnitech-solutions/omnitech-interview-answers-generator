import { VariantProps } from 'class-variance-authority';
/**
 * Colour per state, from the tone tokens. Only the icon, the timer and the paused label change:
 * the clock's own surface is transparent in both states.
 */
export declare const statusClockVariants: (props?: ({
    state?: "paused" | "live" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export declare const statusClockIconVariants: (props?: ({
    state?: "paused" | "live" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export declare const statusClockTimerVariants: (props?: ({
    state?: "paused" | "live" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type StatusClockVariantProps = VariantProps<typeof statusClockVariants>;
