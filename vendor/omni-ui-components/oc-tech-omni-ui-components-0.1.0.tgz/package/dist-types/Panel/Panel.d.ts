import { PanelProps } from './Panel.types';
import * as React from 'react';
/**
 * Omni Panel: a flex-column shell with a 40px header (title, optional subtitle, meta and actions), a body that
 * fills the rest and scrolls inside, and an optional dock pinned at the bottom. Nothing in it is positioned
 * against the window, so a panel never escapes its parent. A parent lays panels out with `width` / `minWidth` /
 * `flex`: for example a 330px (min 300) transcript next to panels that share the rest equally.
 *
 * Callbacks and slots are plain props: `actions` and `dock` take nodes (Buttons with their own `onClick`),
 * `empty` takes the Empty tile config, `scroll` configures the fade, the thin scrollbar and the stick-to-bottom
 * jump pill (`onJumpToLatest`). See-through is a token: set `--oui-panel-see-through` (0-1) and only the panel,
 * header and dock backgrounds become transparent; text and icons stay at full opacity.
 *
 * Slots for host styling: `data-slot="panel" | "panel-header" | "panel-body" | "panel-dock"`.
 *
 * @example
 * <Panel title="Answer" meta="Last capture 08:33 · no question found"
 *   empty={{ icon: <MonitorUp />, title: 'Nothing analysed yet', description: 'Capture to start.' }} />
 * <Panel title="Transcript & chat" width={330} minWidth={300} scroll={{ fade: true, stickToBottom: true }}>{messages}</Panel>
 */
export declare const Panel: React.ForwardRefExoticComponent<PanelProps & React.RefAttributes<HTMLElement>>;
