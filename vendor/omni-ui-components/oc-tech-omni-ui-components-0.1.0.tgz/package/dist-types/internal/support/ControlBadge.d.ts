import { ControlTone } from './controlTone';
import type * as React from 'react';
export interface ControlBadgeProps {
    tone: ControlTone;
    /** Short visible glyph or count, e.g. `'!'`. Omit for a plain dot. */
    label?: string;
    /** Spoken description, wired through `aria-describedby` by the owner via `descriptionId`. */
    description?: string;
    descriptionId?: string;
    /** Owning slot name, e.g. `icon-button-badge`. */
    slot: string;
    /** Extra classes (e.g. a smaller corner offset). */
    className?: string;
}
/**
 * The small status badge at a control's top-right corner (the amber "!"). It is
 * absolutely positioned, so the owning control must be `relative`. The ring cuts
 * it out of the surface behind (`--oui-badge-ring`).
 */
export declare const ControlBadge: React.FC<ControlBadgeProps>;
