/** Attribute a native host reads (by selector) to find portalled surfaces that must stay clickable. */
export declare const SURFACE_ATTRIBUTE = "data-oui-surface";
/** `container` as Radix expects it: `null`/`undefined` means the default (`document.body`). */
export declare const resolvePortalContainer: (container?: HTMLElement | null) => HTMLElement | undefined;
/** Spread onto portalled content so the host can find it; the value names the kind of surface. */
export declare const surfaceProps: (kind: string) => {
    "data-oui-surface": string;
};
