import { IconButtonProps } from '../../IconButton';
import * as React from 'react';
export interface IconActionProps extends Omit<IconButtonProps, 'icon' | 'label' | 'title'> {
    /** Caller-supplied icon node. Without one the first letter of `label` stands in, so a control is never blank. */
    icon?: React.ReactNode;
    /** Accessible name and tooltip. */
    label: string;
    /** Shown after the label in the tooltip: `New chat (⌘ ⇧ O)`. */
    shortcut?: string;
}
/** A compact ghost IconButton for shell chrome (list rows, header, dialog close). The icon is always a caller node. */
export declare const IconAction: React.ForwardRefExoticComponent<IconActionProps & React.RefAttributes<HTMLButtonElement>>;
