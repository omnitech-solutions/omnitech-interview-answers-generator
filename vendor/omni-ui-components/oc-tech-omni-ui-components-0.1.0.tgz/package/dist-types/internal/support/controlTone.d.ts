/**
 * Tone scale shared by Button and IconButton (and any later control that
 * must read as "neutral / accent / success / warning / danger / dim").
 *
 * Colours come from the `--oui-tone-<tone>-*` tokens in `styles/tokens.css`
 * (light + dark), so a surface re-themes the whole scale by overriding
 * tokens, never by passing colours. Class strings are written out in full so
 * Tailwind's source scan can see them.
 */
export type ControlTone = 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'dim';
export declare const CONTROL_TONES: readonly ControlTone[];
/** Filled: solid tone fill (neutral and dim are tinted surfaces with a border). */
export declare const toneSolidClasses: Record<ControlTone, string>;
/** Soft: outlined, transparent until hovered (the outlined red End / outlined Pause). */
export declare const toneSoftClasses: Record<ControlTone, string>;
/** Tint: tinted surface + tone foreground + tone border (icon controls, badges). */
export declare const toneTintClasses: Record<ControlTone, string>;
/** Badge fill per tone: the solid fill and its foreground. */
export declare const toneBadgeClasses: Record<ControlTone, string>;
/** Active (pressed) look: accent tint, whatever the tone. */
export declare const pressedClasses = "aria-pressed:border aria-pressed:border-[color:var(--oui-tone-accent-border)] aria-pressed:bg-[color:var(--oui-tone-accent-bg)] aria-pressed:text-[color:var(--oui-tone-accent-fg)]";
/** Pressed look per tone, so a `danger` toggle (a live mic) is red when pressed instead of the default accent. */
export declare const tonePressedClasses: Record<ControlTone, string>;
/** Foreground per tone (icons, rings, text) for elements that draw with `currentColor`. */
export declare const toneTextClasses: Record<ControlTone, string>;
