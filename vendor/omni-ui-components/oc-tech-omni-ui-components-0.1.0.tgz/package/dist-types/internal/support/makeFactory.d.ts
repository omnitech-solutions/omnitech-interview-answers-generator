export interface Variant<T> {
    name: string;
    args: Partial<T>;
}
export declare const makeFactory: <T extends object>(defaults: T) => (overrides?: Partial<T>) => T;
