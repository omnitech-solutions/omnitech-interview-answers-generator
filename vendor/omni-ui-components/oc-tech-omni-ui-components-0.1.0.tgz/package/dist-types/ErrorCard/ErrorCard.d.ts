import { ErrorCardProps, ErrorItem } from './ErrorCard.types';
import * as React from 'react';
/** Generic over the item type: an extended item reaches every callback by reference. */
export declare const ErrorCard: <T extends ErrorItem = ErrorItem>(props: ErrorCardProps<T> & React.RefAttributes<HTMLDivElement>) => React.ReactElement | null;
