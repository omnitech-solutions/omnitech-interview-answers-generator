export declare const errorCardVariants: (props?: ({
    variant?: "error" | "stopped" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
