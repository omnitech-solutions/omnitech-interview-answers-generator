import * as React from 'react';
export type ThemeMode = 'light' | 'dark';
export type ThemeConfig = {
    mode?: ThemeMode;
    algorithm?: unknown;
    token?: Record<string, string | number>;
    components?: Record<string, Record<string, string | number>>;
    inherit?: boolean;
    tokens?: Record<string, string | number>;
};
export interface ConfigProviderProps {
    children?: React.ReactNode;
    theme?: ThemeConfig;
    componentSize?: 'small' | 'middle' | 'large';
    direction?: 'ltr' | 'rtl';
    prefixCls?: string;
    getPopupContainer?: (trigger?: HTMLElement) => HTMLElement;
    locale?: unknown;
    wave?: {
        disabled?: boolean;
    };
    virtual?: boolean;
    warning?: {
        strict?: boolean;
    };
    csp?: {
        nonce?: string;
    };
}
export declare const ConfigProvider: ({ children, theme, direction }: ConfigProviderProps) => React.JSX.Element;
