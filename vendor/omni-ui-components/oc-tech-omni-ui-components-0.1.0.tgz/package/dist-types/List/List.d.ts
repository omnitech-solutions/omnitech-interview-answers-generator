import * as React from 'react';
export interface ListProps extends React.HTMLAttributes<HTMLUListElement> {
}
export interface ListItemProps extends React.LiHTMLAttributes<HTMLLIElement> {
}
export declare const List: React.MemoExoticComponent<React.ForwardRefExoticComponent<ListProps & React.RefAttributes<HTMLUListElement>>>;
export declare const ListItem: React.MemoExoticComponent<React.ForwardRefExoticComponent<ListItemProps & React.RefAttributes<HTMLLIElement>>>;
