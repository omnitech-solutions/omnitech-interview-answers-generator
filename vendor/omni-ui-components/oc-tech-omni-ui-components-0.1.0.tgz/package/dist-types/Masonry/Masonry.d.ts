import * as React from 'react';
export type MasonryColumns = number | Partial<Record<'xs' | 'sm' | 'md', number>>;
export type MasonryGapValue = number | string;
export type MasonryGap = MasonryGapValue | [MasonryGapValue, MasonryGapValue] | Partial<Record<'xs' | 'sm' | 'md', MasonryGapValue | [MasonryGapValue, MasonryGapValue]>>;
export type MasonrySemantic = 'root' | 'item';
export type MasonrySemanticMap<T> = Partial<Record<MasonrySemantic, T>>;
export interface MasonryItem<T = unknown> {
    key?: React.Key;
    children?: React.ReactNode;
    data?: T;
    column?: number;
    height?: number;
}
export interface MasonryProps<T = unknown> extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> {
    columns?: MasonryColumns;
    fresh?: boolean;
    gutter?: MasonryGap;
    items?: Array<MasonryItem<T> | React.ReactNode>;
    itemRender?: (item: MasonryItem<T> & {
        index: number;
    }) => React.ReactNode;
    onLayoutChange?: (layout: Array<{
        key: React.Key;
        column: number;
    }>) => void;
    classNames?: MasonrySemanticMap<string>;
    styles?: MasonrySemanticMap<React.CSSProperties>;
    prefixCls?: string;
    rootClassName?: string;
    children?: React.ReactNode;
}
export declare const Masonry: React.ForwardRefExoticComponent<MasonryProps<unknown> & React.RefAttributes<HTMLDivElement>>;
