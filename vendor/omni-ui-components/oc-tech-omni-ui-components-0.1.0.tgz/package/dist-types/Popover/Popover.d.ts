import { PopoverAnchorProps, PopoverProps, PopoverTriggerProps } from './Popover.types';
import * as React from 'react';
export declare const Popover: React.FC<PopoverProps>;
export declare const PopoverTriggerRoot: React.FC<PopoverTriggerProps>;
export declare const PopoverAnchorRoot: React.FC<PopoverAnchorProps>;
declare const PopoverContentInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-popover').PopoverContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & {
    container?: HTMLElement | null;
} & React.RefAttributes<HTMLDivElement>>;
export declare const PopoverPanel: typeof PopoverContentInner;
export {};
