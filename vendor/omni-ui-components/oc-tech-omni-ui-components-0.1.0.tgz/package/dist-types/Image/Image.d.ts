import * as React from 'react';
export interface ImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
    preview?: boolean;
}
export declare const Image: React.MemoExoticComponent<React.ForwardRefExoticComponent<ImageProps & React.RefAttributes<HTMLImageElement>>>;
