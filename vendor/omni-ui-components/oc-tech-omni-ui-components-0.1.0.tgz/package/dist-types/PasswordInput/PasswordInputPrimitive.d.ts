import { InputPrimitiveProps } from '../Input/Input.types';
import * as React from 'react';
/** Words of the reveal control. */
export interface PasswordInputLabels {
    show: string;
    hide: string;
}
export declare const DEFAULT_PASSWORD_INPUT_LABELS: PasswordInputLabels;
export interface PasswordInputPrimitiveProps extends Omit<InputPrimitiveProps, 'type'> {
    /** Draw the reveal control at the end of the field. Default false on the primitive (a bare password box). */
    toggleable?: boolean;
    /** Whether the password is shown as text. Controlled; leave it out for the control to keep its own state. */
    revealed?: boolean;
    defaultRevealed?: boolean;
    /** Called with the next state when the person shows or hides the password. */
    onRevealedChange?: (revealed: boolean) => void;
    labels?: Partial<PasswordInputLabels>;
    /** Icon of the control while the password is hidden / shown. */
    showIcon?: React.ReactNode;
    hideIcon?: React.ReactNode;
}
/**
 * Bare password input. With `toggleable`, a reveal control sits at the end of the field: it switches the input
 * between `password` and `text`, says which through `aria-pressed`, and leaves focus in the input.
 *
 * @example
 * <PasswordInputPrimitive toggleable value={password} onChange={setPassword} autoComplete="current-password" />
 */
declare const PasswordInputPrimitiveInner: React.ForwardRefExoticComponent<Omit<PasswordInputPrimitiveProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const PasswordInputPrimitive: typeof PasswordInputPrimitiveInner;
export {};
