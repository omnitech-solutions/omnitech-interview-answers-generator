import { InputPrimitiveProps } from '../Input/Input.types';
import * as React from 'react';
export type PasswordInputPrimitiveProps = Omit<InputPrimitiveProps, 'type'>;
declare const PasswordInputPrimitiveInner: React.ForwardRefExoticComponent<Omit<PasswordInputPrimitiveProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const PasswordInputPrimitive: typeof PasswordInputPrimitiveInner;
export {};
