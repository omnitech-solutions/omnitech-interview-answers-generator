import { InputProps } from '../Input';
import { PasswordInputPrimitiveProps } from './PasswordInputPrimitive';
import * as React from 'react';
export interface PasswordInputProps extends Omit<InputProps, 'type'>, Pick<PasswordInputPrimitiveProps, 'revealed' | 'defaultRevealed' | 'onRevealedChange' | 'labels' | 'showIcon' | 'hideIcon'> {
    /** Show the eye toggle to reveal/hide the password. Default true. */
    toggleable?: boolean;
}
/**
 * Omni PasswordInput: {@link PasswordInputPrimitive} (which owns the reveal control) inside the shared field
 * chrome.
 *
 * @example
 * <PasswordInput label="Password" required value={password} onChange={setPassword} />
 */
declare const PasswordInputInner: React.ForwardRefExoticComponent<Omit<PasswordInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const PasswordInput: typeof PasswordInputInner;
export {};
