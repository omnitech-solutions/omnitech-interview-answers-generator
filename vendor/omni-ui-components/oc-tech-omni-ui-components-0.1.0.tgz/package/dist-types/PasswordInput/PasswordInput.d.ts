import { InputProps } from '../Input';
import * as React from 'react';
export interface PasswordInputProps extends Omit<InputProps, 'type'> {
    /** Show the eye toggle to reveal/hide the password. Default true. */
    toggleable?: boolean;
}
/**
 * Omni PasswordInput — chrome-wrapped {@link PasswordInputPrimitive} with
 * an optional show/hide eye toggle owned by the wrapper.
 */
declare const PasswordInputInner: React.ForwardRefExoticComponent<Omit<PasswordInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const PasswordInput: typeof PasswordInputInner;
export {};
