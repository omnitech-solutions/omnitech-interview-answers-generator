import { SliderPrimitiveProps } from './Slider.types';
import * as React from 'react';
/**
 * Raw Omni Slider primitive. Wraps `components/ui/slider` (Radix
 * Slider) so the Omni wrapper can stay theme-token-aware while the
 * track/thumb visuals match shadcn defaults (primary-tinted track,
 * primary-bordered thumb).
 *
 * Accepts single (number) or range (number[]) values; normalizes both
 * directions at the Radix boundary.
 */
declare const SliderPrimitiveInner: React.ForwardRefExoticComponent<SliderPrimitiveProps & React.RefAttributes<HTMLSpanElement>>;
export declare const SliderPrimitive: typeof SliderPrimitiveInner;
export {};
