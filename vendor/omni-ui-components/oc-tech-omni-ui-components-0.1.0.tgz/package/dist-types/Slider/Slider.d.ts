import { SliderProps } from './Slider.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Slider. Composes {@link SliderPrimitive} with a
 * label / description / error stack via {@link FieldShell}.
 */
declare const SliderInner: React.ForwardRefExoticComponent<SliderProps & React.RefAttributes<HTMLSpanElement>>;
export declare const Slider: typeof SliderInner;
export {};
