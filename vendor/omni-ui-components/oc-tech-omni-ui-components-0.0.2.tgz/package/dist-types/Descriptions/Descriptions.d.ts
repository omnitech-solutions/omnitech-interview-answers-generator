import * as React from 'react';
export interface DescriptionItem {
    key?: React.Key;
    label: React.ReactNode;
    children: React.ReactNode;
}
export interface DescriptionsProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
    title?: React.ReactNode;
    items: DescriptionItem[];
    columns?: number;
}
export declare const Descriptions: ({ title, items, columns, className, ...props }: DescriptionsProps) => React.JSX.Element;
