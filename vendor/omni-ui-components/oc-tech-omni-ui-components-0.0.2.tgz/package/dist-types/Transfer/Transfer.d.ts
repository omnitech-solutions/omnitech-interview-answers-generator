import * as React from 'react';
export interface TransferItem {
    key: string;
    title: React.ReactNode;
}
export interface TransferProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    dataSource: TransferItem[];
    targetKeys?: string[];
    onChange?: (nextTargetKeys: string[]) => void;
}
export declare function Transfer({ dataSource, targetKeys, onChange, className, ...props }: TransferProps): React.JSX.Element;
