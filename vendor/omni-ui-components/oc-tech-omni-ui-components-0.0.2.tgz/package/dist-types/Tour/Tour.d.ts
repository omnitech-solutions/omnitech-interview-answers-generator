import * as React from 'react';
export interface TourStep {
    title?: React.ReactNode;
    description?: React.ReactNode;
}
export interface TourProps {
    open?: boolean;
    current?: number;
    steps: TourStep[];
    onCurrentChange?: (step: number) => void;
    onClose?: () => void;
}
export declare const Tour: ({ open, current, steps, onCurrentChange, onClose }: TourProps) => React.JSX.Element | null;
