import * as React from 'react';
export interface TreeNode {
    key: string;
    title: React.ReactNode;
    children?: TreeNode[];
}
export interface TreeProps extends React.HTMLAttributes<HTMLDivElement> {
    treeData: TreeNode[];
}
export declare const Tree: ({ treeData, className, ...props }: TreeProps) => React.JSX.Element;
