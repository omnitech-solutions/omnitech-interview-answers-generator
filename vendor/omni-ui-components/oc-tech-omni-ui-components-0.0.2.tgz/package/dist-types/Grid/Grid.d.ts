import * as React from 'react';
export interface RowProps extends React.HTMLAttributes<HTMLDivElement> {
    gutter?: number;
}
export interface ColProps extends React.HTMLAttributes<HTMLDivElement> {
    span?: number;
}
export declare const Row: ({ gutter, className, style, ...props }: RowProps) => React.JSX.Element;
export declare const Col: ({ span, className, style, ...props }: ColProps) => React.JSX.Element;
