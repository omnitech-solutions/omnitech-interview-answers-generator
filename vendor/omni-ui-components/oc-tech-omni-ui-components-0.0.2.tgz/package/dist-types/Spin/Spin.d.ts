import * as React from 'react';
export interface SpinProps extends React.HTMLAttributes<HTMLDivElement> {
    spinning?: boolean;
    tip?: React.ReactNode;
}
export declare const Spin: ({ spinning, tip, className, children, ...props }: SpinProps) => React.JSX.Element;
