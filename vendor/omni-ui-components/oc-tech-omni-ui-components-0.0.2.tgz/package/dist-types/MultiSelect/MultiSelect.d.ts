import { SelectOption } from '../Select';
import { FieldLayoutProps } from '../Input/Input.variants';
import { RootProps } from '../lib';
import * as React from 'react';
export interface MultiSelectProps extends RootProps, FieldLayoutProps {
    id?: string;
    name?: string;
    options: SelectOption[];
    value?: string[];
    onChange?: (next: string[]) => void;
    placeholder?: string;
    searchable?: boolean;
    maxItems?: number;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    wrapperClassName?: string;
    labelClassName?: string;
    className?: string;
    'data-testid'?: string;
}
/** Chrome-wrapped Omni MultiSelect. */
export declare const MultiSelect: React.NamedExoticComponent<MultiSelectProps>;
