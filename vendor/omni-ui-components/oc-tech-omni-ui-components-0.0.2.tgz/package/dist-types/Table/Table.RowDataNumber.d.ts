import { RowDataType } from './Table.RowData';
export declare const RowDataNumberType: RowDataType;
