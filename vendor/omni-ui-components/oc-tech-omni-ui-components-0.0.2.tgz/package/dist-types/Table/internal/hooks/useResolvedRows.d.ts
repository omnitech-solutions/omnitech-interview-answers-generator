import { TableDataRow, TableProps, TableResolvedRow } from '../../Table.types';
export interface UseResolvedRowsInput<TRecord, TRowData> {
    dataSource: TRecord[];
    rows: TableDataRow<TRecord, TRowData>[] | undefined;
    row: Partial<TableDataRow<TRecord, TRowData>> | undefined;
    rowKey: TableProps<TRecord, TRowData>['rowKey'];
    childrenColumnName: string;
    appendedRows: TableDataRow<TRecord, TRowData>[];
    rowOrder: string[];
}
export declare function useResolvedRows<TRecord, TRowData>({ dataSource, rows, row, rowKey, childrenColumnName, appendedRows, rowOrder, }: UseResolvedRowsInput<TRecord, TRowData>): {
    effectiveRows: TableDataRow<TRecord, TRowData>[] | undefined;
    baseResolvedRows: TableResolvedRow<TRecord, TRowData>[];
    resolvedRows: TableResolvedRow<TRecord, TRowData>[];
    allResolvedRows: TableResolvedRow<TRecord, TRowData>[];
    rowByKey: Map<string, TableResolvedRow<TRecord, TRowData>>;
};
