import * as React from 'react';
export declare function useDragState(): {
    sensors: import('@dnd-kit/core').SensorDescriptor<import('@dnd-kit/core').SensorOptions>[];
    activeDragId: string | null;
    setActiveDragId: React.Dispatch<React.SetStateAction<string | null>>;
    modifiers: import('@dnd-kit/core').Modifier[];
};
