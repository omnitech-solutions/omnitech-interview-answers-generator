import { TableColumn, TableDataRow, TableProps } from '../../Table.types';
export interface UseAppendControlsInput<TRecord, TRowData> {
    extendable: TableProps<TRecord, TRowData>['extendable'];
    columns: TableColumn<TRecord, TRowData>[];
    rows: TableDataRow<TRecord, TRowData>[] | undefined;
}
export declare function useAppendControls<TRecord, TRowData>({ extendable, columns, rows }: UseAppendControlsInput<TRecord, TRowData>): {
    resolvedExtendable: import('../../Table.append').ResolvedExtendable<TRecord, TRowData>;
    appendedRows: TableDataRow<TRecord, TRowData>[];
    appendedColumns: TableColumn<TRecord, TRowData, unknown>[];
    appendRow: () => Promise<TableDataRow<TRecord, TRowData>>;
    appendColumn: () => Promise<void>;
};
