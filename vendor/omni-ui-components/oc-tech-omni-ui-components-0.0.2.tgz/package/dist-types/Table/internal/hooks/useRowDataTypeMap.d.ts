import { RowDataType } from '../../Table.RowData';
export declare function useRowDataTypeMap(overrides?: RowDataType[]): Record<string, RowDataType>;
