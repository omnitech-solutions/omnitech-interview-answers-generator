import { TableProps } from '../../Table.types';
export declare function useLoadingState<TRecord, TRowData>(loading: TableProps<TRecord, TRowData>['loading']): {
    state: import('../../Table.Loading').ResolvedLoadingState;
    variant: import('../../Table.Loading').TableLoadingVariant;
};
