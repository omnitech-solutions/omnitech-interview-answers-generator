import { TableBulkActionsButtonProps } from '../../Table.types';
import * as React from 'react';
export declare const BulkActionsButton: React.FC<TableBulkActionsButtonProps>;
