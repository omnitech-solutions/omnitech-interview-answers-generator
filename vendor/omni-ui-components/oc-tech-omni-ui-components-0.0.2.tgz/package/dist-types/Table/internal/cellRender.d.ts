import { TableCellOverride, TableCellRenderContext } from '../Table.types';
import { RowDataType } from '../Table.RowData';
import * as React from 'react';
export declare const BUILT_IN_ROW_DATA_TYPES: Record<string, RowDataType>;
export declare const renderCellContent: <TRecord, TRowData>(ctx: TableCellRenderContext<TRecord, TRowData>, value: unknown, override: TableCellOverride<TRecord, TRowData> | undefined, rowDataTypes?: Record<string, RowDataType>) => React.ReactNode;
