import * as React from 'react';
export type SortableHandleBinding = {
    attributes: Record<string, unknown>;
    listeners: React.HTMLAttributes<HTMLButtonElement> | undefined;
    setActivatorNodeRef: (element: HTMLElement | null) => void;
    isDragging: boolean;
    onKeyboardMove: (direction: -1 | 1) => void;
};
type SortableHandleProps = {
    label: string;
    testId: string;
    axis: 'horizontal' | 'vertical';
    setActivatorNodeRef: (element: HTMLElement | null) => void;
    attributes: Record<string, unknown>;
    listeners: React.HTMLAttributes<HTMLButtonElement> | undefined;
    isDragging: boolean;
    onKeyboardMove: (direction: -1 | 1) => void;
};
export declare const SortableHandle: ({ label, testId, axis, setActivatorNodeRef, attributes, listeners, isDragging, onKeyboardMove }: SortableHandleProps) => React.JSX.Element;
export declare const RowDragHandleContext: React.Context<SortableHandleBinding | null>;
type SortableRowHandleCellProps = {
    label: string;
    testId: string;
    rowKey: string;
};
export declare const SortableRowHandleCell: ({ label, testId, rowKey }: SortableRowHandleCellProps) => React.JSX.Element | null;
export {};
