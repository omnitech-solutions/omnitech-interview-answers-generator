import { RowDataType } from './Table.RowData';
/**
 * Named icons that Table columns can render declaratively via
 * `column.type = 'icon'` + `column.icon = '<name>'`. Aliases are folded
 * so both `checkmark` / `check` resolve to the same lucide component.
 */
import * as React from 'react';
export type RowDataIconName = 'check' | 'checkmark' | 'check-circle' | 'chevron' | 'chevron-right' | 'chevron-down' | 'chevron-up' | 'chevron-left' | 'circle' | 'file' | 'folder' | 'folder-open';
export declare const RowDataIcon: React.FC<{
    name: RowDataIconName;
    size?: number;
    className?: string;
}>;
/** Row-data type descriptor for `column.type = 'icon'`. Prefers
 * `column.icon`, falling back to the cell value if it names a known icon. */
export declare const RowDataIconType: RowDataType;
