import { RowDataType } from './Table.RowData';
export declare const RowDataDateType: RowDataType;
