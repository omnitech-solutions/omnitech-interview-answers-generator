import { RowDataType } from './Table.RowData';
export declare const RowDataTextType: RowDataType;
