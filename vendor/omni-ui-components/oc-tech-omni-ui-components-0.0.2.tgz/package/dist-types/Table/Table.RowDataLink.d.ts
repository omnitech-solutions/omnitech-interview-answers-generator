import { RowDataType } from './Table.RowData';
export declare const RowDataLinkType: RowDataType;
