import { RowDataType } from './Table.RowData';
export declare const RowDataActionsType: RowDataType;
