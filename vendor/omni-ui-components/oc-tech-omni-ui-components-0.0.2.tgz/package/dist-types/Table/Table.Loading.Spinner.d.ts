import { TableLoadingVariant } from './Table.Loading';
export declare const TableLoadingSpinnerVariant: TableLoadingVariant;
