import { RowDataType } from './Table.RowData';
export declare const RowDataMoneyType: RowDataType;
