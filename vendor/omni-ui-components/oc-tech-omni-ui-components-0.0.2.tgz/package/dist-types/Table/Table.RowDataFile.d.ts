import { RowDataType } from './Table.RowData';
export declare const RowDataFileType: RowDataType;
