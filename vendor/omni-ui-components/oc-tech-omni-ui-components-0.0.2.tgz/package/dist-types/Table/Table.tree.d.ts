import { TableExpandable } from './Table.types';
/**
 * Tree-table concerns.
 *
 * Owns the two decisions the rest of Table.tsx needs to make when the
 * caller passes nested `children` on their records:
 *
 * - `detectTreeMode` — should the Table render as a tree at all?
 * - `TreeExpandToggle` — the inline chevron + indent that lives inside
 *   the first data cell (instead of a separate expand column).
 *
 * The Table auto-detects tree data via `childrenColumnName` (default
 * `'children'`) and can be opted out by passing `expandedRowRender`
 * (row-expansion mode) or `showExpandColumn: true` (keep a dedicated
 * expand column). Indent width comes from `expandable.indentSize`.
 */
import * as React from 'react';
export declare const detectTreeMode: <TRecord>(dataSource: readonly TRecord[] | undefined, childrenColumnName: string, expandable: TableExpandable<TRecord, unknown> | undefined) => boolean;
interface TreeExpandToggleProps {
    indent: number;
    indentSize?: number;
    canExpand: boolean;
    isExpanded: boolean;
    onToggle: () => void;
    rowKey: string;
    testId?: string;
    /** Optional caller-supplied icon renderer. Receives `{ expanded, onToggle }`
     * and returns any ReactNode (icon, glyph, custom button). When omitted the
     * default lucide chevron button is used. */
    renderIcon?: (ctx: {
        expanded: boolean;
        canExpand: boolean;
        onToggle: (event: React.MouseEvent) => void;
    }) => React.ReactNode;
}
export declare const TreeExpandToggle: React.FC<TreeExpandToggleProps>;
export {};
