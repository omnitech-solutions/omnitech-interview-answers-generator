import { TableDataRow, TableProps, TableSelectionAction } from '../Table.types';
import * as React from 'react';
export interface BulkActionsBarProps<TRecord, TRowData> {
    bulkActions: NonNullable<NonNullable<TableProps<TRecord, TRowData>['rowSelection']>['bulkActions']>;
    selectedKeys: string[];
    selectedRows: TRecord[];
    selectedDataRows: TableDataRow<TRecord, TRowData>[];
    actions: TableSelectionAction[];
    onRunAction: (action: TableSelectionAction) => void;
    onClear: () => void;
}
export declare function BulkActionsBar<TRecord, TRowData>({ bulkActions, selectedKeys, selectedRows, selectedDataRows, actions, onRunAction, onClear, }: BulkActionsBarProps<TRecord, TRowData>): React.JSX.Element | null;
