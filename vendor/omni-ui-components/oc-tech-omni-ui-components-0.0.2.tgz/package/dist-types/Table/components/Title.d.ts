import { TableDataRow, TableProps } from '../Table.types';
import * as React from 'react';
export interface TitleProps<TRecord, TRowData> {
    render: NonNullable<TableProps<TRecord, TRowData>['title']>;
    data: TRecord[];
    rows: TableDataRow<TRecord, TRowData>[];
    className?: string;
    style?: React.CSSProperties;
}
export declare function Title<TRecord, TRowData>({ render, data, rows, className, style }: TitleProps<TRecord, TRowData>): React.JSX.Element;
