import { TableProps } from '../Table.types';
import * as React from 'react';
export interface ExpandHeaderProps<TRecord, TRowData> {
    expandable: NonNullable<TableProps<TRecord, TRowData>['expandable']>;
    className?: string;
}
export declare function ExpandHeader<TRecord, TRowData>({ expandable, className }: ExpandHeaderProps<TRecord, TRowData>): React.JSX.Element;
