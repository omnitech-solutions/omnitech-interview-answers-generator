import { TablePaginationPlacement, TablePaginationState } from '../Table.types';
import * as React from 'react';
export interface PaginationProps {
    placement: TablePaginationPlacement;
    state: TablePaginationState;
    pageCount: number;
    disabled: boolean;
    showPrevNext: boolean;
    showSizeChanger?: boolean;
    pageSizeOptions?: number[];
    onGoToPage: (page: number) => void;
    onPageSizeChange: (size: number) => void;
    className?: string;
    style?: React.CSSProperties;
    testIdSuffix?: string;
}
export declare function Pagination({ placement, state, pageCount, disabled, showPrevNext, showSizeChanger, pageSizeOptions, onGoToPage, onPageSizeChange, className, style, testIdSuffix, }: PaginationProps): React.JSX.Element;
