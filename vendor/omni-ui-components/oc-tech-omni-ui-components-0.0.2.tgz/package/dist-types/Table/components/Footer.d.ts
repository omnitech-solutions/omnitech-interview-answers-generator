import { TableDataRow, TableProps } from '../Table.types';
import * as React from 'react';
export interface FooterProps<TRecord, TRowData> {
    render: NonNullable<TableProps<TRecord, TRowData>['footer']>;
    data: TRecord[];
    rows: TableDataRow<TRecord, TRowData>[];
    className?: string;
    style?: React.CSSProperties;
}
export declare function Footer<TRecord, TRowData>({ render, data, rows, className, style }: FooterProps<TRecord, TRowData>): React.JSX.Element;
