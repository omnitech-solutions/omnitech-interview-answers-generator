import { TableLoadingVariant } from '../Table.Loading';
import { TableDataRow, TableLoadingProps, TableProps } from '../Table.types';
import * as React from 'react';
export interface TableRootProps<TRecord, TRowData> {
    rootRef: React.RefObject<HTMLDivElement | null>;
    scrollRef: React.RefObject<HTMLDivElement | null>;
    className: string | undefined;
    style: React.CSSProperties | undefined;
    rootStyle: React.CSSProperties;
    appearance: NonNullable<TableProps<TRecord, TRowData>['appearance']>;
    borders: TableProps<TRecord, TRowData>['appearance'] extends infer A ? (A extends {
        borders?: infer B;
    } ? B : never) : never;
    showHeader: boolean;
    size: TableProps<TRecord, TRowData>['size'];
    rowHoverable: boolean;
    scroll: TableProps<TRecord, TRowData>['scroll'];
    sticky: TableProps<TRecord, TRowData>['sticky'];
    stickyContainer: HTMLElement | undefined;
    enableVirtualRows: boolean;
    virtual: TableProps<TRecord, TRowData>['virtual'];
    onScroll: React.UIEventHandler<HTMLDivElement> | undefined;
    title: TableProps<TRecord, TRowData>['title'];
    footer: TableProps<TRecord, TRowData>['footer'];
    currentData: TRecord[];
    currentRows: TableDataRow<TRecord, TRowData>[];
    resolvedExtendable: {
        controls?: boolean;
        rows?: unknown | null;
        columns?: unknown | null;
    };
    handleAppendRow: () => Promise<TableDataRow<TRecord, TRowData>>;
    handleAppendColumn: () => Promise<void>;
    loadingState: {
        active: boolean;
        props?: TableLoadingProps;
    };
    loadingVariant: TableLoadingVariant;
    renderRows: unknown[];
    hasDraggableRows: boolean;
    rowSelection: TableProps<TRecord, TRowData>['rowSelection'];
    expandable: TableProps<TRecord, TRowData>['expandable'];
    treeMode: boolean;
    tableContent: React.ReactNode;
    bulkActionsBar: React.ReactNode;
    topPagination: React.ReactNode;
    bottomPagination: React.ReactNode;
}
export declare function TableRoot<TRecord, TRowData>({ rootRef, scrollRef, className, style: _style, rootStyle, appearance, borders, showHeader, size, rowHoverable, scroll, sticky, stickyContainer, enableVirtualRows, virtual, onScroll, resolvedExtendable, handleAppendRow, handleAppendColumn, loadingState, loadingVariant, renderRows, hasDraggableRows, rowSelection, expandable, treeMode, tableContent, bulkActionsBar, topPagination, bottomPagination, title, footer, currentData, currentRows, }: TableRootProps<TRecord, TRowData>): React.JSX.Element;
