import { TableColumn, TableProps, TableResolvedRow } from '../Table.types';
import * as React from 'react';
export interface SelectionCellProps<TRecord, TRowData> {
    resolved: TableResolvedRow<TRecord, TRowData>;
    rowIndex: number;
    column: TableColumn<TRecord, TRowData> | undefined;
    checked: boolean;
    rowSelection: NonNullable<TableProps<TRecord, TRowData>['rowSelection']>;
    checkboxProps: React.InputHTMLAttributes<HTMLInputElement>;
    onSelect: (resolved: TableResolvedRow<TRecord, TRowData>, next: boolean, event: Event) => void;
    fixedSide: 'left' | 'right' | undefined;
    alignStyle: React.CSSProperties;
    className?: string;
}
export declare function SelectionCell<TRecord, TRowData>({ resolved, rowIndex, column, checked, rowSelection, checkboxProps, onSelect, fixedSide, alignStyle, className, }: SelectionCellProps<TRecord, TRowData>): React.JSX.Element;
