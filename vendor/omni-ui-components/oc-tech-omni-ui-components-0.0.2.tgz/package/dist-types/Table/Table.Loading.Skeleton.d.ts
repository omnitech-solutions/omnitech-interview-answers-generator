import { TableLoadingVariant } from './Table.Loading';
export declare const TableLoadingSkeletonVariant: TableLoadingVariant;
