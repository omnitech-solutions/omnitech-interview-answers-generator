/**
 * Absolutely-positioned dropdown container that flips its horizontal /
 * vertical anchor when it would overflow the viewport. Used by the built-in
 * column filter popover so the menu stays inside the table view.
 *
 * The anchor decision is based on the dropdown's own bounding rect after
 * mount. Attributes exposed for styling / testing:
 *   - `data-align-x="left"` (default) | `"right"`
 *   - `data-align-y="bottom"` (default) | `"top"`
 */
import * as React from 'react';
interface AutoFlipDropdownProps extends React.HTMLAttributes<HTMLSpanElement> {
    children: React.ReactNode;
    className?: string;
}
/**
 * Portals the dropdown into `<body>` and positions it with `position: fixed`
 * anchored to its logical trigger (the parent element in the original DOM
 * tree). This guarantees the dropdown is fully decoupled from the row layout
 * — siblings like a Show code panel can never move when the dropdown opens.
 *
 * Auto-flips horizontally/vertically to stay inside the viewport and, when
 * present, inside the nearest `.pb-overview-row-preview` /
 * `[data-dropdown-boundary]` ancestor of the trigger.
 */
export declare const AutoFlipDropdown: React.FC<AutoFlipDropdownProps>;
export {};
