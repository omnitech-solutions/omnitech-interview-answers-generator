import { TableCellOverride, TableColumn, TableDataRow } from './Table.types';
export interface TableMatrixColumnFactoryContext {
    index: number;
    key: string;
}
export interface TableMatrixCellFactoryContext {
    rowIndex: number;
    columnIndex: number;
    rowKey: string;
    columnKey: string;
}
export interface CreateTableMatrixOptions<TRecord, TRowData> {
    createColumn: (ctx: TableMatrixColumnFactoryContext) => TableColumn<TRecord, TRowData>;
    createCell: (ctx: TableMatrixCellFactoryContext) => TableCellOverride<TRecord, TRowData>;
}
export declare const normalizeTableMatrixCount: (value: number | undefined, fallback: number, min?: number) => number;
export declare const nextTableMatrixColumnKey: <TRecord, TRowData>(columns: TableColumn<TRecord, TRowData>[]) => string;
export declare const nextTableMatrixRowKey: <TRecord, TRowData>(rows: TableDataRow<TRecord, TRowData>[]) => string;
export declare const createTableMatrixColumns: <TRecord, TRowData>(count: number, options: Pick<CreateTableMatrixOptions<TRecord, TRowData>, "createColumn">) => TableColumn<TRecord, TRowData>[];
export declare const syncTableMatrixRowToColumns: <TRecord, TRowData>(row: TableDataRow<TRecord, TRowData>, columns: TableColumn<TRecord, TRowData>[], createCell: CreateTableMatrixOptions<TRecord, TRowData>["createCell"], rowIndex: number) => TableDataRow<TRecord, TRowData>;
export declare const createTableMatrixRows: <TRecord, TRowData>(rowCount: number, columns: TableColumn<TRecord, TRowData>[], options: Pick<CreateTableMatrixOptions<TRecord, TRowData>, "createCell">) => TableDataRow<TRecord, TRowData>[];
export declare const resizeTableMatrixColumns: <TRecord, TRowData>(columns: TableColumn<TRecord, TRowData>[], rows: TableDataRow<TRecord, TRowData>[], count: number, options: CreateTableMatrixOptions<TRecord, TRowData>) => {
    columns: TableColumn<TRecord, TRowData>[];
    rows: TableDataRow<TRecord, TRowData>[];
};
export declare const resizeTableMatrixRows: <TRecord, TRowData>(rows: TableDataRow<TRecord, TRowData>[], columns: TableColumn<TRecord, TRowData>[], count: number, options: Pick<CreateTableMatrixOptions<TRecord, TRowData>, "createCell">) => TableDataRow<TRecord, TRowData>[];
