import { Row } from '@tanstack/react-table';
import { TableColumn, TableProps, TableResolvedRow } from '../Table.types';
import * as React from 'react';
export interface UseVirtualizationInput<TRecord, TRowData> {
    virtual: TableProps<TRecord, TRowData>['virtual'];
    visibleRows: Row<TableResolvedRow<TRecord, TRowData>>[];
    scrollRef: React.RefObject<HTMLDivElement | null>;
    mergedLeafColumns: TableColumn<TRecord, TRowData>[];
    columnPinning: import('@tanstack/react-table').ColumnPinningState;
}
export declare function useVirtualization<TRecord, TRowData>({ virtual, visibleRows, scrollRef, mergedLeafColumns, columnPinning, }: UseVirtualizationInput<TRecord, TRowData>): {
    enableVirtualRows: boolean | undefined;
    rowVirtualizer: import('@tanstack/react-virtual').ReactVirtualizer<HTMLDivElement, Element>;
    virtualItems: import('@tanstack/react-virtual').VirtualItem[];
    renderRows: Row<TableResolvedRow<TRecord, TRowData>>[];
    renderedLeafColumns: TableColumn<TRecord, TRowData, unknown>[];
};
