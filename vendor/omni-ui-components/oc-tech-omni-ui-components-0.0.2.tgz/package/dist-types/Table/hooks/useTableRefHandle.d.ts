import { Row } from '@tanstack/react-table';
import { Virtualizer } from '@tanstack/react-virtual';
import { TableRef, TableResolvedRow } from '../Table.types';
import * as React from 'react';
export interface UseTableRefHandleInput<TRecord, TRowData> {
    ref: React.Ref<TableRef>;
    rootRef: React.RefObject<HTMLDivElement | null>;
    scrollRef: React.RefObject<HTMLDivElement | null>;
    visibleRows: Row<TableResolvedRow<TRecord, TRowData>>[];
    enableVirtualRows: boolean;
    rowVirtualizer: Virtualizer<HTMLDivElement, Element>;
}
export declare function useTableRefHandle<TRecord, TRowData>({ ref, rootRef, scrollRef, visibleRows, enableVirtualRows, rowVirtualizer, }: UseTableRefHandleInput<TRecord, TRowData>): void;
