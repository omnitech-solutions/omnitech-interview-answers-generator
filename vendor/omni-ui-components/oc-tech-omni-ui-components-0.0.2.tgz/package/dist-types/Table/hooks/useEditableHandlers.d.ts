import { Row } from '@tanstack/react-table';
import { ResolvedCellEditable } from '../internal';
import { TableCellOverride, TableCellRenderContext, TableColumn, TableEditableConfig, TableEditableRowConfig, TableProps, TableRegistry, TableResolvedRow } from '../Table.types';
import * as React from 'react';
export type EditableTarget<TRecord, TRowData> = {
    resolved: TableResolvedRow<TRecord, TRowData>;
    column: TableColumn<TRecord, TRowData>;
    rowConfig: TableEditableRowConfig<TRecord, TRowData> | null;
    editableConfig: ResolvedCellEditable<TRecord, TRowData>;
    value: unknown;
};
export interface UseEditableHandlersInput<TRecord, TRowData> {
    registry: TableRegistry<TRecord, TRowData>;
    renderedLeafColumns: TableColumn<TRecord, TRowData>[];
    renderRows: Row<TableResolvedRow<TRecord, TRowData>>[];
    rootEditableConfig: TableEditableConfig<TRecord, TRowData> | null;
    editValues: Record<string, Record<string, unknown>>;
    setEditValues: React.Dispatch<React.SetStateAction<Record<string, Record<string, unknown>>>>;
    setEditErrors: React.Dispatch<React.SetStateAction<Record<string, string | null>>>;
    setEditingCell: React.Dispatch<React.SetStateAction<{
        rowKey: string;
        columnKey: string;
    } | null>>;
    setEditingRowKey: React.Dispatch<React.SetStateAction<string | null>>;
    setInternalCellValues: React.Dispatch<React.SetStateAction<Record<string, Record<string, unknown>>>>;
    onEdit: TableProps<TRecord, TRowData>['onEdit'];
}
export declare function useEditableHandlers<TRecord, TRowData>({ registry, renderedLeafColumns, renderRows, rootEditableConfig, editValues, setEditValues, setEditErrors, setEditingCell, setEditingRowKey, setInternalCellValues, onEdit, }: UseEditableHandlersInput<TRecord, TRowData>): {
    editableErrorKey: (rowKey: string, columnKey: string) => string;
    rowInitialEditableValues: (resolved: TableResolvedRow<TRecord, TRowData>, rowConfig: TableEditableRowConfig<TRecord, TRowData> | null) => Record<string, unknown>;
    ensureRowEditValues: (rowKey: string, resolved: TableResolvedRow<TRecord, TRowData>, rowConfig: TableEditableRowConfig<TRecord, TRowData> | null) => void;
    setEditableValue: (rowKey: string, columnKey: string, value: unknown) => void;
    beginCellEdit: (resolved: TableResolvedRow<TRecord, TRowData>, col: TableColumn<TRecord, TRowData>, value: unknown, rowConfig: TableEditableRowConfig<TRecord, TRowData> | null, editableConfig: ResolvedCellEditable<TRecord, TRowData> | null) => void;
    validateEditableCell: (editableConfig: ResolvedCellEditable<TRecord, TRowData>, value: unknown, ctx: TableCellRenderContext<TRecord, TRowData>) => string | null;
    bodyCellEditableConfig: (override: TableCellOverride<TRecord, TRowData> | undefined, col: TableColumn<TRecord, TRowData>) => ResolvedCellEditable<TRecord, TRowData> | null;
    saveCellEdit: (rowKey: string, col: TableColumn<TRecord, TRowData>, editableConfig: ResolvedCellEditable<TRecord, TRowData>, ctx: TableCellRenderContext<TRecord, TRowData>, nextValue?: unknown) => Promise<boolean>;
    editableCellTarget: (currentRowKey: string, currentColumnKey: string, direction: -1 | 1) => EditableTarget<TRecord, TRowData> | null;
    firstEditableCellTarget: (resolved: TableResolvedRow<TRecord, TRowData>) => EditableTarget<TRecord, TRowData> | null;
    saveRowEdit: (resolved: TableResolvedRow<TRecord, TRowData>, rowConfig: TableEditableRowConfig<TRecord, TRowData>) => Promise<void>;
    cancelCellEdit: (rowKey: string, columnKey: string) => void;
    cancelRowEdit: (resolved: TableResolvedRow<TRecord, TRowData>, rowConfig: TableEditableRowConfig<TRecord, TRowData>) => void;
};
