import { ExpandedState } from '@tanstack/react-table';
import { TableProps } from '../../Table.types';
import * as React from 'react';
export declare function useExpandedState<TRecord, TRowData>(propsState: TableProps<TRecord, TRowData>['state'], defaultStateExpanded: ExpandedState | undefined, expandable: TableProps<TRecord, TRowData>['expandable']): {
    expanded: ExpandedState;
    setExpanded: React.Dispatch<React.SetStateAction<ExpandedState>>;
};
