import * as React from 'react';
export declare function useEditingState(): {
    editingCell: {
        rowKey: string;
        columnKey: string;
    } | null;
    setEditingCell: React.Dispatch<React.SetStateAction<{
        rowKey: string;
        columnKey: string;
    } | null>>;
    editingRowKey: string | null;
    setEditingRowKey: React.Dispatch<React.SetStateAction<string | null>>;
    editValues: Record<string, Record<string, unknown>>;
    setEditValues: React.Dispatch<React.SetStateAction<Record<string, Record<string, unknown>>>>;
    editErrors: Record<string, string | null>;
    setEditErrors: React.Dispatch<React.SetStateAction<Record<string, string | null>>>;
    internalCellValues: Record<string, Record<string, unknown>>;
    setInternalCellValues: React.Dispatch<React.SetStateAction<Record<string, Record<string, unknown>>>>;
};
