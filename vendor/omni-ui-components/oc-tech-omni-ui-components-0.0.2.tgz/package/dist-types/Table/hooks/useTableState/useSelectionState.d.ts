import { RowSelectionState } from '@tanstack/react-table';
import { TableKey, TableProps } from '../../Table.types';
import * as React from 'react';
export declare function useSelectionState<TRecord, TRowData>(rowSelection: TableProps<TRecord, TRowData>['rowSelection']): {
    tanStackRowSelection: RowSelectionState;
    setTanStackRowSelection: React.Dispatch<React.SetStateAction<RowSelectionState>>;
    selectionKeysToState: (keys?: TableKey[] | Iterable<TableKey>) => RowSelectionState;
    preserveSelectedRecordsRef: React.MutableRefObject<Map<string, TRecord>>;
    lastSelectedKeyRef: React.MutableRefObject<string | null>;
};
