import { SortingState } from '@tanstack/react-table';
import { TableColumn, TableProps } from '../../Table.types';
import * as React from 'react';
export declare function useSortingState<TRecord, TRowData>(columns: TableColumn<TRecord, TRowData>[], propsState: TableProps<TRecord, TRowData>['state'], defaultStateSorting: SortingState | undefined): {
    sorting: SortingState;
    setSorting: React.Dispatch<React.SetStateAction<SortingState>>;
};
