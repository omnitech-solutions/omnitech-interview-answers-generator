import * as React from 'react';
export declare function useRowOrderState(): {
    rowOrder: string[];
    setRowOrder: React.Dispatch<React.SetStateAction<string[]>>;
};
