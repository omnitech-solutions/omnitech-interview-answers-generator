import { PaginationState } from '@tanstack/react-table';
import { TableProps } from '../../Table.types';
import * as React from 'react';
export declare function usePaginationState<TRecord, TRowData>(rawProps: TableProps<TRecord, TRowData>): {
    paginationStateValue: PaginationState;
    setPaginationStateValue: React.Dispatch<React.SetStateAction<PaginationState>>;
};
