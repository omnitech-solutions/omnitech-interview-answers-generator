import { ColumnOrderState, ColumnPinningState, ColumnSizingState, VisibilityState } from '@tanstack/react-table';
import { TableProps } from '../../Table.types';
import * as React from 'react';
export declare function useColumnLayoutState<TRecord, TRowData>(propsState: TableProps<TRecord, TRowData>['state'], defaultState: TableProps<TRecord, TRowData>['defaultState']): {
    columnVisibility: VisibilityState;
    setColumnVisibility: React.Dispatch<React.SetStateAction<VisibilityState>>;
    columnOrder: ColumnOrderState;
    setColumnOrder: React.Dispatch<React.SetStateAction<ColumnOrderState>>;
    columnSizing: ColumnSizingState;
    setColumnSizing: React.Dispatch<React.SetStateAction<ColumnSizingState>>;
    columnPinning: ColumnPinningState;
    setColumnPinning: React.Dispatch<React.SetStateAction<ColumnPinningState>>;
};
