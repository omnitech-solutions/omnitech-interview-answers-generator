import { ColumnFiltersState } from '@tanstack/react-table';
import { TableColumn, TableFilterItem } from '../../Table.types';
import * as React from 'react';
export declare function useFilterState<TRecord, TRowData>(columns: TableColumn<TRecord, TRowData>[], initial: ColumnFiltersState | undefined): {
    columnFilters: ColumnFiltersState;
    setColumnFilters: React.Dispatch<React.SetStateAction<ColumnFiltersState>>;
    initialFilterItemsRef: React.MutableRefObject<Record<string, TableFilterItem[]>>;
};
