import { ColumnOrderState, VisibilityState } from '@tanstack/react-table';
import { TableColumn, TableProps } from '../Table.types';
export interface UseDerivedColumnsInput<TRecord, TRowData> {
    columns: TableColumn<TRecord, TRowData>[];
    column: Partial<TableColumn<TRecord, TRowData>> | undefined;
    appendedColumns: TableColumn<TRecord, TRowData>[];
    dataSource: TRecord[];
    expandable: TableProps<TRecord, TRowData>['expandable'];
    columnVisibility: VisibilityState;
    columnOrder: ColumnOrderState;
}
export declare function useDerivedColumns<TRecord, TRowData>({ columns, column, appendedColumns, dataSource, expandable, columnVisibility, columnOrder, }: UseDerivedColumnsInput<TRecord, TRowData>): {
    responsiveScreens: Record<string, boolean>;
    childrenColumnName: string;
    treeMode: boolean;
    mergedColumns: TableColumn<TRecord, TRowData, unknown>[];
    mergedLeafColumns: TableColumn<TRecord, TRowData, unknown>[];
};
