import { RowSelectionState } from '@tanstack/react-table';
import { TableKey, TableProps, TableResolvedRow, TableSelectionAction } from '../Table.types';
import * as React from 'react';
export interface UseSelectionHandlersInput<TRecord, TRowData> {
    rowSelection: TableProps<TRecord, TRowData>['rowSelection'];
    locale: TableProps<TRecord, TRowData>['locale'];
    allResolvedRows: TableResolvedRow<TRecord, TRowData>[];
    resolvedRows: TableResolvedRow<TRecord, TRowData>[];
    rowByKey: Map<string, TableResolvedRow<TRecord, TRowData>>;
    tanStackRowSelection: RowSelectionState;
    setTanStackRowSelection: React.Dispatch<React.SetStateAction<RowSelectionState>>;
    selectionKeysToState: (keys: TableKey[] | Iterable<TableKey>) => RowSelectionState;
    preserveSelectedRecordsRef: React.MutableRefObject<Map<string, TRecord>>;
    lastSelectedKeyRef: React.MutableRefObject<string | null>;
    emitStateChange: (partial: Partial<NonNullable<TableProps<TRecord, TRowData>['state']>>) => void;
}
export declare function useSelectionHandlers<TRecord, TRowData>({ rowSelection, locale, allResolvedRows, resolvedRows, rowByKey, tanStackRowSelection, setTanStackRowSelection, selectionKeysToState, preserveSelectedRecordsRef, lastSelectedKeyRef, emitStateChange, }: UseSelectionHandlersInput<TRecord, TRowData>): {
    selectedKeys: string[];
    selectedKeySet: Set<string>;
    selectionControlled: boolean;
    selectionFixedSide: "left" | "right" | undefined;
    selectionAlignStyle: React.CSSProperties;
    selectionStateForKeys: (keys?: TableKey[]) => RowSelectionState;
    selectedRecordsForKeys: (keys: string[]) => TRecord[];
    selectionCheckboxPropsFor: (resolved: TableResolvedRow<TRecord, TRowData>) => React.InputHTMLAttributes<HTMLInputElement>;
    isSelectionDisabled: (resolved: TableResolvedRow<TRecord, TRowData>) => boolean;
    changeableSelectionKeys: string[];
    applySelectionKeys: (keys: string[], type: "single" | "multiple" | "all" | "invert" | "none") => string[];
    handleSelect: (resolved: TableResolvedRow<TRecord, TRowData>, checked: boolean, nativeEvent: Event) => void;
    resolvedSelectionActions: TableSelectionAction[];
    bulkActionsConfigured: boolean;
    clearSelection: () => void;
    runBulkAction: (action: TableSelectionAction) => void;
};
