import { ColumnFiltersState, ColumnOrderState, ColumnPinningState, ColumnSizingState, ExpandedState, PaginationState, RowSelectionState, SortingState, VisibilityState } from '@tanstack/react-table';
import { TableColumn, TableProps, TableResolvedRow, TableSorterResult } from '../Table.types';
import * as React from 'react';
export interface UseTableInstanceInput<TRecord, TRowData> {
    rawProps: TableProps<TRecord, TRowData>;
    columns: TableColumn<TRecord, TRowData>[];
    mergedLeafColumns: TableColumn<TRecord, TRowData>[];
    resolvedRows: TableResolvedRow<TRecord, TRowData>[];
    dataSource: TRecord[];
    sorting: SortingState;
    columnFilters: ColumnFiltersState;
    expanded: ExpandedState;
    paginationStateValue: PaginationState;
    tanStackRowSelection: RowSelectionState;
    columnVisibility: VisibilityState;
    columnOrder: ColumnOrderState;
    columnSizing: ColumnSizingState;
    columnPinning: ColumnPinningState;
    setSorting: React.Dispatch<React.SetStateAction<SortingState>>;
    setColumnFilters: React.Dispatch<React.SetStateAction<ColumnFiltersState>>;
    setExpanded: React.Dispatch<React.SetStateAction<ExpandedState>>;
    setPaginationStateValue: React.Dispatch<React.SetStateAction<PaginationState>>;
    setTanStackRowSelection: React.Dispatch<React.SetStateAction<RowSelectionState>>;
    setColumnVisibility: React.Dispatch<React.SetStateAction<VisibilityState>>;
    setColumnOrder: React.Dispatch<React.SetStateAction<ColumnOrderState>>;
    setColumnSizing: React.Dispatch<React.SetStateAction<ColumnSizingState>>;
    setColumnPinning: React.Dispatch<React.SetStateAction<ColumnPinningState>>;
    emitStateChange: (partial: Partial<NonNullable<TableProps<TRecord, TRowData>['state']>>) => void;
    paginationState: () => import('../Table.types').TablePaginationState;
    scrollToFirstRow: () => void;
}
export declare function useTableInstance<TRecord, TRowData>(input: UseTableInstanceInput<TRecord, TRowData>): {
    table: import('@tanstack/react-table').Table<TableResolvedRow<TRecord, TRowData>>;
    applySortingChange: (next: SortingState, changedColumn?: TableColumn<TRecord, TRowData>, changedOrder?: TableSorterResult<TRecord>["order"]) => void;
    sortingControlled: boolean;
};
