import { PaginationState, Table as TanStackTable, ColumnFiltersState } from '@tanstack/react-table';
import { TablePaginationState, TableProps, TableResolvedRow, TableSemanticDOM } from '../Table.types';
import * as React from 'react';
export interface UsePaginationHandlersInput<TRecord, TRowData> {
    pagination: TableProps<TRecord, TRowData>['pagination'];
    paginationStateValue: PaginationState;
    setPaginationStateValue: React.Dispatch<React.SetStateAction<PaginationState>>;
    table: TanStackTable<TableResolvedRow<TRecord, TRowData>>;
    paginationState: () => TablePaginationState;
    scrollToFirstRow: () => void;
    onChange: TableProps<TRecord, TRowData>['onChange'];
    columnFilters: ColumnFiltersState;
    dataSource: TRecord[];
    resolvedRows: TableResolvedRow<TRecord, TRowData>[];
    allResolvedRows: TableResolvedRow<TRecord, TRowData>[];
    emitStateChange: (partial: Partial<NonNullable<TableProps<TRecord, TRowData>['state']>>) => void;
    classMap: Partial<Record<TableSemanticDOM, string>>;
    styleMap: Partial<Record<TableSemanticDOM, React.CSSProperties>>;
}
export declare function usePaginationHandlers<TRecord, TRowData>({ pagination, paginationStateValue: _paginationStateValue, setPaginationStateValue, table, paginationState, scrollToFirstRow, onChange, columnFilters, dataSource, resolvedRows, allResolvedRows, emitStateChange, classMap, styleMap, }: UsePaginationHandlersInput<TRecord, TRowData>): {
    paginationEffectivelyOff: boolean;
    topPagination: React.JSX.Element[];
    bottomPagination: React.JSX.Element[];
};
