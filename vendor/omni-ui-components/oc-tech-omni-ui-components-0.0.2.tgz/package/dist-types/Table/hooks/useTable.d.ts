import { Table as TanStackTable, ColumnPinningState, ColumnSizingState, ExpandedState, SortingState } from '@tanstack/react-table';
import { RowDataType } from '../Table.RowData';
import { TableColumn, TableEditableConfig, TableProps, TableRegistry, TableResolvedRow, TableSemanticDOM, TableSorterResult } from '../Table.types';
import * as React from 'react';
export interface TableContextShape<TRecord = unknown, TRowData = unknown> {
    table: TanStackTable<TableResolvedRow<TRecord, TRowData>>;
    props: TableProps<TRecord, TRowData>;
    registry: TableRegistry<TRecord, TRowData>;
    testIdPrefix: string;
    mergedColumns: TableColumn<TRecord, TRowData>[];
    mergedLeafColumns: TableColumn<TRecord, TRowData>[];
    renderedLeafColumns: TableColumn<TRecord, TRowData>[];
    resolvedRows: TableResolvedRow<TRecord, TRowData>[];
    rowByKey: Map<string, TableResolvedRow<TRecord, TRowData>>;
    rowDataTypeMap: Record<string, RowDataType>;
    classMap: Partial<Record<TableSemanticDOM, string>>;
    styleMap: Partial<Record<TableSemanticDOM, React.CSSProperties>>;
    rootEditableConfig: TableEditableConfig<TRecord, TRowData> | null;
    expanded: ExpandedState;
    editingCell: {
        rowKey: string;
        columnKey: string;
    } | null;
    editingRowKey: string | null;
    editValues: Record<string, Record<string, unknown>>;
    editErrors: Record<string, string | null>;
    internalCellValues: Record<string, Record<string, unknown>>;
    sorting: SortingState;
    columnSizing: ColumnSizingState;
    columnPinning: ColumnPinningState;
    tableSortDirections: readonly TableSorterResult<unknown>['order'][];
    applySortingChange: (next: SortingState, changedColumn?: TableColumn<TRecord, TRowData>, changedOrder?: TableSorterResult<TRecord>['order']) => void;
    moveColumnByKeyboard: (columnKey: string, direction: -1 | 1) => void;
    moveRowByKeyboard: (rowKey: string, direction: -1 | 1) => void;
}
export declare const TableProvider: React.Provider<TableContextShape<unknown, unknown> | null>;
export declare function useTable<TRecord = unknown, TRowData = unknown>(): TableContextShape<TRecord, TRowData>;
