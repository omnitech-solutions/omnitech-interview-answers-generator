import { ExpandedState, Table as TanStackTable } from '@tanstack/react-table';
import { TableColumn, TableKey, TablePaginationState, TableProps, TableResolvedRow } from '../Table.types';
import * as React from 'react';
export interface UseTableHandlersInput<TRecord, TRowData> {
    columnFilters: {
        id: string;
        value: unknown;
    }[];
    setColumnFilters: React.Dispatch<React.SetStateAction<{
        id: string;
        value: unknown;
    }[]>>;
    paginationStateValue: {
        pageIndex: number;
        pageSize: number;
    };
    setPaginationStateValue: React.Dispatch<React.SetStateAction<{
        pageIndex: number;
        pageSize: number;
    }>>;
    expanded: ExpandedState;
    setExpanded: (next: ExpandedState) => void;
    sorting: unknown;
    tanStackRowSelection: unknown;
    emitStateChange: (partial: Partial<NonNullable<TableProps<TRecord, TRowData>['state']>>) => void;
    onStateChange: TableProps<TRecord, TRowData>['onStateChange'];
    onChange: TableProps<TRecord, TRowData>['onChange'];
    allResolvedRows: TableResolvedRow<TRecord, TRowData>[];
    resolvedRows: TableResolvedRow<TRecord, TRowData>[];
    mergedLeafColumns: TableColumn<TRecord, TRowData>[];
    table: TanStackTable<TableResolvedRow<TRecord, TRowData>>;
    pagination: TableProps<TRecord, TRowData>['pagination'];
    expandable: TableProps<TRecord, TRowData>['expandable'];
    scroll: TableProps<TRecord, TRowData>['scroll'];
    scrollRef: React.RefObject<HTMLDivElement | null>;
}
export declare function useTableHandlers<TRecord, TRowData>({ columnFilters, setColumnFilters, paginationStateValue, setPaginationStateValue, expanded, setExpanded, sorting, tanStackRowSelection, emitStateChange, onStateChange, onChange, allResolvedRows, resolvedRows, mergedLeafColumns, table, pagination, expandable, scroll, scrollRef, }: UseTableHandlersInput<TRecord, TRowData>): {
    paginationState: () => TablePaginationState;
    scrollToFirstRow: () => void;
    committedFilterKeys: (col: TableColumn<TRecord, TRowData>) => TableKey[];
    commitFilter: (col: TableColumn<TRecord, TRowData>, values: TableKey[]) => void;
    toggleExpanded: (resolved: TableResolvedRow<TRecord, TRowData>) => void;
};
