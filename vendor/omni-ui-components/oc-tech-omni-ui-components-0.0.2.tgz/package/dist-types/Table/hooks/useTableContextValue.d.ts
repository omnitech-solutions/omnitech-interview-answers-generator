import { TableContextShape } from './useTable';
export declare function useTableContextValue<TRecord, TRowData>(input: TableContextShape<TRecord, TRowData>): TableContextShape<TRecord, TRowData>;
