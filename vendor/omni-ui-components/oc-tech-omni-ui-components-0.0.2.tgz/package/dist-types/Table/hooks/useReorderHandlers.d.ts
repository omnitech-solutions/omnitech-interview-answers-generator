import { DragEndEvent } from '@dnd-kit/core';
import { ColumnOrderState } from '@tanstack/react-table';
import { TableColumn, TableProps, TableResolvedRow } from '../Table.types';
import * as React from 'react';
export interface UseReorderHandlersInput<TRecord, TRowData> {
    resolvedRows: TableResolvedRow<TRecord, TRowData>[];
    mergedLeafColumns: TableColumn<TRecord, TRowData>[];
    setRowOrder: React.Dispatch<React.SetStateAction<string[]>>;
    setColumnOrder: React.Dispatch<React.SetStateAction<ColumnOrderState>>;
    emitStateChange: (partial: Partial<NonNullable<TableProps<TRecord, TRowData>['state']>>) => void;
    onRowOrderChange: TableProps<TRecord, TRowData>['onRowOrderChange'];
    onColumnOrderChange: TableProps<TRecord, TRowData>['onColumnOrderChange'];
}
export declare function useReorderHandlers<TRecord, TRowData>({ resolvedRows, mergedLeafColumns, setRowOrder, setColumnOrder, emitStateChange, onRowOrderChange, onColumnOrderChange, }: UseReorderHandlersInput<TRecord, TRowData>): {
    draggableRows: TableResolvedRow<TRecord, TRowData>[];
    draggableRowKeys: string[];
    hasDraggableRows: boolean;
    draggableColumnKeys: string[];
    moveRowByKeyboard: (rowKey: string, direction: -1 | 1) => void;
    moveColumnByKeyboard: (columnKey: string, direction: -1 | 1) => void;
    handleDragEnd: (event: DragEndEvent) => void;
};
