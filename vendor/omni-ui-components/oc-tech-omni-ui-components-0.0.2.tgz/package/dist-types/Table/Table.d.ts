import { TableProps, TableRef } from './Table.types';
import * as React from 'react';
export declare const Table: <TRecord, TRowData = unknown>(props: TableProps<TRecord, TRowData> & {
    ref?: React.Ref<TableRef>;
}) => React.ReactElement;
export default Table;
