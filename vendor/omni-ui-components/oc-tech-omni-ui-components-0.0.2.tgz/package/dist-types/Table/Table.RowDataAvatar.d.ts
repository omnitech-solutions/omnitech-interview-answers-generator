import { RowDataType } from './Table.RowData';
export declare const RowDataAvatarType: RowDataType;
