import * as React from 'react';
export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
    closable?: boolean;
    onClose?: () => void;
    color?: string;
}
export declare const Tag: ({ closable, onClose, color, className, children, ...props }: TagProps) => React.JSX.Element;
