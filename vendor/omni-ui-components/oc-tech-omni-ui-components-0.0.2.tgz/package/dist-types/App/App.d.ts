import * as React from 'react';
export interface AppProps {
    children?: React.ReactNode;
}
export declare const App: ({ children }: AppProps) => React.JSX.Element;
