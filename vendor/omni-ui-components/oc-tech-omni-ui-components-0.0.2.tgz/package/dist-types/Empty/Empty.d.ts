import * as React from 'react';
export interface EmptyProps extends React.HTMLAttributes<HTMLDivElement> {
    image?: React.ReactNode;
    description?: React.ReactNode;
}
export declare const Empty: ({ image, description, className, children, ...props }: EmptyProps) => React.JSX.Element;
