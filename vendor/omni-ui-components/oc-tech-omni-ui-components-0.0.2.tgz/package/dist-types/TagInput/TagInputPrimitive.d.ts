import * as React from 'react';
export interface TagInputPrimitiveProps {
    id?: string;
    name?: string;
    value?: string[];
    defaultValue?: string[];
    onChange?: (next: string[]) => void;
    placeholder?: string;
    pattern?: RegExp;
    maxItems?: number;
    commitOnSpace?: boolean;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    'aria-describedby'?: string;
    'data-testid'?: string;
    className?: string;
}
/** Raw tag input: chips + draft input + commit logic. */
export declare const TagInputPrimitive: React.ForwardRefExoticComponent<TagInputPrimitiveProps & React.RefAttributes<HTMLInputElement>>;
