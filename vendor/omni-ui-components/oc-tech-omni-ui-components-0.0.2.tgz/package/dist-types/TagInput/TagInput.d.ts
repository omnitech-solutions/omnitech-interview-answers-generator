import { FieldLayoutProps } from '../Input/Input.variants';
import { RootProps } from '../lib';
import * as React from 'react';
export interface TagInputProps extends RootProps, FieldLayoutProps {
    id?: string;
    name?: string;
    value?: string[];
    defaultValue?: string[];
    onChange?: (next: string[]) => void;
    placeholder?: string;
    pattern?: RegExp;
    maxItems?: number;
    commitOnSpace?: boolean;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    wrapperClassName?: string;
    labelClassName?: string;
    className?: string;
    'data-testid'?: string;
}
/** Chrome-wrapped Omni TagInput. */
export declare const TagInput: React.NamedExoticComponent<TagInputProps>;
