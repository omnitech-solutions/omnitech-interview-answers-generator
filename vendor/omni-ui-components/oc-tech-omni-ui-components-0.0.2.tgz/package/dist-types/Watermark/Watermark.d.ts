import * as React from 'react';
export interface WatermarkProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'content'> {
    content: React.ReactNode;
    children?: React.ReactNode;
}
export declare const Watermark: ({ content, children, className, ...props }: WatermarkProps) => React.JSX.Element;
