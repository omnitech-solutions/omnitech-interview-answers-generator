import { SegmentedPrimitiveProps } from './Segmented.types';
import * as React from 'react';
/**
 * Raw Omni Segmented primitive — a single-select pill row built on
 * Radix `ToggleGroup`. Selected option uses `bg-primary` + white text;
 * the row itself is a rounded-full muted pill so the active segment
 * "pops" through.
 *
 * Defaults: single-select. Whole control is keyboard-friendly (Left /
 * Right move selection inside the group).
 */
declare const SegmentedPrimitiveInner: React.ForwardRefExoticComponent<SegmentedPrimitiveProps & React.RefAttributes<HTMLDivElement>>;
export declare const SegmentedPrimitive: typeof SegmentedPrimitiveInner;
export {};
