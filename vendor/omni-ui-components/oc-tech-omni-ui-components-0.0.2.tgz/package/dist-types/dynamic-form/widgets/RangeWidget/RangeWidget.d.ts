import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Range widget — slider for numeric schemas. */
export declare const RangeWidget: (props: WidgetProps) => React.JSX.Element;
