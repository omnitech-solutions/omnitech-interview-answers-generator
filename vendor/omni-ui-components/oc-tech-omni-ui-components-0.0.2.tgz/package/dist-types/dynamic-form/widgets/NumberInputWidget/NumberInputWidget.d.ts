import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF NumberInput widget — formatted numeric input. */
export declare const NumberInputWidget: (props: WidgetProps) => React.JSX.Element;
