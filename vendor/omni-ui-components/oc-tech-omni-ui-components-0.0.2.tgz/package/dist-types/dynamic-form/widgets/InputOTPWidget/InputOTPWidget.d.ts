import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF InputOTP widget — one-time-code grid. */
export declare const InputOTPWidget: (props: WidgetProps) => React.JSX.Element;
