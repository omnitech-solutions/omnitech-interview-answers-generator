import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * RJSF FileUpload widget — emits file.name strings (placeholder behavior).
 * Real uploads require feature code to override onChange.
 */
export declare const FileUploadWidget: (props: WidgetProps) => React.JSX.Element;
