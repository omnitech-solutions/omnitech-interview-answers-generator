import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Textarea widget. */
export declare const TextareaWidget: (props: WidgetProps) => React.JSX.Element;
