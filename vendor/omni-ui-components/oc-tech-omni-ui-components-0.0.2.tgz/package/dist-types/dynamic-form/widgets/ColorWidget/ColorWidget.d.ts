import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Color widget — submits `#rrggbb`. */
export declare const ColorWidget: (props: WidgetProps) => React.JSX.Element;
