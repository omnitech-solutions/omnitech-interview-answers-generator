import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Currency widget for monetary fields. */
export declare const CurrencyWidget: (props: WidgetProps) => React.JSX.Element;
