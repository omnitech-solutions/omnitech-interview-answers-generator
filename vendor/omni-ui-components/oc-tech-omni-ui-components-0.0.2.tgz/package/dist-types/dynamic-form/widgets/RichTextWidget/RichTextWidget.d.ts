import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF RichText widget for HTML string values. */
export declare const RichTextWidget: (props: WidgetProps) => React.JSX.Element;
