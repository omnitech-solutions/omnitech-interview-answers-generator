import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Stepper widget for `type: 'integer' | 'number'` schemas. */
export declare const StepperWidget: (props: WidgetProps) => React.JSX.Element;
