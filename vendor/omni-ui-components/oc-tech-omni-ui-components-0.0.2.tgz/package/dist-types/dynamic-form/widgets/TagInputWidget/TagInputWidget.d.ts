import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF TagInput widget — chip-based multi-string input. */
export declare const TagInputWidget: (props: WidgetProps) => React.JSX.Element;
