import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF DateTime widget for `type: 'string', format: 'date-time'`. */
export declare const DateTimeWidget: (props: WidgetProps) => React.JSX.Element;
