import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
export declare const TextWidget: (props: WidgetProps) => React.JSX.Element;
