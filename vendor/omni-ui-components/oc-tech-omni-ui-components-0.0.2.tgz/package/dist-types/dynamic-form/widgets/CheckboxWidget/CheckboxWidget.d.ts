import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Checkbox widget for boolean schemas. */
export declare const CheckboxWidget: (props: WidgetProps) => React.JSX.Element;
