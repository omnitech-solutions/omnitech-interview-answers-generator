import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Switch widget for boolean schemas. */
export declare const SwitchWidget: (props: WidgetProps) => React.JSX.Element;
