import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Phone widget. `ui:options.defaultDialCode` (e.g. `+1`) prefills the dial code. */
export declare const PhoneWidget: (props: WidgetProps) => React.JSX.Element;
