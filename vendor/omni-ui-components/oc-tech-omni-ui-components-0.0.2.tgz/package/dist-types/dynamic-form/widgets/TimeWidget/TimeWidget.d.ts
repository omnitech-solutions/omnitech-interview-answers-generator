import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
/** RJSF Time widget — submits `HH:MM` (24h). */
export declare const TimeWidget: (props: WidgetProps) => React.JSX.Element;
