import { FieldProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * Non-input RJSF field for arbitrary display content rendered inside a
 * form (timer header, "Saved 2m ago" banner, summary panels). The
 * field reads display content from `formContext.derived[panelKey]`
 * (string) or `formContext.actions` for label/href panels. It never
 * writes to `formData`; the schema property should be marked
 * `readOnly: true` and is not part of the submit payload.
 *
 * Two render modes:
 *   - `ui:options.panelKey`  → render `formContext.derived[panelKey]`
 *     as a single block; nice for "12h 21m 32s" timers.
 *   - `ui:options.lines`     → render an array of derived keys as
 *     stacked lines (heading + subheading + status chip).
 */
export declare const StaticPanelField: (props: FieldProps) => React.JSX.Element;
