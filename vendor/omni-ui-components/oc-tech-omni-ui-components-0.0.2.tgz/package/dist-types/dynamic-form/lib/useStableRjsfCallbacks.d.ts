import { WidgetProps } from '@rjsf/utils';
import * as React from 'react';
export interface StableRjsfCallbacks<T = unknown> {
    onChange: (next: T) => void;
    onBlur: (e: React.FocusEvent<HTMLElement>) => void;
    onFocus: (e: React.FocusEvent<HTMLElement>) => void;
}
export declare function useStableRjsfCallbacks<T = unknown>(props: Pick<WidgetProps, 'id' | 'onChange' | 'onBlur' | 'onFocus' | 'options'>, transform?: (next: T, emptyValue: unknown) => unknown): StableRjsfCallbacks<T>;
