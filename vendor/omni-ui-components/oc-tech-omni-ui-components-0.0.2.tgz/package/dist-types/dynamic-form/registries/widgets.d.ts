import { RegistryWidgetsType } from '@rjsf/utils';
/**
 * App-level RJSF widget registry. The single `TextWidget` handles every
 * string-like type (text, email, password, url, tel, …) by reading the
 * `<input type="…">` value from `schema.format` / `props.type`. Routing
 * `EmailWidget` / `PasswordWidget` / `URLWidget` to the same component
 * keeps the bordered look consistent with the bare `TextWidget` — the
 * `@rjsf/shadcn` defaults used different chrome.
 *
 * @example
 * import { appWidgets } from 'dynamic-form';
 * const merged = { ...appWidgets, currency: CurrencyWidget };
 */
export declare const appWidgets: RegistryWidgetsType;
