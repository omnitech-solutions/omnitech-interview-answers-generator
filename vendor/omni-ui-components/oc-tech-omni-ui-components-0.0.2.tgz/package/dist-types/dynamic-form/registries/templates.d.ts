import { TemplatesType } from '@rjsf/utils';
/**
 * Omni overrides layered on top of `@rjsf/shadcn`'s template registry.
 * Only includes templates that change behavior relative to the upstream
 * theme — everything else (GridTemplate, ButtonTemplates, Title/Description,
 * MultiSchema, Array) inherits from `@rjsf/shadcn`.
 *
 * - `ObjectFieldTemplate` adds the flat `ui:rows` authoring API.
 * - `FieldTemplate` paints the required `*` marker in `text-destructive`.
 */
export declare const appTemplates: Partial<TemplatesType>;
