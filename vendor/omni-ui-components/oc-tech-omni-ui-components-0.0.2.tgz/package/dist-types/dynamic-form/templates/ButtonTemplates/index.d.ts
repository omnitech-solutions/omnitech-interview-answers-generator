import { IconButtonProps, SubmitButtonProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * Generic RJSF IconButton template. Omni's `IconButton` provides the
 * chrome; RJSF supplies the icon node + handlers.
 */
export declare const RjsfIconButton: (props: IconButtonProps & {
    icon?: React.ReactNode;
}) => React.JSX.Element;
export declare const CopyButton: (props: IconButtonProps) => React.JSX.Element;
export declare const MoveDownButton: (props: IconButtonProps) => React.JSX.Element;
export declare const MoveUpButton: (props: IconButtonProps) => React.JSX.Element;
export declare const RemoveButton: (props: IconButtonProps) => React.JSX.Element;
export declare const ClearButton: (props: IconButtonProps) => React.JSX.Element;
/**
 * RJSF SubmitButton template. Routes through the shadcn `Button` primitive
 * and honours `ui:submitButtonOptions` (submitText, norender, className,
 * etc.) via {@link getSubmitButtonOptions}.
 *
 * Note: Omni's `DynamicForm` forces `ui:submitButtonOptions.norender =
 * true` by default because the outer `Form` provides its own submit
 * affordance. This template is here for theme parity and for callers who
 * use raw RJSF `Form` or opt back into RJSF's submit (e.g.,
 * `ui:submitButtonOptions: { norender: false }`).
 */
export declare const SubmitButton: (props: SubmitButtonProps) => React.JSX.Element | null;
