import { WrapIfAdditionalTemplateProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * Omni override of `@rjsf/shadcn`'s WrapIfAdditional template. RJSF
 * uses this to wrap properties of an `additionalProperties` object so
 * each row gets a rename-key input + the value field + a remove button +
 * a separator.
 *
 * Differences from the upstream shadcn theme:
 * - Key input is a native `<input>` styled via `inputVariants` so RJSF's
 *   `defaultValue` + `onBlur` rename pipeline works (Omni `Input` is
 *   controlled and would drop `defaultValue`).
 * - Each row is `col-span-12 w-full` so it stacks vertically inside the
 *   parent `ui:rows` grid instead of flowing horizontally.
 * - Remove button comes from the registered
 *   `ButtonTemplates.RemoveButton` (Omni destructive `IconButton`).
 * - Separator is a plain `<hr>` using Omni border tokens.
 */
export declare const WrapIfAdditionalTemplate: (props: WrapIfAdditionalTemplateProps) => React.JSX.Element;
