import { FieldTemplateProps } from '@rjsf/utils';
import * as React from 'react';
/**
 * Omni override of the shadcn `FieldTemplate`. Same structure as the
 * upstream template but the required `*` always renders in
 * `text-destructive`, matching the legacy `.form-field` modal asterisk
 * styling.
 */
export declare const FieldTemplate: (props: FieldTemplateProps) => React.JSX.Element;
