import { RootProps } from '../lib';
import * as React from 'react';
export interface TimePickerPrimitiveProps extends RootProps {
    id?: string;
    name?: string;
    /** Time value in `HH:MM` (24h) form. */
    value?: string;
    defaultValue?: string;
    onChange?: (next: string) => void;
    step?: number;
    min?: string;
    max?: string;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    className?: string;
    'aria-describedby'?: string;
    'data-testid'?: string;
}
declare const TimePickerPrimitiveInner: React.ForwardRefExoticComponent<TimePickerPrimitiveProps & React.RefAttributes<HTMLInputElement>>;
export declare const TimePickerPrimitive: typeof TimePickerPrimitiveInner;
export {};
