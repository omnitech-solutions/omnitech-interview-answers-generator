import { FieldLayoutProps } from '../Input/Input.variants';
import { RootProps } from '../lib';
import * as React from 'react';
export interface TimePickerProps extends RootProps, FieldLayoutProps {
    id?: string;
    name?: string;
    /** Time value in `HH:MM` (24h) form. */
    value?: string;
    defaultValue?: string;
    onChange?: (next: string) => void;
    step?: number;
    min?: string;
    max?: string;
    disabled?: boolean;
    required?: boolean;
    invalid?: boolean;
    readOnly?: boolean;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    wrapperClassName?: string;
    labelClassName?: string;
    className?: string;
    'data-testid'?: string;
}
/**
 * Omni TimePicker — chrome-wrapped {@link TimePickerPrimitive}.
 *
 * @example
 * <TimePicker label="Start time" value={start} onChange={setStart} />
 */
declare const TimePickerInner: React.ForwardRefExoticComponent<TimePickerProps & React.RefAttributes<HTMLInputElement>>;
export declare const TimePicker: typeof TimePickerInner;
export {};
