import { z, ZodTypeAny } from 'zod';
import { FieldDef } from './Form.types';
/**
 * Catalog of pre-built Zod validators for the common field shapes. Pair with
 * `buildZodSchema` via `ZodFieldDef.validate`:
 *
 * @example
 * buildZodSchema([
 *   { name: 'email', label: 'Email', required: true, validate: validators.email() },
 *   { name: 'zip', label: 'ZIP', required: true, validate: validators.postalCode('US') },
 * ]);
 */
export declare const validators: {
    readonly text: (opts?: {
        min?: number;
        max?: number;
        label?: string;
    }) => z.ZodString;
    readonly email: (message?: string) => z.ZodString;
    readonly password: (opts?: {
        min?: number;
    }) => z.ZodString;
    readonly url: (message?: string) => z.ZodString;
    readonly tel: (message?: string) => z.ZodString;
    readonly number: (opts?: {
        min?: number;
        max?: number;
        int?: boolean;
    }) => z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
    /** Postal code by ISO country. `US` → 5 digits, `CA` → A1A 1A1, fallback → 3–10 alphanumerics. */
    readonly postalCode: (country?: "US" | "CA" | "UK" | "INTL") => z.ZodString;
    /** Permissive credit-card check: digits + Luhn checksum. */
    readonly creditCard: () => z.ZodString;
    /** Date in ISO `YYYY-MM-DD` form. */
    readonly date: () => z.ZodString;
};
/** Field declaration enriched with optional Zod overrides used by `buildZodSchema`. */
export interface ZodFieldDef<TName extends string = string> extends FieldDef<TName> {
    /** Replace the default validator for this field entirely. */
    validate?: ZodTypeAny;
    /** Override the "required" message used when the field is empty. */
    requiredMessage?: string;
}
/**
 * Build a Zod object schema from a flat array of {@link ZodFieldDef} entries.
 * Honors `field.required` (adds an empty-string / non-positive min) and
 * `field.validate` (full validator override per field).
 *
 * @example
 * const schema = buildZodSchema([
 *   { name: 'email', label: 'Email', type: 'email', required: true },
 *   { name: 'age', label: 'Age', type: 'number', validate: z.coerce.number().min(18, 'Must be 18+') },
 * ]);
 */
export declare function buildZodSchema<TName extends string>(fields: ZodFieldDef<TName>[]): z.ZodObject<any>;
/** Flatten a row layout (`FieldDef[][]` / `FormRowDef` / heading rows) into a flat field list. */
export declare function fieldsFromRows<TName extends string>(rows: (ZodFieldDef<TName>[] | {
    fields: ZodFieldDef<TName>[];
} | {
    kind: 'heading';
})[]): ZodFieldDef<TName>[];
