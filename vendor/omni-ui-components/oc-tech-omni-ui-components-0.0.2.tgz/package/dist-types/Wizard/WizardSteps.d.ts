import { WizardStepsProps } from './Wizard.types';
import * as React from 'react';
/**
 * Wizard step indicator — numbered circles separated by em-dashes.
 * Completed steps fill with `bg-primary` + checkmark; active step is
 * `bg-foreground`; upcoming steps render as hollow outlines.
 *
 * Linear-forward by default (clicking an unreached step is a no-op).
 * Set `forceLinearForward={false}` to allow jumping ahead.
 */
declare const WizardStepsInner: React.ForwardRefExoticComponent<WizardStepsProps & React.RefAttributes<HTMLElement>>;
export declare const WizardSteps: typeof WizardStepsInner;
export {};
