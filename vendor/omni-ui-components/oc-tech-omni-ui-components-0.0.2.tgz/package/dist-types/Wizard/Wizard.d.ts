import { WizardProps } from './Wizard.types';
import * as React from 'react';
/**
 * Omni Wizard — orchestrates a multi-step flow.
 *
 * Composes:
 * - {@link WizardSteps} (step indicator)
 * - The current step's `content`
 * - Back / Next / Finish action row (skippable via `hideActions`)
 *
 * Controlled mode: pass `currentStep` + `onStepChange`. Uncontrolled:
 * pass `defaultStep` (or omit — first step is used).
 *
 * @example
 * <Wizard
 *   steps={[
 *     { name: 'basic',   label: 'Basic info', content: <BasicInfoForm /> },
 *     { name: 'payment', label: 'Payment',     content: <PaymentForm /> },
 *     { name: 'review',  label: 'Review',      content: <ReviewPanel />, canAdvance: hasAgreed },
 *   ]}
 *   onComplete={() => save()}
 * />
 */
declare const WizardInner: React.ForwardRefExoticComponent<WizardProps & React.RefAttributes<HTMLDivElement>>;
export declare const Wizard: typeof WizardInner;
export {};
