import { IconButtonProps } from './IconButton.types';
import * as React from 'react';
/**
 * Omni IconButton — square, icon-only button used by RJSF array
 * toolbars (copy / move / remove) and other compact affordances. Sizes
 * track the Omni field-height scale so the button sits cleanly next to
 * Input / Select / Textarea rows.
 *
 * Mirrors `@rjsf/shadcn`'s IconButton API (`icon`, `variant`, size). One
 * of `label` / `aria-label` / `title` is required for a11y; the wrapper
 * does not enforce this at the type level so the props stay structurally
 * compatible with RJSF's `IconButtonProps`.
 *
 * @example
 * <IconButton aria-label="Remove" icon={<Trash2 />} variant="destructive" onClick={…} />
 */
declare const IconButtonInner: React.ForwardRefExoticComponent<IconButtonProps & React.RefAttributes<HTMLButtonElement>>;
export declare const IconButton: typeof IconButtonInner;
export {};
