import { VariantProps } from 'class-variance-authority';
/**
 * Tailwind class config for IconButton. Sizes track the Omni field
 * height scale (`--oui-field-height-*`) so IconButtons sit cleanly next
 * to Input / Select / Textarea rows.
 */
export declare const iconButtonVariants: (props?: ({
    variant?: "ghost" | "default" | "link" | "destructive" | "outline" | "secondary" | null | undefined;
    iconSize?: "sm" | "default" | "md" | "lg" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type IconButtonVariantProps = VariantProps<typeof iconButtonVariants>;
