import * as React from 'react';
export interface PopconfirmProps {
    title: React.ReactNode;
    description?: React.ReactNode;
    onConfirm?: () => void;
    onCancel?: () => void;
    confirmText?: React.ReactNode;
    cancelText?: React.ReactNode;
    children: React.ReactNode;
}
export declare const Popconfirm: ({ title, description, onConfirm, onCancel, confirmText, cancelText, children }: PopconfirmProps) => React.JSX.Element;
