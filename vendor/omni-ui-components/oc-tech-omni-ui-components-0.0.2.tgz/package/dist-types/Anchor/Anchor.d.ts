import * as React from 'react';
export interface AnchorItem {
    key?: React.Key;
    href: string;
    title: React.ReactNode;
}
export interface AnchorProps extends React.HTMLAttributes<HTMLElement> {
    items: AnchorItem[];
}
export declare const Anchor: ({ items, className, ...props }: AnchorProps) => React.JSX.Element;
