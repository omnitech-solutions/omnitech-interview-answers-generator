import * as React from 'react';
export type StepItem = {
    key?: React.Key;
    title: React.ReactNode;
    description?: React.ReactNode;
    status?: 'wait' | 'process' | 'finish' | 'error';
    disabled?: boolean;
};
export interface StepsProps extends Omit<React.HTMLAttributes<HTMLOListElement>, 'onChange'> {
    items?: StepItem[];
    current?: number;
    direction?: 'horizontal' | 'vertical';
    size?: 'default' | 'small';
    status?: 'wait' | 'process' | 'finish' | 'error';
    onChange?: (current: number) => void;
}
export declare const Steps: React.ForwardRefExoticComponent<StepsProps & React.RefAttributes<HTMLOListElement>>;
