import { TooltipProps, TooltipProviderProps, TooltipTriggerProps } from './Tooltip.types';
import * as React from 'react';
export declare const Tooltip: React.FC<TooltipProps>;
export declare const TooltipRootProvider: React.FC<TooltipProviderProps>;
export declare const TooltipTriggerRoot: React.FC<TooltipTriggerProps>;
declare const TooltipContentInner: React.ForwardRefExoticComponent<Omit<import('@radix-ui/react-tooltip').TooltipContentProps & React.RefAttributes<HTMLDivElement>, "ref"> & React.RefAttributes<HTMLDivElement>>;
export declare const TooltipPopup: typeof TooltipContentInner;
export {};
