import * as React from 'react';
export interface SplitterProps extends React.HTMLAttributes<HTMLDivElement> {
    children?: React.ReactNode;
}
export interface SplitterPanelProps extends React.HTMLAttributes<HTMLDivElement> {
    defaultSize?: string | number;
}
export declare const Splitter: ({ className, children, ...props }: SplitterProps) => React.JSX.Element;
export declare const SplitterPanel: ({ defaultSize, style, ...props }: SplitterPanelProps) => React.JSX.Element;
