import { VariantProps } from 'class-variance-authority';
/**
 * Tailwind class config for the Input primitive. All colors and metrics
 * come from `omni-ui-components/styles/tokens.css` so retheming a subtree
 * is a CSS-variable override, not a component change.
 *
 * @example
 * <input className={inputVariants({ variant: 'bordered', inputSize: 'md' })} />
 */
export declare const inputVariants: (props?: ({
    variant?: "bordered" | "ghost" | null | undefined;
    inputSize?: "sm" | "default" | "md" | "lg" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type InputVariantProps = VariantProps<typeof inputVariants>;
export type InputVariant = NonNullable<InputVariantProps['variant']>;
export type InputSize = NonNullable<InputVariantProps['inputSize']>;
/**
 * Field-group layout variants. `vertical` stacks label / input / helpers
 * (default form layout). `horizontal` aligns the label inline on the left
 * with a fixed-width column and lets the input flex (PropertyRow pattern).
 *
 * @example
 * <div className={fieldGroupVariants({ layout: 'horizontal' })}>…</div>
 */
export declare const fieldGroupVariants: (props?: ({
    layout?: "vertical" | "horizontal" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export declare const fieldLabelVariants: (props?: ({
    layout?: "vertical" | "horizontal" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type FieldLayoutProps = VariantProps<typeof fieldGroupVariants>;
export type FieldLayout = NonNullable<FieldLayoutProps['layout']>;
