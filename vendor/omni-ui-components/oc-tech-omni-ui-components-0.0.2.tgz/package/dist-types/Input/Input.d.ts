import { InputProps } from './Input.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Input. Composes {@link InputPrimitive} with a
 * label / description / error stack via {@link FieldShell}.
 *
 * @example
 * <Input label="Project Title" value={title} onChange={setTitle} required />
 */
declare const InputInner: React.ForwardRefExoticComponent<Omit<InputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
export declare const Input: typeof InputInner;
export {};
