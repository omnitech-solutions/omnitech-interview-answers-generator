import * as React from 'react';
export interface SpaceProps extends React.HTMLAttributes<HTMLDivElement> {
    direction?: 'horizontal' | 'vertical';
    size?: number | string;
    wrap?: boolean;
}
export declare const Space: ({ direction, size, wrap, className, style, ...props }: SpaceProps) => React.JSX.Element;
