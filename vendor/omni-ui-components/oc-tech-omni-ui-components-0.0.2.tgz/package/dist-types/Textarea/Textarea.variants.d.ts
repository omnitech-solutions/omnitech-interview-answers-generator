import { VariantProps } from 'class-variance-authority';
/**
 * Tailwind class config for the Textarea primitive. Shares the Input
 * variant + size scale so a `<Textarea size="md">` reads the same metrics
 * as `<Input inputSize="md">`. Colors and metrics come from
 * `omni-ui-components/styles/tokens.css`.
 *
 * @example
 * <textarea className={textareaVariants({ variant: 'bordered', textareaSize: 'default' })} />
 */
export declare const textareaVariants: (props?: ({
    variant?: "bordered" | "ghost" | null | undefined;
    textareaSize?: "sm" | "default" | "md" | "lg" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
export type TextareaVariantProps = VariantProps<typeof textareaVariants>;
export type TextareaVariant = NonNullable<TextareaVariantProps['variant']>;
export type TextareaSize = NonNullable<TextareaVariantProps['textareaSize']>;
