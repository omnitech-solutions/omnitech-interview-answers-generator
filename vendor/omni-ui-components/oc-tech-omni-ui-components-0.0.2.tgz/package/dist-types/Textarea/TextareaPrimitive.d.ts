import { TextareaPrimitiveProps } from './Textarea.types';
import * as React from 'react';
/**
 * Raw Omni textarea primitive. Renders a styled `<textarea>` and nothing
 * else. No label, no description, no error row — pair with {@link Textarea}
 * when field chrome is needed.
 *
 * Wrapped in `React.memo` so RJSF parent re-renders only touch fields whose
 * props actually changed; unchanged sibling fields skip the work entirely.
 *
 * @example
 * <TextareaPrimitive variant="ghost" value={value} onChange={setValue} />
 *
 * @example
 * <TextareaPrimitive
 *   variant="bordered"
 *   textareaSize="default"
 *   rows={6}
 *   invalid={Boolean(errors.message)}
 *   onChange={setMessage}
 *   value={message}
 * />
 */
declare const TextareaPrimitiveInner: React.ForwardRefExoticComponent<Omit<TextareaPrimitiveProps, "ref"> & React.RefAttributes<HTMLTextAreaElement>>;
export declare const TextareaPrimitive: typeof TextareaPrimitiveInner;
export {};
