import { TextareaProps } from './Textarea.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Textarea. Composes {@link TextareaPrimitive} with
 * label / description / error rows via {@link FieldShell}.
 *
 * @example
 * <Textarea label="Message" value={msg} onChange={setMsg} rows={6} required />
 */
declare const TextareaInner: React.ForwardRefExoticComponent<Omit<TextareaProps, "ref"> & React.RefAttributes<HTMLTextAreaElement>>;
export declare const Textarea: typeof TextareaInner;
export {};
