import * as React from 'react';
export interface StatisticProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title' | 'prefix'> {
    title?: React.ReactNode;
    value: React.ReactNode;
    prefix?: React.ReactNode;
    suffix?: React.ReactNode;
}
export declare const Statistic: ({ title, value, prefix, suffix, className, ...props }: StatisticProps) => React.JSX.Element;
