import { SwitchPrimitiveProps } from './Switch.types';
import * as React from 'react';
/**
 * Raw Omni Switch primitive (Radix `@radix-ui/react-switch` via the
 * shadcn `components/ui/switch` wrapper). Use {@link Switch} for the
 * chrome-wrapped variant with label / description / error.
 */
declare const SwitchPrimitiveInner: React.ForwardRefExoticComponent<SwitchPrimitiveProps & React.RefAttributes<HTMLButtonElement>>;
export declare const SwitchPrimitive: typeof SwitchPrimitiveInner;
export {};
