import { SwitchProps } from './Switch.types';
import * as React from 'react';
/**
 * Chrome-wrapped Omni Switch. The full row is a `<label>` so clicking
 * anywhere toggles the switch.
 *
 * @example
 * <Switch label="Email notifications" description="Daily digest at 9am." checked={on} onChange={setOn} />
 */
declare const SwitchInner: React.ForwardRefExoticComponent<SwitchProps & React.RefAttributes<HTMLButtonElement>>;
export declare const Switch: typeof SwitchInner;
export {};
