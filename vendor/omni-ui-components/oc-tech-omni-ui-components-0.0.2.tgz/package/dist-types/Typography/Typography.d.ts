import * as React from 'react';
export declare const Typography: {
    Text: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "ref"> & {
        type?: "secondary" | "success" | "warning" | "danger";
    } & React.RefAttributes<HTMLElement>>>;
    Title: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "ref"> & {
        type?: "secondary" | "success" | "warning" | "danger";
    } & React.RefAttributes<HTMLElement>>>;
    Paragraph: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>, "ref"> & {
        type?: "secondary" | "success" | "warning" | "danger";
    } & React.RefAttributes<HTMLElement>>>;
    Link: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.AnchorHTMLAttributes<HTMLAnchorElement>, HTMLAnchorElement>, "ref"> & {
        type?: "secondary" | "success" | "warning" | "danger";
    } & React.RefAttributes<HTMLElement>>>;
};
