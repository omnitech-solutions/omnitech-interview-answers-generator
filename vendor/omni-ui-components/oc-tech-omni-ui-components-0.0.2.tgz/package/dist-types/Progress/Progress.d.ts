import * as React from 'react';
export interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
    percent?: number;
    showInfo?: boolean;
    status?: 'normal' | 'success' | 'exception' | 'active';
}
export declare const Progress: ({ percent, showInfo, status, className, ...props }: ProgressProps) => React.JSX.Element;
