import * as React from 'react';
export interface TimelineItem {
    key?: React.Key;
    color?: string;
    children: React.ReactNode;
}
export interface TimelineProps extends React.HTMLAttributes<HTMLUListElement> {
    items: TimelineItem[];
}
export declare const Timeline: ({ items, className, ...props }: TimelineProps) => React.JSX.Element;
