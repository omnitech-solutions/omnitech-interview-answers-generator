import { Select } from '../Select';
import * as React from 'react';
export interface TreeSelectNode {
    value: string;
    title: string;
    children?: TreeSelectNode[];
}
export interface TreeSelectProps extends Omit<React.ComponentProps<typeof Select>, 'options'> {
    treeData: TreeSelectNode[];
}
export declare const TreeSelect: ({ treeData, ...props }: TreeSelectProps) => React.JSX.Element;
