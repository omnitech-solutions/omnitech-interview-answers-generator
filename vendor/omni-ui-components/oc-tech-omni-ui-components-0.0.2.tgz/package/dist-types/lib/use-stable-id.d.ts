/**
 * Stable component-instance id usable for `htmlFor` and `aria-describedby`
 * wiring. SSR-safe because each render reuses the ref-cached value.
 *
 * @example
 * const id = useStableId('oui-input');
 * <label htmlFor={id}>…</label>
 * <input id={id} />
 */
export declare const useStableId: (prefix?: string) => string;
