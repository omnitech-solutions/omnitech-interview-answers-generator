import { FieldLayoutProps } from '../Input/Input.variants';
import * as React from 'react';
export interface FieldChromeArgs {
    id?: string;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    invalid?: boolean;
    required?: boolean;
    prefix: string;
}
export interface FieldChrome {
    id: string;
    isInvalid: boolean;
    descriptionId?: string;
    errorId?: string;
    describedBy?: string;
}
export declare function useFieldChrome({ id, label: _label, description, error, invalid, prefix }: FieldChromeArgs): FieldChrome;
export interface FieldShellProps extends FieldLayoutProps {
    id: string;
    label?: React.ReactNode;
    description?: React.ReactNode;
    error?: React.ReactNode;
    required?: boolean;
    descriptionId?: string;
    errorId?: string;
    labelTag?: 'label' | 'span';
    labelId?: string;
    role?: string;
    ariaLabelledBy?: string;
    wrapperClassName?: string;
    labelClassName?: string;
    children: React.ReactNode;
}
export declare const FieldShell: React.FC<FieldShellProps>;
