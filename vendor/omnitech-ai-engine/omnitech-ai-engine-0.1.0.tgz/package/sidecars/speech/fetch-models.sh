#!/bin/sh
# Fetches the speech model files named in models.json into a directory, and
# proves each one by size and SHA-256 before it is given its final name.
#
#   fetch-models.sh <directory>           download what is missing, verify everything
#   fetch-models.sh <directory> --check   verify only; download nothing
#
# Safe to run again: a verified file is left alone, and an interrupted download
# resumes from its `.part`. Needs sh, curl, grep, sed and sha256sum or shasum.
#
# MODELS_JSON   the pin file. Default: models.json beside this script.
# HF_ENDPOINT   the hub to fetch from. Default: https://huggingface.co
set -eu

here=$(cd "$(dirname "$0")" && pwd)
pins="${MODELS_JSON:-$here/models.json}"
endpoint="${HF_ENDPOINT:-https://huggingface.co}"
directory="${1:?usage: fetch-models.sh <directory> [--check]}"
mode="${2:-fetch}"

say() { printf 'speech-models: %s\n' "$*"; }
fail() { printf 'speech-models: %s\n' "$*" >&2; exit 1; }

[ -f "$pins" ] || fail "the pin file is missing: $pins"

# [STRATEGY] The pin file is flat JSON this package writes, so its fields are
# read with grep and sed and no JSON tool has to be installed anywhere.
flat=$(tr -d ' \n\r\t' < "$pins")
# A field that is absent reads as empty, and is refused by name below.
text_field() { printf '%s' "$flat" | { grep -o "\"$1\":\"[^\"]*\"" || true; } | sed 's/^[^:]*:"//; s/"$//'; }
repository=$(text_field repository)
revision=$(text_field revision)
model_id=$(text_field id)
roles=$(text_field role)
names=$(text_field name)
hashes=$(text_field sha256)
sizes=$(printf '%s' "$flat" | { grep -o '"size":[0-9]*' || true; } | sed 's/^[^:]*://')
count=$(printf '%s\n' "$names" | grep -c . || true)

[ -n "$repository" ] && [ -n "$revision" ] && [ "$count" -gt 0 ] || fail "the pin file names no model: $pins"

nth() { printf '%s\n' "$1" | sed -n "${2}p"; }
size_of() { wc -c < "$1" | tr -d ' '; }
sha256_of() {
  if command -v sha256sum > /dev/null 2>&1; then sha256sum "$1" | cut -d' ' -f1
  elif command -v shasum > /dev/null 2>&1; then shasum -a 256 "$1" | cut -d' ' -f1
  else fail "neither sha256sum nor shasum is installed"; fi
}
# [GUARD] A file is the pinned one only when both its size and its hash say so.
verified() { [ -f "$1" ] && [ "$(size_of "$1")" = "$2" ] && [ "$(sha256_of "$1")" = "$3" ]; }

mkdir -p "$directory"
index=1
while [ "$index" -le "$count" ]; do
  role=$(nth "$roles" "$index")
  name=$(nth "$names" "$index")
  size=$(nth "$sizes" "$index")
  hash=$(nth "$hashes" "$index")
  index=$((index + 1))
  # [SAFETY] A name becomes a path and part of a URL: a plain file name only.
  case "$name" in */* | *..* | "") fail "not a plain file name in the pin file: $name" ;; esac
  case "$role" in */* | *..* | "") fail "not a plain role in the pin file: $role" ;; esac
  target="$directory/$name"
  part="$target.part"

  if verified "$target" "$size" "$hash"; then
    say "$name is present and verified ($size bytes)"
  elif [ "$mode" = "--check" ]; then
    fail "$name is missing or does not match its pin (expected $size bytes, sha256 $hash)"
  else
    # [GUARD] A final file that does not verify is not the pinned file: it is set aside, never served.
    [ ! -e "$target" ] || { say "$name does not match its pin; fetching it again"; rm -f "$target"; }
    # A part larger than the whole cannot be resumed.
    if [ -f "$part" ] && [ "$(size_of "$part")" -gt "$size" ]; then rm -f "$part"; fi
    if [ ! -f "$part" ] || [ "$(size_of "$part")" -lt "$size" ]; then
      url="$endpoint/$repository/resolve/$revision/$name"
      say "fetching $name ($size bytes) from $url"
      quiet="-sS"
      [ -t 2 ] && quiet="--progress-bar"
      # [STRATEGY] `-C -` resumes from what the part already holds.
      curl -fL $quiet --retry 5 --retry-delay 2 -C - -o "$part" "$url" \
        || fail "the download of $name did not finish; run this again to resume it"
    fi
    if ! verified "$part" "$size" "$hash"; then
      got_size=$(size_of "$part")
      rm -f "$part"
      fail "$name does not match its pin after download (got $got_size bytes, expected $size bytes, sha256 $hash); the part was removed"
    fi
    mv "$part" "$target"
    say "$name fetched and verified ($size bytes)"
  fi
  # [DOMAIN] The server loads a model by its role, so a new pin needs no new command line.
  # A file already named for its role needs no link (and must not become one to itself).
  [ "$name" = "$role.gguf" ] || ln -sf "$name" "$directory/$role.gguf"
done

if [ "$mode" != "--check" ]; then printf '%s' "$model_id" > "$directory/model.id"; fi
say "all $count model files are verified in $directory"
