#!/bin/sh
# Builds the speech server on this machine from the pinned source: with Apple
# Metal on macOS, for the CPU elsewhere. The commit is the one the Dockerfile
# names, so both ways of running the server run the same source.
#
#   build-native.sh <directory>
#
# Leaves <directory>/build/tts-server. Safe to run again: an up-to-date build
# is left alone. Installs nothing: a missing tool stops the build with the
# command that installs it.
set -eu

here=$(cd "$(dirname "$0")" && pwd)
out="${1:?usage: build-native.sh <directory>}"
repository=$(sed -n 's/^ARG QWENTTS_REPOSITORY=//p' "$here/Dockerfile")
commit=$(sed -n 's/^ARG QWENTTS_COMMIT=//p' "$here/Dockerfile")
[ -n "$repository" ] && [ -n "$commit" ] || { echo "speech-native: the Dockerfile names no pinned source" >&2; exit 1; }

system=$(uname -s)
# [GUARD] Nothing is installed on the user's behalf.
need() {
  command -v "$1" > /dev/null 2>&1 && return 0
  echo "speech-native: $1 is not installed. Install it with: $2" >&2
  exit 1
}
if [ "$system" = "Darwin" ]; then
  need git "xcode-select --install"
  need c++ "xcode-select --install"
  need cmake "brew install cmake"
else
  need git "apt-get install git"
  need c++ "apt-get install g++"
  need cmake "apt-get install cmake"
fi

mkdir -p "$out"
out=$(cd "$out" && pwd)
if [ -x "$out/build/tts-server" ] && [ "$(cat "$out/.commit" 2> /dev/null || true)" = "$commit" ]; then
  echo "speech-native: $out/build/tts-server is up to date ($commit)"
  exit 0
fi

# [STRATEGY] Fetch exactly the pinned commit, and the submodule commit it records.
source="$out/src"
if [ ! -d "$source/.git" ]; then
  git init -q "$source"
  git -C "$source" remote add origin "$repository"
fi
echo "speech-native: fetching $repository at $commit"
git -C "$source" fetch -q --depth 1 origin "$commit"
git -C "$source" checkout -q --detach FETCH_HEAD
git -C "$source" submodule update -q --init --recursive --depth 1

if [ "$system" = "Darwin" ]; then
  flags="-DGGML_METAL=ON -DGGML_METAL_EMBED_LIBRARY=ON"
  echo "speech-native: configuring with Apple Metal"
else
  flags=""
  echo "speech-native: configuring for this machine's CPU"
fi
# shellcheck disable=SC2086
cmake -S "$source" -B "$out/build" -DCMAKE_BUILD_TYPE=Release $flags > "$out/configure.log" 2>&1 \
  || { tail -n 40 "$out/configure.log" >&2; echo "speech-native: configuring failed; see $out/configure.log" >&2; exit 1; }
echo "speech-native: building tts-server (a few minutes the first time)"
cmake --build "$out/build" --config Release --target tts-server -j "$(getconf _NPROCESSORS_ONLN)" > "$out/build.log" 2>&1 \
  || { tail -n 40 "$out/build.log" >&2; echo "speech-native: the build failed; see $out/build.log" >&2; exit 1; }
[ -x "$out/build/tts-server" ] || { echo "speech-native: the build finished without a tts-server binary" >&2; exit 1; }
printf '%s' "$commit" > "$out/.commit"
echo "speech-native: built $out/build/tts-server ($commit)"
