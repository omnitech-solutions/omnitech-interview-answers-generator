CREATE SCHEMA IF NOT EXISTS assistant;
CREATE TABLE IF NOT EXISTS assistant.threads (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL,
  workspace_id text NOT NULL, artifact_id text NOT NULL, title text NOT NULL,
  revision bigint NOT NULL DEFAULT 0 CHECK (revision >= 0), message_sequence bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, id)
);
CREATE INDEX IF NOT EXISTS assistant_thread_binding ON assistant.threads (tenant_id, actor_id, product_id, workspace_id, artifact_id);
CREATE TABLE IF NOT EXISTS assistant.runs (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL UNIQUE,
  thread_id text NOT NULL, input jsonb NOT NULL, versions jsonb NOT NULL,
  idempotency_key text NOT NULL, fingerprint text NOT NULL,
  status text NOT NULL CHECK (status IN ('queued','running','completed','failed','cancelled','interrupted')),
  sequence bigint NOT NULL DEFAULT 0 CHECK (sequence >= 0), lease_owner text, lease_until timestamptz,
  queue_job_id text, created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, id),
  UNIQUE (tenant_id, actor_id, product_id, idempotency_key),
  UNIQUE (tenant_id, actor_id, product_id, id, thread_id),
  FOREIGN KEY (tenant_id, actor_id, product_id, thread_id) REFERENCES assistant.threads (tenant_id, actor_id, product_id, id),
  CHECK ((status='running' AND lease_owner IS NOT NULL AND lease_until IS NOT NULL) OR (status<>'running' AND lease_owner IS NULL AND lease_until IS NULL))
);
CREATE TABLE IF NOT EXISTS assistant.events (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, run_id text NOT NULL,
  sequence bigint NOT NULL CHECK (sequence > 0), type text NOT NULL, payload jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, run_id, sequence),
  FOREIGN KEY (tenant_id, actor_id, product_id, run_id) REFERENCES assistant.runs (tenant_id, actor_id, product_id, id)
);
CREATE TABLE IF NOT EXISTS assistant.messages (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL,
  thread_id text NOT NULL, run_id text NOT NULL, sequence bigint NOT NULL CHECK (sequence>0),
  role text NOT NULL CHECK (role IN ('user','assistant','system','tool')), parts jsonb NOT NULL,
  status text NOT NULL CHECK (status IN ('complete','partial')), created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, id),
  UNIQUE (tenant_id, actor_id, product_id, thread_id, sequence),
  FOREIGN KEY (tenant_id, actor_id, product_id, thread_id) REFERENCES assistant.threads (tenant_id, actor_id, product_id, id),
  FOREIGN KEY (tenant_id, actor_id, product_id, run_id, thread_id) REFERENCES assistant.runs (tenant_id, actor_id, product_id, id, thread_id)
);
CREATE TABLE IF NOT EXISTS assistant.proposals (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL,
  run_id text NOT NULL, proposal jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','applied','rejected','conflicted')),
  PRIMARY KEY (tenant_id, actor_id, product_id, id),
  FOREIGN KEY (tenant_id, actor_id, product_id, run_id) REFERENCES assistant.runs (tenant_id, actor_id, product_id, id)
);
CREATE TABLE IF NOT EXISTS assistant.receipts (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, proposal_id text NOT NULL,
  receipt jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, proposal_id),
  FOREIGN KEY (tenant_id, actor_id, product_id, proposal_id) REFERENCES assistant.proposals (tenant_id, actor_id, product_id, id)
);
CREATE TABLE IF NOT EXISTS assistant.attachments (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL,
  thread_id text NOT NULL, metadata jsonb NOT NULL,
  PRIMARY KEY (tenant_id, actor_id, product_id, id),
  FOREIGN KEY (tenant_id, actor_id, product_id, thread_id) REFERENCES assistant.threads (tenant_id, actor_id, product_id, id)
);
CREATE OR REPLACE FUNCTION assistant.refuse_event_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'Assistant events are append-only' USING ERRCODE='55000'; END $$;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgrelid='assistant.events'::regclass AND tgname='assistant_events_append_only') THEN
    CREATE TRIGGER assistant_events_append_only BEFORE UPDATE OR DELETE ON assistant.events FOR EACH ROW EXECUTE FUNCTION assistant.refuse_event_mutation();
  END IF;
END $$;
-- Private rows require all three trusted scope values, even for direct SQL.
DO $$ DECLARE table_name text; BEGIN
  FOREACH table_name IN ARRAY ARRAY['threads','runs','events','messages','proposals','receipts','attachments'] LOOP
    EXECUTE format('ALTER TABLE assistant.%I ENABLE ROW LEVEL SECURITY', table_name);
    EXECUTE format('ALTER TABLE assistant.%I FORCE ROW LEVEL SECURITY', table_name);
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='assistant' AND tablename=table_name AND policyname='private_scope') THEN
      EXECUTE format('CREATE POLICY private_scope ON assistant.%I USING (tenant_id=current_setting(''app.tenant_id'',true) AND actor_id=current_setting(''app.actor_id'',true) AND product_id=current_setting(''app.product_id'',true)) WITH CHECK (tenant_id=current_setting(''app.tenant_id'',true) AND actor_id=current_setting(''app.actor_id'',true) AND product_id=current_setting(''app.product_id'',true))', table_name);
    END IF;
  END LOOP;
END $$;
