-- A person's standing preferences for the assistant in a product.
CREATE TABLE IF NOT EXISTS assistant.preferences (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL,
  instructions text NOT NULL DEFAULT '', memory_enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id)
);
-- Facts the person asked the assistant to remember across conversations.
CREATE TABLE IF NOT EXISTS assistant.memories (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL,
  text text NOT NULL CHECK (length(text) BETWEEN 1 AND 500),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, id)
);
DO $$ DECLARE table_name text; BEGIN
  FOREACH table_name IN ARRAY ARRAY['preferences','memories'] LOOP
    EXECUTE format('ALTER TABLE assistant.%I ENABLE ROW LEVEL SECURITY', table_name);
    EXECUTE format('ALTER TABLE assistant.%I FORCE ROW LEVEL SECURITY', table_name);
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='assistant' AND tablename=table_name AND policyname='private_scope') THEN
      EXECUTE format('CREATE POLICY private_scope ON assistant.%I USING (tenant_id=current_setting(''app.tenant_id'',true) AND actor_id=current_setting(''app.actor_id'',true) AND product_id=current_setting(''app.product_id'',true)) WITH CHECK (tenant_id=current_setting(''app.tenant_id'',true) AND actor_id=current_setting(''app.actor_id'',true) AND product_id=current_setting(''app.product_id'',true))', table_name);
    END IF;
  END LOOP;
END $$;
