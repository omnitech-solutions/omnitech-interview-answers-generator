-- Conversation management: pin, archive, soft delete, branches, feedback, run errors.
ALTER TABLE assistant.threads ADD COLUMN IF NOT EXISTS pinned_at timestamptz;
ALTER TABLE assistant.threads ADD COLUMN IF NOT EXISTS archived_at timestamptz;
-- Deleted conversations stay restorable until purged.
ALTER TABLE assistant.threads ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
-- The leaf of the branch the user is looking at; the model sees the path to it.
ALTER TABLE assistant.threads ADD COLUMN IF NOT EXISTS head_message_id text;

ALTER TABLE assistant.messages ADD COLUMN IF NOT EXISTS parent_id text;
CREATE INDEX IF NOT EXISTS assistant_message_parent ON assistant.messages (tenant_id, actor_id, product_id, thread_id, parent_id);

-- The user message a run answers (new, edited, or answered again), and why it stopped.
ALTER TABLE assistant.runs ADD COLUMN IF NOT EXISTS user_message_id text;
ALTER TABLE assistant.runs ADD COLUMN IF NOT EXISTS error jsonb;

-- Threads written before branches existed are one straight line.
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM assistant.messages WHERE parent_id IS NULL AND sequence > 1) THEN
    ALTER TABLE assistant.messages DISABLE ROW LEVEL SECURITY;
    UPDATE assistant.messages m SET parent_id = previous.id
      FROM assistant.messages previous
      WHERE m.parent_id IS NULL AND m.sequence > 1
        AND (previous.tenant_id, previous.actor_id, previous.product_id, previous.thread_id) = (m.tenant_id, m.actor_id, m.product_id, m.thread_id)
        AND previous.sequence = m.sequence - 1;
    ALTER TABLE assistant.messages ENABLE ROW LEVEL SECURITY;
  END IF;
  ALTER TABLE assistant.threads DISABLE ROW LEVEL SECURITY;
  UPDATE assistant.threads t SET head_message_id = (
    SELECT id FROM assistant.messages m
    WHERE (m.tenant_id, m.actor_id, m.product_id, m.thread_id) = (t.tenant_id, t.actor_id, t.product_id, t.id)
    ORDER BY sequence DESC LIMIT 1)
  WHERE head_message_id IS NULL;
  ALTER TABLE assistant.threads ENABLE ROW LEVEL SECURITY;
  ALTER TABLE assistant.runs DISABLE ROW LEVEL SECURITY;
  UPDATE assistant.runs r SET user_message_id = (
    SELECT id FROM assistant.messages m
    WHERE (m.tenant_id, m.actor_id, m.product_id, m.run_id) = (r.tenant_id, r.actor_id, r.product_id, r.id) AND m.role = 'user'
    ORDER BY sequence LIMIT 1)
  WHERE user_message_id IS NULL;
  ALTER TABLE assistant.runs ENABLE ROW LEVEL SECURITY;
END $$;

CREATE TABLE IF NOT EXISTS assistant.feedback (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, message_id text NOT NULL,
  rating text NOT NULL CHECK (rating IN ('up','down')), reasons jsonb NOT NULL DEFAULT '[]',
  note text, updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, message_id),
  FOREIGN KEY (tenant_id, actor_id, product_id, message_id) REFERENCES assistant.messages (tenant_id, actor_id, product_id, id) ON DELETE CASCADE
);
ALTER TABLE assistant.feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant.feedback FORCE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='assistant' AND tablename='feedback' AND policyname='private_scope') THEN
    CREATE POLICY private_scope ON assistant.feedback USING (tenant_id=current_setting('app.tenant_id',true) AND actor_id=current_setting('app.actor_id',true) AND product_id=current_setting('app.product_id',true)) WITH CHECK (tenant_id=current_setting('app.tenant_id',true) AND actor_id=current_setting('app.actor_id',true) AND product_id=current_setting('app.product_id',true));
  END IF;
END $$;

-- Events stay append-only, except when a conversation is purged on request.
CREATE OR REPLACE FUNCTION assistant.refuse_event_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' AND current_setting('assistant.purge', true) = 'on' THEN RETURN OLD; END IF;
  RAISE EXCEPTION 'Assistant events are append-only' USING ERRCODE='55000';
END $$;
