-- MCP servers a person connected; their tools are offered to the model.
CREATE TABLE IF NOT EXISTS assistant.connectors (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL,
  name text NOT NULL, url text NOT NULL, enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, id),
  UNIQUE (tenant_id, actor_id, product_id, url)
);
ALTER TABLE assistant.connectors ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant.connectors FORCE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='assistant' AND tablename='connectors' AND policyname='private_scope') THEN
    CREATE POLICY private_scope ON assistant.connectors USING (tenant_id=current_setting('app.tenant_id',true) AND actor_id=current_setting('app.actor_id',true) AND product_id=current_setting('app.product_id',true)) WITH CHECK (tenant_id=current_setting('app.tenant_id',true) AND actor_id=current_setting('app.actor_id',true) AND product_id=current_setting('app.product_id',true));
  END IF;
END $$;
