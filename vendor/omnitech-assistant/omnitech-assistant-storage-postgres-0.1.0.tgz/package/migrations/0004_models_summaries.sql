-- Images the user attaches are kept as bytes for models that can see them.
ALTER TABLE assistant.attachments ADD COLUMN IF NOT EXISTS content bytea;
-- A summary of earlier turns that stands in for them in the model's context;
-- the messages themselves are kept.
ALTER TABLE assistant.threads ADD COLUMN IF NOT EXISTS summary jsonb;
