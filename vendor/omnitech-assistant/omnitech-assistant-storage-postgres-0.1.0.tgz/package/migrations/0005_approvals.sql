-- A run can pause until the person allows or denies an action.
ALTER TABLE assistant.runs DROP CONSTRAINT IF EXISTS runs_status_check;
ALTER TABLE assistant.runs ADD CONSTRAINT runs_status_check
  CHECK (status IN ('queued','running','waiting','completed','failed','cancelled','interrupted'));
-- Tools the person allowed for the rest of a conversation.
ALTER TABLE assistant.threads ADD COLUMN IF NOT EXISTS allowed_tools jsonb NOT NULL DEFAULT '[]';
CREATE TABLE IF NOT EXISTS assistant.approvals (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL,
  run_id text NOT NULL, call_id text NOT NULL, tool text NOT NULL, request jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','once','always','denied')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, id),
  UNIQUE (tenant_id, actor_id, product_id, run_id, call_id),
  FOREIGN KEY (tenant_id, actor_id, product_id, run_id) REFERENCES assistant.runs (tenant_id, actor_id, product_id, id)
);
ALTER TABLE assistant.approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant.approvals FORCE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='assistant' AND tablename='approvals' AND policyname='private_scope') THEN
    CREATE POLICY private_scope ON assistant.approvals USING (tenant_id=current_setting('app.tenant_id',true) AND actor_id=current_setting('app.actor_id',true) AND product_id=current_setting('app.product_id',true)) WITH CHECK (tenant_id=current_setting('app.tenant_id',true) AND actor_id=current_setting('app.actor_id',true) AND product_id=current_setting('app.product_id',true));
  END IF;
END $$;
