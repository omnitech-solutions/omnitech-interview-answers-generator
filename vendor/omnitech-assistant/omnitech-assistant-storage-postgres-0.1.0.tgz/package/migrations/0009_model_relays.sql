-- Model calls handed to a model running in the person's browser, and what it streamed back.
CREATE TABLE IF NOT EXISTS assistant.model_relays (
  tenant_id text NOT NULL, actor_id text NOT NULL, product_id text NOT NULL, id text NOT NULL,
  profile_id text NOT NULL, input jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','claimed','done','failed','cancelled')),
  parts jsonb NOT NULL DEFAULT '[]', error text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, actor_id, product_id, id)
);
CREATE INDEX IF NOT EXISTS assistant_model_relays_pending ON assistant.model_relays (tenant_id, actor_id, product_id, created_at) WHERE status = 'pending';
ALTER TABLE assistant.model_relays ENABLE ROW LEVEL SECURITY;
ALTER TABLE assistant.model_relays FORCE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='assistant' AND tablename='model_relays' AND policyname='private_scope') THEN
    CREATE POLICY private_scope ON assistant.model_relays USING (tenant_id=current_setting('app.tenant_id',true) AND actor_id=current_setting('app.actor_id',true) AND product_id=current_setting('app.product_id',true)) WITH CHECK (tenant_id=current_setting('app.tenant_id',true) AND actor_id=current_setting('app.actor_id',true) AND product_id=current_setting('app.product_id',true));
  END IF;
END $$;
