-- A proposal that was applied can be undone (reverted) and applied again.
ALTER TABLE assistant.proposals DROP CONSTRAINT IF EXISTS proposals_status_check;
ALTER TABLE assistant.proposals ADD CONSTRAINT proposals_status_check
  CHECK (status IN ('pending','applied','rejected','conflicted','reverted'));
