-- How long conversations are kept, and read-only links to share one.
ALTER TABLE assistant.preferences ADD COLUMN IF NOT EXISTS retention text NOT NULL DEFAULT 'forever'
  CHECK (retention IN ('forever','90d','30d'));
ALTER TABLE assistant.threads ADD COLUMN IF NOT EXISTS share_token text;
CREATE UNIQUE INDEX IF NOT EXISTS assistant_thread_share ON assistant.threads (share_token) WHERE share_token IS NOT NULL;
